/* Digital Factory Lab – booking database for ONE station (Moodle Database JavaScript template).
   List page: station header, "Book this station", bookings grouped by day, conflict flags.
   Add/Edit page: checks the time against the other bookings of this station before saving.
   Who may book is decided by Moodle permissions (role "Station booker"), not by this script. */
(function () {
  /* ======== settings ======== */
  var STATION = "3D Measuring Machine";          // name shown on this page (also used by the overview)
  var LOCATION = "C0.1", ROOM = "";
  var OVERVIEW_DB = 2323;             // id of the "Station overview" database (number after d= in its URL); 0 = no back link
  var AVAIL_DB = 0;                // id of the "Robot availability" database; 0 = don't check the availability board
  var OPEN = 8, CLOSE = 18, MAX_HOURS = 4;
  var DAYS = [1, 2, 3, 4, 5];      // bookable weekdays, 1 = Monday
  var IMG = "data:image/webp;base64,UklGRp4YAABXRUJQVlA4WAoAAAAQAAAAtwAAxwAAQUxQSLILAAAB/yckSPD/eGtEpO4TDtpIcqSpvvvYffwBbxoIEf2fgKrneX4abbSu6WR/NqYpXZV0JHRcSQCOMgI5yMI+0BSsrdgLansBrip14CrddwNgSAtkhdjWZ7WfPqnFXZJ7rMctkTR7v19wD6mqlQ1wfyVUjbi4NuAN2zZDsq1tO6+IVKlR3T17NMe0Bqbnsm3btm3btm3ba9oYto1GuTIjrh+VVZVZmRkLvyJiAhApgRE95VSgMID0lp9ulgqR0tlHaj5SmhCnaCnGIM66OySirvkaWUSKMZB33uCLqLilObUEKDqhMZj2eV8GOCLUgvQCiciErUEDcebSQTAiJqWQ2oTItU0YkMuvBVh4dm7luedOltAOfKUXf35TBytwagEcFYQGQANQmL9t/nGnTY/lh6eK6LHyu09eh2xmyQDEIKw50njr8xBl9XefBbTOHtvDoFxy/djliLT4hNcDjMylguiwrPjK5Y3l8WiAHLLY89BpD8Alu9uOHRUDnDliRIQQYqdV1wAiqkwuFBEaqNgm9U4oNgdZojCXYlu1TUObg3BthHs6LjF1MwBhDCCEk6viOkUcBRhRcwZ1F2dacZ37BwA6MpVlUzIme+aPAJSKSmcYXIppfnMDAFFUnGWxn/VHxKrMJe/c2KF1VNpcJtehM4hMmUv5prDAtCwcCtHKtLwFDmGOShtLfg/CKSo2FcKiqS2LMOKotKlAURhr09IIF8LUbCcqNhTS6LpiLCpTJep2GQy7m7ifaXWfn4uMTed+MDTxcFM745ToyHDuD0O3H2Fql1im9jgYevFOpjYyFAebgcy5rp3Lgy03V7SEr1pO2c0Vm+04st9ec95Z8+NFmwQChgralgAzC4LZzr38bzn0SIQBpg7Kqpm37mSGedNTno0kU3aNvycHIx9/PxJOWTU5BTOTRZj5zgqSrzsoaw6tRwpyR9a2rkXSlc6oB1+WNFZaSieDVrwWSSebAM6gFyD5hEyav38KdIZwpjwFhj760EE4euB4tVqvtsQZMxflIpMdnCVPQfyNz/0WDiHUu/RV93O1IDDroE3QhRyglyFId2Sp+EV8R1+J3sXqkpIS4KBV1xy86HXAoafXVDCaNfNzsTVfhXiPA9DbF5G9d0Ls30DMFgDpIYPvE9vid+JiAEQZlD8/tr9gEJBFZyL2vw1GFl8Ym94QW2avia3SiI0zSpwZW1PEltWl02MjxM4AKIOK5dhsO7YhAG4xewq52DwvtmkAQxPZY8vYpBUbA5BW9kgRG4m4hqYV8NNt2cOIXVpxnVs6Av3lg9kzgCTiuvmTb8E3rkf2ao5PxhX87MlLO5cySKnYQHEB8opHI4MXa/HJ+PC7e2TR0kJ8PAC/vGdG5Nqql8axNLjDWDaMftM52fbrlWqt2aby7FlpkJXeqjIGWxuD9DHgL3vjq5/gmgEG/Ukf+NhHzcDWgwbg+DsXGPVmUGm3Wq2gzUorbllW5nACwjX7SvkN3dDtdkMdmLghc1Ri+v95XEP3dQA84EOrUsP1E8WgHvy4PvG7H73s/Je3+DciLZwgUb1zPPJVT1yu8YkK85dTw9XZcIcP57FOc+2zT/CQlh5SU8XTCjC2p85XC6RnIT3u8o0vf+RN77w8ojs8wge1T1Y3X5IibnrgmQDw5g9E89a3lQA0F45fd6uJhPqItsgNAJCW8zuVGl7aRExe9dsdcApLu1OjmDYUkS2/ua4DXKwcSQsvbWQ0IOz5RAiEvcwpIdNGRCMk0/evg24CIGEF6eBmArTMt951MR9TAATaQSoU0yZiZmHhz0+2VaGAzsWTaeClzVvfFwkAglr177LyvY5vP9dPATddtPjwB1TT748VEYC3vXvhprsFha3v/XkNKeili5InjgXVQyf9pf3V2rFqs1pttnxAKwQAhv696lXrK0+6w9N3IQUply59+r7frDeWjlUWl2blY289Xl94xGc33vew/bx7ffCmFBB2ivXOb9FK1/WMuG1j018z+d5/22jWKtzm5EgrI8hlIdBj8JfGmX4zP3b1W5Ij7IyARJ+tzfYp5XE4V7ENkRAnK/pvV4ZtwJdaM5JpWVnllBCukNAcMv32fxES61KG7f3S9UjysZxjEWVR61s/QaIPveBk0X3RYzPo759Bwv3ddWATIuSU2/KJA0hF2Rf7TKl25Mv/REr2R6QUp1j12QABTJy8uz5pbnZypBdAkUgxZ9ayXUsKUPIAFIbLD93cS7o7z7zcIzAjNX93OCuweTsUgyg10MyMylFlCzBS8w6nQQXggGTqDYOlZRGnxSM/PcY+oBvSttPOAUgQI9H27Nq75Hdv37no3vV9pzlsW5B5hqR0O3QLMdsyYe++HwA06xV33CoXiTUgkfL+9+/xY5vsPBK+Bn0yIfWv+TC2gVm12wkLrD7S/9j7NwJggt9WCcvcf92CTqFZsFkxwpksmLXQHQKwLTYwAogY3cmIQkkKYqJuJm1LYpZkVLoLWIIBMi0CkeWVJHEHkQmFayZh2ZOSYc46RBEJJ1+UCGUj4hBoFvlcSYSZse4mbS5RFzKhcEcKEOe7GbEOsUGOaBe4GxmQCskRw3dHml0YBqw7hCfIKxT2B12MmDoILF053oZ5SSnYb40UTWrlPfYfrrEjLGovVM83qSPNi8v+o0Y0ifwZu6Ycg6pdBznjTmjGqbtvrU4b1GljJ9TeG3whefc6HJoIIxM6eQkBkwzJAKqnhhnxocYEMGqRlADINijatgawA1g2AeftMKgV1oWrXZeJWhVxYWN7kpgyxvevyI/m8+T71XLtCg4jSkLmVo7csn4hkMqSvLyDiMNgwBYsiUCS5Yk2axLcIciAfEgSgRDSagPQAIHA2oAsQNu+ZReGPZj11GVO46QsSmYCQB1kRkcPTM0OnT1laVgQYSAjQmWrX7gl58phl4QECEQw4jOeN6srl7geN3wiySBiEmRCWz5V8Kyfc1nbNiuNTrJhwqyWgc3WSMNyQxhgLdiABIgRWHNUV+jOAZJIWWMFDOjGeY5r9WDGATprs44ks9pyfUg1R4Z1+7sQ2iyNlXMmdfx9CG/YY3bBeBaOF4cdQtD2F7+ArsrXC7bpNDesv2aPItFcaC6ju3+sKGG2fNXXD599RmHrddc10LO7PJF3TIb9T80ByF3+it/+8+2remt75VzSZKpV35xHuHXx237/0+dPdpNtr5xP2qZ8uZRax18g0OvQE/96y+O7gJVjJe1D18tVysuJeDRRIk68l9Cn++TrvjQdoqvHrWbSggMHbt56ZLmqJazowhk8YL+qof+Jz934kI6gUfcTNySbvjW6ornt4BX+iJAUB6B9xYN0AyJ9zC2vJUDUrDwnzWbNWjm6Pba5eSkdq0sp+mNQGJRqqQEKosH5V3+jDFdOTiQucKketFE/cXArn4sTR6s7DmgG9dazZL+iB0aqaLDid38caYzOaj9pulkJJHFDBQzhrZwfdYpn39Er2qWSjATSCepqUAhRF7/4t59d9Y0P3CNp/lKLAq0ViABmAXdq/qxVc0snnZnzV+YiACzNNCAx2p/a8OsfPT6XtAXBDAaIiABmgBml2Zz09UV3PjM3PyX6AivQYIjoYD3jq/uehqQHAEAAs4AmBjEYGoAtvckzWsVH3mvK6Qc+d1GJwaWKd61OGsCAIoA0E4gBBpgRKmyafvidVo5NlERPrDhMVA9xHBTH6esaJ+6cNGJ0MjQAIjAARs+UH56//8XaOW261AVaCwbAtO/l7/ntuoXI/DgwdvlqK2lREoO4l1BX5FdMT3xu3ULQYZFnCwBoXvGVtzzvxW/92nWLUez8RyxpqDuoNyCK8B98+BlPe/tf9x5rq5ykDrV8cPO6P37y5Y986Eu+tq7Rx8Hnb0m5cOon3qEz1q599pQsTliARTpoAAQCTdztpZffcd7t0iQY6dhwffiCB54/3pAgMLqLmXPvdM814wBWzsNgZWloZUCa0efY6Y9+cFveN28yAK5ApHLiUX/Jwcy/cQL/pwtWUDggxgwAANBAAJ0BKrgAyAA+bTKVRyQjIiEoMtvYgA2JZxwA+DWIAGVA+Nw8X6z3nPHaarvJ+BCf078ZPDz/U/V31Y8DP0C+wyO5lu8ptQJ3346zCPZL65xR6Vn909Qb+S/2X/weqjn8+sPYG/nH9k9Nb2meh1+wh0yinutleTCLHR45Rvq2sHW3eBo8rvsa7BP/6rPt6V6MscNGMc4tsI9VlMnWuv/VdMKWQvx1h2ZqiK9990ErbHQwk2Oz/yt9GYP+JG6R6dqCM169ZkpQ6M+FfLLtVkGmIxCyv6InNtA62S9S8T3xm6X+CJiAHkINcHUZ/65JnerNeMPEW4iYJ3P58q686GcjAJ7PpDSIYbMwUPNAL8pvU17SBxs4CvPnD4JzUNSVpvRzP9P++I0gKX1fU51wPDmxRc72uxIuJA1/zZPHtOVsgH1FQGWJ5ZbMF2u5GFJ4PQb52RPC0Y/FeQreFRSP0olIHSr9S1kMjVx9DaNUjBcwD0yDh0hO1wxw9FXy/RHB9+DToasxygQwyr2833MUp6tPfWwhT7tsVpXfZNcgzbRHV0/aTn/INRqMjLYUSpTgYrOZfSX9zuyHwtQDbuJ3VULgSgeCmjIlvHTokMdF09SYf/weEGuVZId04NvVFi52i+GMQU7kzHhljnRO3AWpvKuRnPUM+u+bT/B8+uG5oamJ/tGjUHeS1WfAd/2E5kwAAP7V0Gm1dMFX8n44hnhw1bVTk7HwXuwMt4rAP/LZMIcCa0JdwZcF844Umhis3pF91lEess2JcAw+mK79wFiio0lCCVRo/Vi8GN2mwUD0NPnenJawy+waiEZU6ybGjZ3UP/yxF0GsMWitT/5nu2yPdf4X7/71LXIXZieuX4dAtz4/fugZR4gIyI29uCgeswoLQlPHIztlDr9kyBXiiNMont9SPc4i3os4WkudqOY/P5OnFborb0oSYyBLIT8lJN/NZICu/YQ/0NzrECuNYXbR0xaRYknwRKB5C8B/1K5FlaeEP80ZPRmsGIa6WnAnro5QD4LGsiZdmLSenO4YI9m0wl4ktDoSueSgAaG5AfPEcvJE6rMQXEgPWuhXDXRnmXHMmaVhK4rnkoAEN/xgUp417CdzQo7wMj3Ibou3OR6JkBFYmfBlA4IKQplwSTaerXVkIRnODC4gMoiHkEPdj/qoTZs4+cswMJT7dGN/t73HkxPFLQTC/XKkhrpCU885xQuEQp6ylUqx68YIHujApQFJ/wBsVgFlZ57tWP/xN+pKG8OOiGaNgb198vrhJ4TdlgFAO3UXYVCvrZsoOh4IJPgxosbgxLeAZo+GYCBrxFeEhFvckcohhO5s+JGNO68heVyh+izR3qnKdQMjdxv7pGCGZtua3ognU/kgEXl86m1S4/cdgsQdrevyBN4pIix5UNotIuptQGgXb4ytO0Qc8klpqUfLtwIraflVanKzMtzTP8qEcJk4ENagsxlD90ZmrkpEp1qNkk+wP/7u4g07+xqOTs8T2LXNwBjJYuplsSHzv0QLOnnriLLz/zmzToxOB/+BZNPZZhm5fl9vDDuSfhG0wihfb4hclmCNs/PUuzI0oJg7x3RRhv/uNYBOxoW3RvO0sGK59OaWQzWYVkV7bzn5kqjysxccsmWrxkopxbylwyHMYBYLE246oD/4DXQcF4mgElXZSYRft+JZSDx0YOpLzyddKjSxTSpdwO4uFjyfNivgZ5llg9V6NDzIzprf/6sm60jQ0Hp1HzjohLwQxdkvFBp4xJQrHtdsXsTeoXf+W6qXEvQyXGcmXOIsAyPVf/+Ra//w8p//vj33lviVpqh0StT8GzHI4cLd/MKzBzOgQuCRzajHljmx9gBP5Xzfyp1/7IymGT9At4vp7jklsP4wfy8ES4XV17oZ/Npdxq/5J+4xTeO1GSupz8MXsP2aK0xHFyF+2COqffVNcWJjFc2EwLbKIMqV8muIOTejrXAGySoV+NmyjhbsiuX6+lvzKkC8oEgmNlkrt041DQiqTz+ZCyuuTmCrhcsKB4BTq9OxN40/6BL95RJ+Uahap7SyTRYjVfy/BUb1/vC/U7QnB6MDHXXRam1feG0yUkEDMbtFENGRTqtMlSsc5tdRkWqDPzCOAmjwVnaiI5FmN/Ys5LB5gG5R2oN3quXv+u5Z62wjXGEmRYffMjighGVNLnZVkbZw1rAbsssQVFN28f79x9P4Zjtotrf9ncHMMkFBhGT3PT3f8/btk7GimOoyud2VJModmbTkf0W+Ee2W2qGrRohXuMZUv96JMTc7vSUfYmzuGGfVNCSTv6RhZcKJ6p3xAA2zouvA8iVnmihqunljmUgaZG32iWNiKZoKSB4oxqrltMb7K91rHZ3sXBNoZyJY+7fuQCGdv9c4Wd0zLTVwMeQLNu6ft2FyG6Z1S8yo2Id0z8okEZLwTI1EdQjdy95yOLl2Hs8wbDfToBYj0N6/kvCnVrN6zAd1TdctU9uG3YsDiuTnF4GtfGHNo0LyZSNa2WxM0DEMLuXBWOvR9Zs7Hs0ai/YjfJnnwRtnZWHWeFnedEuc68V3hEDLG4F0VEt1iT27My3yEFPUx9Uun+5uRTcf3+zdl04RrumzcQzo0lW/P+ssj4TJ4wY8rBGb0R7ydC32cNujpEp4XIbxJ0hp9z2K9U+ETfu6cYpS5PLoBlParCgQO9MJuON91nh6gBQEHL3qNY4Ht36kCjf7Ee/ekACdMJ2H5q0Yy+4cUTM+l/9dpH7XYOzaez9pZkxbM6bbn+4RtDEeRj36U6+pISaGyc3z6vbhEHcUAe6y8OIk3Ebei/5M0GGGZ1MEGCvhMufuFYTIu9mzv59pou/pDQ8DXv7dRqgCQcR+R4RxoiYnrVKPcQ/tnIhNQcS5m4aKZkQEt0bRm1xP3vRNzMOhF7c7PQScaWMSTCQ7Ljdv0VcT6oRWMqgaS8T4U9Junz0E4+ta0hgOhomZaIK9qH/s754Mz/P5nyuBvQhBy2kqikmgbBcBdtpFc2EYZk/zpY0wtRqvG34aL2X5ZrBd6kQtSqgKtR+1LYQ1/2AxSv7Smml5FzTA8vEEUBeX06uEq8P9jEpJ+pQzHcl/DcB0iYo1zqbIYWMhVmtIHiIw0IBKMUjXIKjO+euJnJxay2OrpcSp0P3+hHVt2pgynvX1DTj1vyJGOJ3CyDUO9xo7uB8pu5i6MACK0uY1RnhX/RMrjoOGb/MKT1F381qsNAjiK9u1mBpjrnn8Kq10MkEnZsDxSUrDbglgykPv5gPqiIW1QyzgnrvHaSXjWmsa1LkEdZ5X4plTbWDtPxox4h8sAycqMe6BxNzsdaPCzc6TpduyYtrFllq1zmDSZdsgc3FZxdaqAQ/QJj+cuLzrUqRF9gAwFVtgBXvMiIkG4D5gXHpcYQh+Td4gUIn2CmsnohPm++nEkMCSzXsIW8T5xrzHrtOeWCjipXfUPPGVP5BHjZXkqAwD1zm4aZ5fFv1beTLViEvlrUoBEX0jvr96/0X8fb04U4XJO55Tm897VHI01W/SAJFKwtGyNmx2cq2xbnIVLnHam/VTgQXFW9LxMX5yhGeSTCvtO3iOjwNImxvRl6haGnsdz6/tW97aeLYnyNOgPTdAmytKM9V4uwkeE+w7huny5L4Ca2QD63UXK5JbeMCxcqg/K37dufZja+IyDHbcb5nTOE1U2a6ir47cPAIMGINSrLJljNFB4JwXtoOE+23tCyd9f/pPJ9j/rNxMMwRYk/Zt+iiX0P1eNlAacfRo5yrnyV97AWiFd/LAXb3uBLR4Ea2ZkOx4c/yxOAfsZz1FzotdklQJ+5xBmO3LfsrHj1MwB2agyyvhMOudTWRm2sJDwzSOdP+89NfUj0JdmjxrPNlqsGr4be161KeZcTz+5xfntUmReZqnh3LbRhzf8txDqfAk7zMzEZU07JyhN2jgyqW26Kx+NLUpxit33fWyEoLSDukLGWj6JAsJ0dEbfkOYUuNTYxQpnOztkmjXqzLSQ/Y8F98NOpYrWTQvklIwL/NJ9W0TEpZNTH9WqDAugbbPVrNrB6Pxtx62zaOvuC5CQY63J+QCBMu7W2fz5cjQOXBo7Wh4Yw6+KTYDNAvlAj1R/ZcopfJ/03U+L7CBQlAuw7Di/GXubuU092kj9MEDSJzsusz4RWv/duwnGmciS+SKVL+Za9PVgTskC5uuRiUElMA/RKf/PRN0WrFXsBPFZuGc4NYExfn2dtICJJ0peVWHBHhhWfKSk4MtcupV7y2etkidTC9lh5MyUT27SlZI0JeaucgpAAAkejnj4yCoAECCwvnsXJ6bvEMEQpwY2HNb8B3OI0ss3AQH27Db7+ExSJf1/5//T+b3/GA+v/Tu2bV/5UliIrLgMSSc7TVAAAAAAA==";               // picture of the station: image address or data: image ("" = none)
  /* ========================== */

  var MONTHS = { january: 1, jan: 1, januar: 1, "jänner": 1, february: 2, feb: 2, februar: 2, "feber": 2, march: 3, mar: 3, "märz": 3, "mär": 3,
    april: 4, apr: 4, may: 5, mai: 5, june: 6, jun: 6, juni: 6, july: 7, jul: 7, juli: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9,
    october: 10, oct: 10, oktober: 10, okt: 10, november: 11, nov: 11, december: 12, dec: 12, dezember: 12, dez: 12 };
  var WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function txt(el) { return el ? el.textContent.replace(/\s+/g, " ").trim() : ""; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m) + "-" + pad(d); }
  function today() { var d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function dow(s) { var p = s.split("-"); return (new Date(+p[0], +p[1] - 1, +p[2]).getDay() + 6) % 7 + 1; }
  function nice(s) { var p = s.split("-"); return WD[dow(s) - 1] + ", " + p[2] + "." + p[1] + "." + p[0]; }
  function hh(h) { return pad(h) + ":00"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseShown(s) {   /* "18 November 2026" (English) or "18. November 2026" (German) */
    var m = s.toLowerCase().match(/(\d{1,2})\.?\s*([a-zäö]+)\.?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]]) { return iso(+m[3], MONTHS[m[2]], +m[1]); }
    m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) { return iso(+m[3], +m[2], +m[1]); }
    m = s.match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : "";
  }
  function hour(s) { var m = String(s).match(/(\d{1,2})/); return m ? +m[1] : NaN; }
  function param(n) { var m = location.search.match(new RegExp("[?&]" + n + "=([^&]*)")); return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; }
  function selfQuery() { return param("d") ? "d=" + param("d") : "id=" + param("id"); }
  function overlaps(a, b) { return a.date === b.date && a.from < b.to && b.from < a.to; }

  function readBookings(root) {
    return Array.prototype.map.call(root.querySelectorAll(".bk-e"), function (e) {
      return { el: e, id: +e.getAttribute("data-id") || 0, date: parseShown(txt(e.querySelector(".bk-date"))),
        from: hour(txt(e.querySelector(".bk-from"))), to: hour(txt(e.querySelector(".bk-to"))),
        user: txt(e.querySelector(".bk-user")), note: txt(e.querySelector(".bk-note")) };
    });
  }
  function readBoard(root) {
    var out = null;
    Array.prototype.forEach.call(root.querySelectorAll(".tdf-card"), function (c) {
      if (txt(c.querySelector(".tdf-name")) !== STATION) { return; }
      var u = txt(c.querySelector(".tdf-until")).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      out = { status: txt(c.querySelector(".tdf-status")), person: txt(c.querySelector(".tdf-person")).replace(/^@\s*/, ""), until: u ? iso(+u[3], +u[2], +u[1]) : "" };
    });
    return out;
  }
  function fetchPage(query) {
    return fetch("view.php?" + query + "&perpage=1000", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.text(); })
      .then(function (h) { return new DOMParser().parseFromString(h, "text/html"); });
  }
  function problems(b, others, board) {
    var p = [];
    if (!b.date) { p.push("Choose a date."); return p; }
    if (isNaN(b.from) || isNaN(b.to)) { p.push("Choose a start and end time."); return p; }
    if (b.to <= b.from) { p.push("The end time must be after the start time."); }
    else if (b.to - b.from > MAX_HOURS) { p.push("A booking can be at most " + MAX_HOURS + " hours."); }
    if (b.from < OPEN || b.to > CLOSE) { p.push("Bookings are possible between " + hh(OPEN) + " and " + hh(CLOSE) + "."); }
    if (DAYS.indexOf(dow(b.date)) < 0) { p.push("The lab is closed on " + nice(b.date) + "."); }
    if (board && (board.status === "Busy" || board.status === "Occupied") && !(board.until && b.date > board.until)) {
      p.push(STATION + " is " + (board.status === "Occupied" ? "out of service" : "assigned to " + (board.person || "someone")) + (board.until ? " until " + nice(board.until) : "") + " (availability board).");
    }
    others.forEach(function (o) { if (overlaps(b, o)) { p.push("Already booked " + hh(o.from) + "–" + hh(o.to) + " by " + (o.user || "someone") + "."); } });
    return p;
  }
  function header() {
    var el = document.getElementById("st-head"); if (!el) { return; }
    var place = [LOCATION, ROOM].filter(function (v) { return v; }).join(" · ");
    el.innerHTML = (IMG ? '<div class="st-img"><img src="' + IMG + '" alt=""></div>' : "") +
      '<div class="st-headtxt"><h3 class="bk-h">' + esc(STATION) + "</h3>" + (place ? '<p class="bk-sub">' + esc(place) + "</p>" : "") +
      '<p class="bk-sub">Bookable ' + WD[DAYS[0] - 1] + "–" + WD[DAYS[DAYS.length - 1] - 1] + ", " + hh(OPEN) + "–" + hh(CLOSE) + ", max. " + MAX_HOURS + " h per booking.</p></div>";
    var back = document.getElementById("st-back");
    if (back) { if (OVERVIEW_DB) { back.href = "view.php?d=" + OVERVIEW_DB; } else { back.style.display = "none"; } }
  }

  /* ---------------- list page ---------------- */
  function listPage(list) {
    header();
    var all = readBookings(document), t = today(), h = new Date().getHours(), board = null;
    var state = { tab: "upcoming", q: "" };
    var phase = function (b) { return !b.date ? "upcoming" : b.date < t || (b.date === t && b.to <= h) ? "past" : b.date === t && b.from <= h ? "now" : "upcoming"; };
    function draw() {
      Array.prototype.forEach.call(list.querySelectorAll(".bk-js"), function (x) { x.remove(); });
      all.forEach(function (b) {
        b.phase = phase(b);
        var pr = problems(b, all.filter(function (o) { return o !== b && o.id < b.id; }), board);
        b.el.className = "bk-e bk-" + b.phase + (pr.length ? " bk-bad" : "");
        b.el.querySelector(".bk-flag").innerHTML = pr.length ? '<span class="bk-badge bad">Problem</span>' : b.phase === "now" ? '<span class="bk-badge now">Now</span>' : b.phase === "past" ? '<span class="bk-badge">Past</span>' : '<span class="bk-badge ok">Confirmed</span>';
        var pe = b.el.querySelector(".bk-problems");
        if (!pe) { pe = document.createElement("div"); pe.className = "bk-problems"; b.el.insertBefore(pe, b.el.querySelector(".bk-actions")); }
        pe.innerHTML = pr.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + (pr.length ? "<div><b>Please change or delete this booking.</b></div>" : "");
      });
      var show = all.filter(function (b) {
        var okTab = state.tab === "all" || (state.tab === "past" ? b.phase === "past" : state.tab === "today" ? b.date === t : b.phase !== "past");
        return okTab && (!state.q || (b.user + " " + b.note).toLowerCase().indexOf(state.q) >= 0);
      });
      var asc = state.tab !== "past";
      show.sort(function (a, b) { var k = (a.date + pad(a.from)).localeCompare(b.date + pad(b.from)); return asc ? k : -k; });
      all.forEach(function (b) { b.el.style.display = "none"; });
      var last = "";
      show.forEach(function (b) {
        if (b.date !== last) { var hd = document.createElement("h4"); hd.className = "bk-dayhead bk-js"; hd.textContent = (b.date === t ? "Today · " : "") + (b.date ? nice(b.date) : "No date"); list.appendChild(hd); last = b.date; }
        b.el.style.display = ""; list.appendChild(b.el);
      });
      if (!show.length) { var e = document.createElement("p"); e.className = "bk-empty bk-js"; e.textContent = state.tab === "upcoming" ? "No upcoming bookings for this station." : "No bookings match these filters."; list.appendChild(e); }
      var up = all.filter(function (b) { return b.phase !== "past"; }).length, now = all.filter(function (b) { return b.phase === "now"; }).length;
      var bad = all.filter(function (b) { return /bk-bad/.test(b.el.className) && b.phase !== "past"; }).length;
      document.getElementById("bk-summary").innerHTML = "<b>" + up + "</b> upcoming · <b>" + now + "</b> running now" + (bad ? ' · <span class="bad">' + bad + " with a problem</span>" : "");
      Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-t") === state.tab); });
    }
    var qi = document.getElementById("bk-q"); if (qi) { qi.oninput = function () { state.q = qi.value.toLowerCase().trim(); draw(); }; }
    Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.onclick = function () { state.tab = b.getAttribute("data-t"); draw(); }; });
    var add = document.getElementById("bk-add"); if (add) { add.href = "edit.php?" + selfQuery(); }
    if (document.querySelector(".pagination, .paging")) {
      var hint = document.getElementById("bk-pagehint");
      hint.innerHTML = 'Some bookings are on other pages. <a href="view.php?' + selfQuery() + '&perpage=1000">Show all bookings on one page</a>.'; hint.hidden = false;
    }
    draw();
    if (AVAIL_DB) { fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); draw(); }).catch(function () {}); }
  }

  /* ---------------- add / edit page ---------------- */
  function formPage(form) {
    var t = document.getElementById("st-formtitle"); if (t) { t.textContent = "Book: " + STATION; }
    var fromSel = form.querySelector(".bkf-from select"), toSel = form.querySelector(".bkf-to select");
    var dsel = function (part) { return form.querySelector('.bkf-date select[name$="_' + part + '"]'); };
    var box = document.getElementById("bk-check"), others = null, board = null, rid = +param("rid") || 0;
    var pd = param("date").match(/^(\d{4})-(\d{2})-(\d{2})$/), pf = +param("from"), pt = +param("to");
    var setSel = function (sel, fn) { if (sel) { Array.prototype.forEach.call(sel.options, function (o) { if (fn(o)) { sel.value = o.value; } }); } };
    if (pd && !rid) { setSel(dsel("year"), function (o) { return +o.value === +pd[1]; }); setSel(dsel("month"), function (o) { return +o.value === +pd[2]; }); setSel(dsel("day"), function (o) { return +o.value === +pd[3]; }); }
    if (pf && !rid) { setSel(fromSel, function (o) { return hour(o.text) === pf; }); }
    if (pt && !rid) { setSel(toSel, function (o) { return hour(o.text) === pt; }); }
    function current() {
      var y = dsel("year"), m = dsel("month"), d = dsel("day");
      return { date: y && m && d ? iso(+y.value, +m.value, +d.value) : "",
        from: hour(fromSel ? fromSel.options[fromSel.selectedIndex].text : ""), to: hour(toSel ? toSel.options[toSel.selectedIndex].text : "") };
    }
    function check(final) {
      var b = current(), p = problems(b, others || [], board);
      if (b.date && (b.date < today() || (b.date === today() && b.from < new Date().getHours()))) { p.unshift("That time has already passed."); }
      var day = others && b.date ? others.filter(function (o) { return o.date === b.date; }).sort(function (a, c) { return a.from - c.from; }) : [];
      var dayTxt = day.length ? "<div class='bk-dayline'>Other bookings on " + nice(b.date) + ": " + day.map(function (o) { return hh(o.from) + "–" + hh(o.to) + " (" + esc(o.user) + ")"; }).join(", ") + "</div>" : "";
      if (others === null) { box.className = "bk-checkbox wait"; box.innerHTML = "Checking existing bookings…"; return p; }
      if (p.length) { box.className = "bk-checkbox bad"; box.innerHTML = "<b>" + (final ? "Not saved: " : "") + "please fix this first</b>" + p.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + dayTxt; }
      else if (b.date && !isNaN(b.from)) { box.className = "bk-checkbox ok"; box.innerHTML = "<b>✓ " + esc(STATION) + " is free on " + nice(b.date) + ", " + hh(b.from) + "–" + hh(b.to) + ".</b>" + dayTxt; }
      else { box.className = "bk-checkbox"; box.innerHTML = "Choose a date and time."; }
      return p;
    }
    [fromSel, toSel, dsel("day"), dsel("month"), dsel("year")].forEach(function (s) {
      if (s) { s.addEventListener("change", function () {
        var toH = toSel ? hour(toSel.options[toSel.selectedIndex].text) : NaN, frH = hour(fromSel.options[fromSel.selectedIndex].text);
        if (s === fromSel && toSel && (isNaN(toH) || toH <= frH)) { setSel(toSel, function (o) { return hour(o.text) === frH + 1; }); }
        check(false);
      }); }
    });
    var f = form.closest("form");
    if (f) { f.addEventListener("submit", function (ev) {
      if ((ev.submitter && /cancel/i.test(ev.submitter.name || "")) || others === null) { return; }
      if (check(true).length) { ev.preventDefault(); box.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }); }
    check(false);
    var jobs = [fetchPage(selfQuery()).then(function (doc) {
      var all = readBookings(doc);   // a booking that clashes with an earlier one is marked "Problem" – it doesn't block others
      others = all.filter(function (o) { return o.id !== rid && !all.some(function (e) { return e.id < o.id && overlaps(e, o); }); });
    })];
    if (AVAIL_DB) { jobs.push(fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); }).catch(function () {})); }
    Promise.all(jobs).then(function () { check(false); }).catch(function () {
      others = []; check(false);
      box.insertAdjacentHTML("beforeend", "<div class='bk-dayline'>Couldn't load the other bookings – conflicts will be flagged on the list page.</div>");
    });
  }

  function run() {
    var list = document.querySelector(".bk-list"); if (list) { listPage(list); }
    var form = document.querySelector(".bk-sform"); if (form) { formPage(form); }
    if (!list && !form && document.getElementById("st-head")) { header(); }
  }
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", run); } else { run(); }
})();
