/* Digital Factory Lab – booking database for ONE station (Moodle Database JavaScript template).
   List page: station header, "Book this station", bookings grouped by day, conflict flags.
   Add/Edit page: checks the time against the other bookings of this station before saving.
   Who may book is decided by Moodle permissions (role "Station booker"), not by this script. */
(function () {
  /* ======== settings ======== */
  var STATION = "Taurob - Sieglinde";          // name shown on this page (also used by the overview)
  var LOCATION = "C0.1", ROOM = "";
  var OVERVIEW_DB = 2323;             // id of the "Station overview" database (number after d= in its URL); 0 = no back link
  var AVAIL_DB = 0;                // id of the "Robot availability" database; 0 = don't check the availability board
  var OPEN = 8, CLOSE = 18, MAX_HOURS = 4;
  var DAYS = [1, 2, 3, 4, 5];      // bookable weekdays, 1 = Monday
  var IMG = "data:image/webp;base64,UklGRkYiAABXRUJQVlA4WAoAAAAQAAAA7wAAnwAAQUxQSI4RAAAB8Mf//+qm/f89T9I2RVqKe9lgDC/u7u6uc3d3h/cMXoUXc8FtArOyDZsPhxc+rLpK2oY0niPP5+P+R845SUtzXv56R8QEsP/3/39mrnf9wEnd/35qd8/Xl7yE7AZ/J0n3OKHr7/h3kv0b6NPov5PYGgPc/ffSE0Yf/Z1ga96pZiXNAumdavp3gJTx7M/FgbVJldMjL6RHOQ9buho2Vnfa2lIA8LepnFlOoQd8wxhr2i8j0ZJ13L/1kV8U6P7ZpDJqPu0GABIRm1nNBy+L0BcdbBbsbugKRa34fCyLfY27DiNSyGEBYEXjjxGZn7WyhuUaTRGKJ8DfYZXY6wfoExcEYOkGGD9suW5EJHGC+8nkmI3JRpR02Gvic8laNV659vUn9sBw90R7bAZ86IvG/IfMQttb9N5+K2PsUTKAuimdMVbLHkX6k+OD0ERsSOCAw0L1XXNlM2PsVg/Mnlx826ZjL97+wUAzN/QcIHNCjAjHa1uosQWo+HD8azKiLzqLitcSDVIekHqWq4j9yVQLVfd9DSBETyAAeNBg4CPDP1QQW0EAztS1UEzaoKASfbfo9Njt9CPWp/IBXGhopdhDyw9VAvh7rRljU70wG7q47Um/kfPZfQCKrrNU4zJ7f0axA86MYmyIF1zHe3j1rAHXsxqXjJ4ZuB+As52lSt5y3/jz/ktZqw7GCM5JbIiqw9/olMga7cm5PflVg70pGecBlLa2VKzT9rGd2qYxlvLY1oKYwDWusxMEyI8yxtgzgHL6h6/liM+asnZ/AvB0sFas66a5dhZ5/ZnYoGJrLifg3aSIBWEAWDBk1SerpyUy1tYJINjdYrHGL697eGynVukfAVxQDICQKnDumgSJMSaNLABwBzPMcAEI97RajLWc+fjSl5e9t9MHig1A5f2YFMHYVg51otHYAgBKX+tlPKoEgmKDyw0Y03E8/uGBillGd/4BQB1g3dIuQVNjVNSSMUlijKWtevfNCxt0kpv13ekGIEZat9ZOCB4jX0eD2ss3vn/4M0fDXre8e7hIBgjAg9atXxix/7wJ03U8v3HH2cu/FijQFYoA7b390acaWbPBXoodvnGwpPTpL2y56NVgUghVBQUFsC3Rkk0OhbXY4dMVv5UiekGyRiDA192SLRKKPxQb7g8Rog6eP1QhiBSFBAF4zZL9H9SQLyRiEbziD5MZXnLo3Rsz0pq//NdyEQxzRK61ZJughWU1JqqiCej6s3dl3j4svSZjjDV+7Z4NciCgUMQPSVbsMxAhStIjQYD70/0nx7evx4ylhu8/c2+u7A8qGgd2OazYCCeMSc9QA6AuYXW2PsrMJtR99fU5n8mBQEjlwIVmVoxlHIgRKYB7PmOs8W+3mrE7nn193ht+ORTmAPJbWDLWbA3XM09CAV5ikRmnxpiwSbOWz727gHs9KoALDa0ZS3pAiYHQBB1tocMm/+0aI8nW/d2Zi46Q11Xm8Xi+SrFmUi3b7a7owKmoHTN88XO7AbOlrn3x3gMIFay8PXP3V9datFa1We9j0QHOdKOau282srOFy6fuRyh/xYIXtuzsas1Y61SJNd0eA3GXEetztIVBgiP5/sW7oLpXLLrpoXcHWTKpSUuHxJhjqRwVim5KMmArlxtIdtbutb3Qgt89N2/xK8OsWIsdF24bnMAYs9/sjAr4tK5Bm8Ot9JgkOdZeAeSC/UvGPTHKivU/kJ1d8MGtC2556JUTIjqsNmAfPmbEUncBUPNPPtjniTmWK7n1xIfWnipXwTkAxCI81WBMlk2PsY5/AKCS0091njvWYiXecbQclV4+SS/1m1ZGN2gEaL7cm/veMM461Wo78o7MHziqYsUsHfbhCIPEdRoHKPR5j9H3LbBCCQ07zsj87mwFYi+igW+JzpszDAZnywRgX9/Ow++/w2Z57Avf3+2BPsWECCElGoTuszHGXpti8I5bAMD63tMe+GC5w/LcvqrtVLdbEQIxJeKKQMAjooGnDWMJGzvrNTzu1iLWtu41YmJvyerUezN9QZavIkQwSSaIAAI0laJyt2Xspm0JeouLS3fuCAOrmSXu9vWe8mIvh1nyk1ElerumLD7Yhem2fuZiQdY2GfixtvWpMf7WnwBOMEkAtOi0nSu2q1EoX3+xIYPpNryr7kuB/ACA42nWZzaHIZGZGKrPNH8Xqrn8Lo2Yfus7WzLH4k+DRNifYn0yAoLrxZgMgJOXeNjcxVpMP+2hBowx1qUUHH9rb31qnkdMSXBOINmrmADAP33tAsjgvFG7qSzy+gIi/OywPuy7GBERgIOFID1BAPDt3UVwewDuyzn1F5tBjwk6jc8A+L2GBXojNvp0UQUnHYLx/tWZiwd2rudgxiMWptdnjDm+AHAsJX5JVefOyogUiGp7s2HLO7DIlI4jb3hi+Xvf5+aeWNqW2TNDhDP1LNA4UUmkJ0yoWZk/rKjHmNRztysoh/3uioA/IF9YxO7KBi40jluSJFWZ1q5KMiQTQOjYG6nt38/K95WXlxaXuFwej7vcc+bmpRc1ymkWryTJZrfpJDXpPHDS9LaSTardpUlsHEerRrTnZj8BaIV/XDx/ucjpdLlKnaWu0rMXZVFwTXySpISkBLud2dvOW/1L7hUZONC+RcftoQutGLNFxz6OFQmKhsxAc1PBvnOnTl8qdJWVFBaXlrpcrkOHQ1pZ5/jEWGqDNHvS+G/LCIDMAVr3eCYBmbPu/m57RlR3RUNqOMwB0hSuRwAEEP7TFIDct3NcBSWukpyLx48XOEuDqs+vCd+w+CRJqTUSWK8LxNWSrI2nOEhA98pPPwBZjLFEU72VaIQgmBXZHCj6meA8jQoyhYAc3P+38tzTP+/Z+evZMoHI8Pj4ZGNJnW744LxKgDjxdVCFtwiahkgN8G1cuenoslomUs9FEbV25yWEvt0vUHpeyedBIhMA330w+H3Wzvdef+3bIHTF7DjV/KXLMCm8qPiDZKETKfKuAONYvQEOHfZp5eDtw/jjzR8EoMkh+YpSbApC1g7uKjix9csiWdPBLfGpwW6YJCCI0h8JAOGMH5Ch+1DyUnxg13mhkkAoPvKTD1BCmhz0l5IwAyD3Yijv7IUcH/TviU9dKgBooXDQyQGcWY1T+1B4AICXQ/gK/RGho+UoSmMzVjRloys4rxTAn3M4RCASxLkQgrgpcOUvd5/8ZMXqA14A9HJcSuq5s+jwu6+t2vThLk0gOHu04MCDb6DIj1CQZJ/GBXTVDyYdx6qkLn/4LuWHVF4JUMMIK6SEFVUDQIKEGSDn14pHn5mW9iIo4PooLiUOnLX0lXvvytywthxAWYv6+UBWjbV49DUECvPygQhO0D87+e5w+TvvbckXlQGQGqRQMBgIEQDigkwBPPOLLW2egyjM+8wej+rc//6en45nuwv/fH4jgAfrFUHNYAf5vJeB0E3bsN0JoEQDFAUAXMXQDv56wo3KV4LhcJhzTgAIwhQglCtekLPge0ccGrTLB4LuLY2PAUf6eVHWeJHC8+Tzfv/kzKONdsGPAIDiEoBQhYWmaZogITRCjEVh4c+148+IIhgHMtjNBG2HjML2u4AfxqZ+je2f3JC2MvCS8/HysALA7QFVHZMEQ0WLgoLBr1jcTcyCSVrTNHEPIsUxN040YrV+R6AgN6/cv//sq4Unz3id8IZwVYflMJkCcPKVefGm9nkzQO69N6ogRBb3Z6krYV6Tg4g5VRWQEuBRABXz6scXad4lUmRFkWWBSD+BC0DQ0W593gv/dsHUVUhREYEIMVwWXxi7T6twlpW6AvztHQRjAnf6cfLa6RVXEylRaUECQBTVpWcbxZXa+wJl+YW5pUHMTZhzXI+g7/vqliMm1JAAQO4CpycQ0jQ5rFYOD3DwqEAAwLWogDvjSsbJ0pIKry8oY5rE2uXrcQBaOQAIAHkr71o0ZWj3RTIAuC4W+sOqIMGpcigYRiWSFg5rpv4aT2zP+cIhlQDgleEPr/dBkQGuAdg2YmMJR2T4l6e7MsbaZ6Pclb1TDhOqJFcqAyCC6cNt40fS0iCMhQYA4QAgCILOjq07+vfzANylgPzj3V2+rMDby84c5IRq+NPkuHGdD5Uo73jlQi6AcEG2i3D+d6zfue9HQvVJZCY7PW6kl5tyfnXfZzyC6wCuHA5dQXSBw30K1ariNVPWJm5Iz5YLABRRPr510+55ANSzhIpnftTCWfdsB7SQjOqZNDPeznGD2dLfBCAi8vt0bbecQ1/dcPMGeDOehOJ1h6qpKBfFD4mNJuj75ne+J4zcLwB3EQBPiaYuOyBfDIdEdUYGa+3xQpLYzVyPcGp7BZQZ9c/hy3sA+mHTbyqQ/YOM6lyEDM41iRuM/UXxc65oskwoD2J5QvJufFT3IlDw0EMuaF5nbqFSjZHCSaesQ/xI/oVUQZyrAjhY7ExPrHMKy9g9+OJz5VxAcED45GpMNwAgNChOSBKrdQKm9yVLncrxEqt/IrPuOuC5mzaeU1DtcwA082qRbJH2KmRj0jJzJ76ZvNGPH2slfbq++TtYk8yktL5P73VS9ab71FVgS0iqUbNmjWSHI9lRtVKWHr3kNYLYenlzWBvNPjnwjtiTxux2G2P2oRXqaaeo5k6nVSGpdqP0th379OvefciALtc1qVu3bmrVYTa7xFhina7fGnH5o083lG5q/jOwuVXt1JTUlFo1E7p4xMmPf6Dqzd8hVpIkMVuCI9nhcNRIadA8/foek26/74l7F06Yu2jS8AmjBvZt17JV66ZVKYHpXnfOALhS9naxVqCefPDaziPHjxg1uG//PnO92iGnBqrWPG3NSJLNnlQjJa1Ovbp1UtMatuo6eOyMafOnz77jhZUrVy1dnvnyE7eOHDx5/sThE0eNGdq1Tft2LaoQk/T6/ySMABDKf935wePzRoycOH7U4H6951a4mz6OkHJVUWWoHEBWYmKNlNq1U2ql1q3XoH6jRq069urZrkO7NunXdug1YuqcebMXTp8yZfb8OdNHDuzVpd21Des2bNqwTr06qcmJtgS7rSoZjvTDPOVkuwPi4u3XORhjktTwtDrzVN5NJVeV0FNjovsxq9kgvUXzpvUbNm7ZoXWL5i1aX3dNk4Z166bWqVsnJTUlOTHBbrfbWPVpm/j+jt0/H/EYANBkoOLyd1Nb2Rlja3ApMDb18lVlmLWiPOKzNx+ddKNswAnAOsYkm91ut9tsiTUSbTZJYtW/ZG/2i5lIDgqXbBxTn80HlrFmR68Ozo18XmBVsy4vbs96xcYYc5w2IAA4WZPFY8dKHzcHkADCZ+8f7eddai11q2t2U+4xIJQLf67Pr6pckCADjWKRdxmqjwu9k6uBG5jZHQa6hQ3iErN1GDJp0f2XzOiXHfXxHT+eKvpt4BYc/2sJhA/B/Z4/A16vwjkXBEDwgksUgwPvCuFVVb3QqwEaZqJG2zfN/ZQcn/TfVqIhOVzqg3/z4TUvXoBSlK15ARCIiGBSaBU8BvJlQT5SKagBQJnqasGYrUbL4YsfX3PMp5ry9mTxPKnvxCX3r7piAgDXAK2gONtNIuB1FasyqnCYVFwJwqcA2JtyzYIvjpQJRJ9TN67p1v2sJCBMRKpeOucp44FgSARDVQkQ4ESaiPj2LGJ8vl78YwmNOg9/0G0K4F5/TiAc9HGuUUy0isLTckyq5KYEC6A75rW1359VjQAIQaQJmA+WXj7y/ba3XrhnZI/2rZas+fJnT6Xw2Li+6s8spFT3qQMXyhUD06HCUz9seeGWqb1bN6iZwEzaEj+oFCGiCp75+q7eNZnFrNOiy4hl+y/8WeaXOWkhT/65X9e/csPgVnXsLJYS6/BtqVeJGciUkn3g9X6pzKo26tCzV/+h48ePHNS3TaOarHKTWrab6omZSf+5t2c2SWZ/NyY++lu5iJEgQMn7/aWx10rs78vanW9Yf+B8uSwAMhf+8/fNd3Stz/4urd9jxmPv7z6d5woJPSVvz6dPdktlf8/aU1tmDJlz1yMvvfbK8y88srBTbYn9v///Mz5WUDggkhAAAHBGAJ0BKvAAoAA+eTqWSKSjoiEn+RowkA8JZ27hdgDub2upBvtu7ztfor3ij0K+lS8pDNIP4b+M3fT/gPx480fxb53/H/2L9vfXcxV9RebD8M/wP7n5v95vwN1Bfx/+f/6P0iXsOhv/S9QX2V+vd99qZeCvYA/V30j/0/hF/gf9f7Af8z/v//i/y3usf337Ueg/9A/0/7T/AP/M/7P+xPa5/bv2Qf1iLsjnqRDXxql1Ihrz2GMWOoqx/jW1Z1dkoVHu15IhtFINvsapdSFnm118zMAmhlm6ulwxajxJxnP5ObqjDOUNZXXfHOVX3vsUVwJbDNXSdjyQGYFA7JLeJbmPXm0ufP8zVBuaX0QJhhsBHrtIxdc9SIalWKTxWff2qIkKmDLwmKP8bpITCJzqX8q/7qIXrAJwZYrhUVeO+Sc8twQ63rV/jmUAXp+6NNPyCpVtAZB0c75scHmj7RMGzmpo4i5RTglHz7cKm3E5ZDlDxupP9rlMkNklYZ6zplI1whgRpjtTlv+4DNSE9eQV5TP8r/thxRzAuzU/Rzezrb/1acwmPNUB6JoC+kT9cqnMLlRqvAyzcSbWh+Onz7ExQLao++mfj456qFVlnf+xSM8+KqwFI26BDlvbCK1QnNLaSBBfCGGWImu+R/sve7Y/hOUCk2NrEzcFQn+gNd3TnHfhm/YVz+X5+UB8hz6p2hnA9vCoCJHPpavulW3O31C89xYXtrE3f58ec8WCd3O94YIAIbXRd2krFD6jncJgAP7/0IcAAt/5SZwTu+WMzNfxGgu2M944RPZOuZpyI1Nd/n0HYrNLys7zYzE76Tq2RJ4+MtVr/9aniAR+2Qiv7yPnI4TubirGSgkJSPRNtwS44z4lIzkWO7YJoqVVMIbm4/2Mx6d25wBh5YwWgDx6T6eBy+BtW5h2pjJ7gc+g3KV59AHOyHdTkmHKR503+xjMCVV+Rzxl26cc/9mcF035ABeFb1wA41SuLs+mFG4PZcBM31pFmauyXrPCWz2zcdXw6L4Gyx96D877z9k7+I6WgNu5CjmktTsuvbuHKTRm5EmlhLRabLzDD+jzvCvQf/0dSz8QICOEPVIgE/o0G7OmgCztY3suApZ/SSok+Fl4vrTM8kGaTNLkYW508GaepvSyBlt2WFvuyrMKLVOoj72R8dx1BxTqex6bJOdJt/6uj1c0ZbzpYsEjq85jCJCdSujHuynJXg+f1jBVW3mBFbEC1vN+4hQ0mAs2fcpdn37OOf+0U75Ttrz2o88+Xm6dfFmhFBgRh24XWi9KMejDpOSaBbm0ibtVkDXkom8Zaip3+4kZgFbwvJi4uvEO9EIQX+x/M4x8y3f0nkcoTDDYnRYC5jRLnnwPUBPC67esEQt/I4MJM/wJsUpZYcIoFhKJaBgoMqKnvMQxaBTbD1awBTtWGEcjdq/QYYTNAvZDhKigjK4+R6YC2ADh8kFs7JuMGNHrsSVqyV/AiFNShjwcuOBlADOAa/4QOLNMHJAH7clR6q1W5lO81+a0tyS6yNmGuo7VnQLPDz1NJEHYvKyV0s6TkUBMZzpdy2lALi4E0T4OiHHszl7REOkrrDZ2mxu23qS/dQJUAajflMWiTBweowQdKitIy27eqRT45c3yDiEC+Y/HUutdOI/+/32ZI8UYVUjzoZyeFOYSfLmJprXBWRDbYV1d3gdx0JhRIi7ZXhptoCfCU4LhuHlb604rnbBWsfv/p/vxAdUXJ/H+BCc30f+Nx/9nvyVDFM+5Y329fgx6utB+Erk3uVcUI+/zel5Q9xuqn17J6sNM+7d5XsvWfVj8DO+gDOfDGsGz8jirZsf+rVLz9ZBfTFK1cRa10k2j2pP0B4JKLMkn8R8TBIJu/Q/D8QjZ9ef7A69Rhje8/C5bvJc8NriVmmFGZiZe0b2S1VR44dASJ/tSiKNw+9FFt2FjZ5xxolmA6Z4wuthq8CAd072VE0V46mJxxC7q7lKgAq3JN6wTNX/yt9gWK056FKH4+VnlncsPm4AADgtVcMd/FHo56yfZ2/w14hGqBGff27Df2JdxvQL4/wGvhev3ZMXOGJWW/Tg7o/xvkch4NNopgqDbG9qeGp4T8UOeIB5E605eEzPna3BcGz2d5nrEemJXrAOiYnnhEDzfgykz3WfwvzVtsYPf+0FriAuJNuFOJnZm4/Tn3+t1YlW6spyjQONe0/oOdIth3uqLyR+2ISFGVpRohZrMvufHWEkTQm9aUoDbJXmwMAtaAtFnJO03kOqqX08Q70NpQt32IdnpJohL6x4zrhURgCXs/LQ8N30ISAWy3iKOOYSyuyqrCW0BGb/kI8j6OyW9GWM+zTvNprsONVsGxNj8NHKSyy1aGpO3qACxJqm0xbVJkaXQWJxdm1b5ZUAUxGKCs1TUwwd7mfaRU++cs6IqtE5qTFtDXwBRfgoGp/DaEzctRHoGPZrTfrc2LUjN9T8bJL4gLGtGE3Jbyt7fA3apOJeXz6U7TaEhutKCk5W99ApopGd2EVq6I32HcUfIWFgerDN/nFKTKxN8MNu3ZuzIHSoaHO5GjhnalzcJvIlvlOUPNGACu63l4Pb0aVX2x6x+Svt8i/+0L6RI7dFx7jwO8wcWDZjp9jPDcO4x+Pa8rAnOgvd8V+KDqeVZO3/fDylGSG6rh4XN/t7qWcm7W3HNeKa6QjUl7mNw6e/g+0ZSPCTa3njwgXPpedXjudUtCIeSPYeuxqOjUxYr/nXQpzzJ7lbqrIbFwLeBsMhCY3l9kDbfn46+ekDkUhrVDnWdtRCuSLufEuHOwEZNhiBkoN6yp6eYcp7UKfDlPFpSV/gGwpMIXj/vS/BighwH2FGowrqCAeGAdsQceMxqaOOWYbbSm7zzCBdOJvFVbd0W8UCgpAPnqUetzIVSB6twwA/Eyrw16HSPlsl/JsERbWhttiy3Og7VNC9dpMZACeLIl7E6keoQuHX9kk5Oydt4M7N+Ty9AP3vNNSQUHidYdA+cO3g7i36RnMqxr1KccOZjookGVczNxDJvddXuWysnT8cNukAezk54MFG29UzKltzEdogQCnh4mXT3AEaGOBlS1ZbeRf03RVAyl9ojLUP/crCNJWJRI01yGn6IzYQiQmEIIe5lpEQ+Rv/do9inzfBTMKjYfYYeLfTRCHB/5OaBOFqHdh0FRyMFsVuAcMPRd33MXq56DfvLxDWE8Eu7HNOfXoWGnJwCXwsDzie0XNKkp0bTuXdQSenyHKOKYleUVudNf2WSYsD9iv1K0Kp+Tb+HVA1iJbCa2lqgFq8A1ZcZSWbimCY3WHVjAcPwexu2RuAeR//bcBzYnezIqlfshXW3BRKrqoJFJ07ehkoc/5qwJYVGJydOGJfH7XyWODYoq8OK6q+xj8XWr+Ubzcos6llIt7jF8zWYWMQKV6g5nalr4RPMKdhaWvGs8Hk+tsPf0kcMXVse3zlAyIYaPLESoWqQBqeQvhy0HTEVLd25LYpj5NS+h/22HIICkJMeQzCD3Jzls7lt2evSuQmBrNr+fV3x4yC7n5X3fuambSjkD8oypVpDTF/fISV9f1+HPjStB6lOaOSIqgg9pT24GaUTanasZf2LO9YyhvGK9IiCNDzP8Y5rsBhA8wcmogPnf4yaUuz10rfdL8hL0YuyLVu1+YKvnct4o8sSktUF9KGmC5TiKLn92Xy1PxII0wrwzo19i/tPXYdOfLh49xtt8FoIINiSCOfmARlcxhSZB0XQIzo7rxrFKBgMjDgrfJKzSsJ3ARtPMgDEdGhvQhdTX/AoMj6Yctn5PCk0/8JIrxHzFneQ31YnODV0W0CB+R1kfg+0LpKAdPRtaPuOdbMWWwa4o5pg4v1c+bCj0eSx0F+K8V9H822iFnJUYxdEnO8hrwh5/XeaFWHF7HLyGuHH5uWlrUKYA1bbVJH6fqm14/LE9vjDLIGu3MKWc4mY7ZS8xRVSOaKDtSvTyykDEu8hMEWufuj81HUG9Lfm/LOdMdxs+8ovfvk1pQe2+ffe2FxLc+oPFHF8ZEANvm6vIDizbBbKOvWx8SRp6mC0oOvOM1zlmIKxoSIDkQzKsp2Tt3gUf+kgYdusevPEGpu5pwJjg1K5ialbr8OBPeAZtkg48qacGip93PGDQgs+PeioguUyXLx+QW3hjlyDXiqkKBI7tjibmREaXOz+LnQkRurMF02asb5m80Zi/Tu4bbSvPLc5m2OTRLTkWafGlSGAUyHkSmykre/PPUE5WJryiOm/BN2VTZ0iWLQenz7FUerlP7JScVwW/9/FTfCxj04n9vFSnD6YQpwWsiZfyr5slqK4Ml6ROiRjmPGla7jTKU/zoIc22phNAPRMpJq/QzGUrC8UpOQ7nD7V/l+bx6+tbR15bb+z31JH4XCDROhgPS27jFURYNGkF+Aw1pywdgnL4DfUMqvmAWyuoBFwrWjtrVK38A6bO4ue3cnezrMkXv6ToxurTd08+Vqo+PD7qgesOzYje8lkdJwAqyRXsabIh5dRxuFfZno+f7ta5sbQrKbyVETCyGznexvbCFuU3JYuVM2yHt9h+QJohxqGdxIClvo9RZadu3b7tcoUjGwQKL8TyO/toXknhy4TxOJiWrAD2bXYnY9nCL9tDcNIT4GmbuJKnmV4eW6tsOWk7p96TTXGaPOtg9aD2AUMaY51gYbkiHlPQnbEAUlvWx2oZJNw87Mnx4U2wbfhkAY4KEjRHeryTCKtijcEN9C4YB3SNgSP0p1vkBkY8nTfAR9jzD7NOk8deeTZI1JL3C6K5R3xGERRtiDUnzp+LlmW3lnkojGmVbaXnFsWhQJhSJ4USu9RlO+Lhkw+l8N0TGd1YAdajV9sDbJeiktEmcRDgdaYsvXLXisqnvs3c16w7zl6V8/2DQCopDTkmLqCiCOjOU94Cty84erUG/h5763/m18Xtmf8o/SvTz8iOrjfacRF+IByYTjmCTdxBdLe8MJiF6v3AIVFuZrZmqUoYa2IZnsXxd0v/zhuC7veOl3Y1sPkYEG0uIol/hvWhMM/jpVKgmkkIXNIf69aOSaVQ46/KHhDxQxNpmjDHJy/8Zg/cn8zvVKrNCqQZNQB4RUpteIZFGRn5MlT42Gax5IQH9aTFGXHb83IYoUcerYHk7CLcXnClrlZcqRcz4ZKdD0q9ePDPOz46i+fQ4W9SqM5F2eL4plKnpdllDYiMRkwDb6kqjY4iNuTqyJdCZ7cFU/8+BjjEUvH9RrXPqgqcXc/LpqpnPh+5N7js6GOYWNMEImfe1XsInHKDl+G0CwrDDvkxkDPBtHv8kEwoqKbV/jYyH0nPFopZn8OzfGefl/tMdo9+jEu1BQ/QGlRb3DUpdqouW8IS8vFowITRM09oAAW5nY2nc5wGNiAED0cq++pNv16CKlMvso7T/mdyETuUcNV+GLUwXsCxA0+hJAaEoho5IRZ39pEMScA46DRjWKxtRTIAYWxzaIvx7ehvWGrrPduOoNKlTmbkhnad6sLaWX+OE7iFOqGlCab5gdJWDnJr6e3VJfjuuI/hkLDAW48Yly2A4tH+s/IdGJd6ZROFUjayBJUr2TVol8fLSwzkp5l2+THnc9mGu1PcYFo+53wojy7YmIt+dwDPpVACncq51lw3HHGedbKfCbJHHaMVEbX7UmOtUgZy2k3ugoHmGwIdyHLZw0yAAAAAA==";               // picture of the station: image address or data: image ("" = none)
  /* ========================== */

  var MONTHS = { january: 1, jan: 1, januar: 1, "jänner": 1, february: 2, feb: 2, februar: 2, "feber": 2, march: 3, mar: 3, "märz": 3, "mär": 3,
    april: 4, apr: 4, may: 5, mai: 5, june: 6, jun: 6, juni: 6, july: 7, jul: 7, juli: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9,
    october: 10, oct: 10, oktober: 10, okt: 10, november: 11, nov: 11, december: 12, dec: 12, dezember: 12, dez: 12 };
  var WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function txt(el) { return el ? el.textContent.replace(/\s+/g, " ").trim() : ""; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m) + "-" + pad(d); }
  function today() { var d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function dow(s) { var p = s.split("-"); return (new Date(+p[0], +p[1] - 1, +p[2]).getDay() + 6) % 7 + 1; }
  function nice(s) { var p = s.split("-"); return WD[dow(s) - 1] + ", " + p[2] + "." + p[1] + "." + p[0]; }
  function hh(h) { return pad(h) + ":00"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseShown(s) {   /* "18 November 2026" (English) or "18. November 2026" (German) */
    var m = s.toLowerCase().match(/(\d{1,2})\.?\s*([a-zäö]+)\.?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]]) { return iso(+m[3], MONTHS[m[2]], +m[1]); }
    m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) { return iso(+m[3], +m[2], +m[1]); }
    m = s.match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : "";
  }
  function hour(s) { var m = String(s).match(/(\d{1,2})/); return m ? +m[1] : NaN; }
  function param(n) { var m = location.search.match(new RegExp("[?&]" + n + "=([^&]*)")); return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; }
  function selfQuery() { return param("d") ? "d=" + param("d") : "id=" + param("id"); }
  function overlaps(a, b) { return a.date === b.date && a.from < b.to && b.from < a.to; }

  function readBookings(root) {
    return Array.prototype.map.call(root.querySelectorAll(".bk-e"), function (e) {
      return { el: e, id: +e.getAttribute("data-id") || 0, date: parseShown(txt(e.querySelector(".bk-date"))),
        from: hour(txt(e.querySelector(".bk-from"))), to: hour(txt(e.querySelector(".bk-to"))),
        user: txt(e.querySelector(".bk-user")), note: txt(e.querySelector(".bk-note")) };
    });
  }
  function readBoard(root) {
    var out = null;
    Array.prototype.forEach.call(root.querySelectorAll(".tdf-card"), function (c) {
      if (txt(c.querySelector(".tdf-name")) !== STATION) { return; }
      var u = txt(c.querySelector(".tdf-until")).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      out = { status: txt(c.querySelector(".tdf-status")), person: txt(c.querySelector(".tdf-person")).replace(/^@\s*/, ""), until: u ? iso(+u[3], +u[2], +u[1]) : "" };
    });
    return out;
  }
  function fetchPage(query) {
    return fetch("view.php?" + query + "&perpage=1000", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.text(); })
      .then(function (h) { return new DOMParser().parseFromString(h, "text/html"); });
  }
  function problems(b, others, board) {
    var p = [];
    if (!b.date) { p.push("Choose a date."); return p; }
    if (isNaN(b.from) || isNaN(b.to)) { p.push("Choose a start and end time."); return p; }
    if (b.to <= b.from) { p.push("The end time must be after the start time."); }
    else if (b.to - b.from > MAX_HOURS) { p.push("A booking can be at most " + MAX_HOURS + " hours."); }
    if (b.from < OPEN || b.to > CLOSE) { p.push("Bookings are possible between " + hh(OPEN) + " and " + hh(CLOSE) + "."); }
    if (DAYS.indexOf(dow(b.date)) < 0) { p.push("The lab is closed on " + nice(b.date) + "."); }
    if (board && (board.status === "Busy" || board.status === "Occupied") && !(board.until && b.date > board.until)) {
      p.push(STATION + " is " + (board.status === "Occupied" ? "out of service" : "assigned to " + (board.person || "someone")) + (board.until ? " until " + nice(board.until) : "") + " (availability board).");
    }
    others.forEach(function (o) { if (overlaps(b, o)) { p.push("Already booked " + hh(o.from) + "–" + hh(o.to) + " by " + (o.user || "someone") + "."); } });
    return p;
  }
  function header() {
    var el = document.getElementById("st-head"); if (!el) { return; }
    var place = [LOCATION, ROOM].filter(function (v) { return v; }).join(" · ");
    el.innerHTML = (IMG ? '<div class="st-img"><img src="' + IMG + '" alt=""></div>' : "") +
      '<div class="st-headtxt"><h3 class="bk-h">' + esc(STATION) + "</h3>" + (place ? '<p class="bk-sub">' + esc(place) + "</p>" : "") +
      '<p class="bk-sub">Bookable ' + WD[DAYS[0] - 1] + "–" + WD[DAYS[DAYS.length - 1] - 1] + ", " + hh(OPEN) + "–" + hh(CLOSE) + ", max. " + MAX_HOURS + " h per booking.</p></div>";
    var back = document.getElementById("st-back");
    if (back) { if (OVERVIEW_DB) { back.href = "view.php?d=" + OVERVIEW_DB; } else { back.style.display = "none"; } }
  }

  /* ---------------- list page ---------------- */
  function listPage(list) {
    header();
    var all = readBookings(document), t = today(), h = new Date().getHours(), board = null;
    var state = { tab: "upcoming", q: "" };
    var phase = function (b) { return !b.date ? "upcoming" : b.date < t || (b.date === t && b.to <= h) ? "past" : b.date === t && b.from <= h ? "now" : "upcoming"; };
    function draw() {
      Array.prototype.forEach.call(list.querySelectorAll(".bk-js"), function (x) { x.remove(); });
      all.forEach(function (b) {
        b.phase = phase(b);
        var pr = problems(b, all.filter(function (o) { return o !== b && o.id < b.id; }), board);
        b.el.className = "bk-e bk-" + b.phase + (pr.length ? " bk-bad" : "");
        b.el.querySelector(".bk-flag").innerHTML = pr.length ? '<span class="bk-badge bad">Problem</span>' : b.phase === "now" ? '<span class="bk-badge now">Now</span>' : b.phase === "past" ? '<span class="bk-badge">Past</span>' : '<span class="bk-badge ok">Confirmed</span>';
        var pe = b.el.querySelector(".bk-problems");
        if (!pe) { pe = document.createElement("div"); pe.className = "bk-problems"; b.el.insertBefore(pe, b.el.querySelector(".bk-actions")); }
        pe.innerHTML = pr.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + (pr.length ? "<div><b>Please change or delete this booking.</b></div>" : "");
      });
      var show = all.filter(function (b) {
        var okTab = state.tab === "all" || (state.tab === "past" ? b.phase === "past" : state.tab === "today" ? b.date === t : b.phase !== "past");
        return okTab && (!state.q || (b.user + " " + b.note).toLowerCase().indexOf(state.q) >= 0);
      });
      var asc = state.tab !== "past";
      show.sort(function (a, b) { var k = (a.date + pad(a.from)).localeCompare(b.date + pad(b.from)); return asc ? k : -k; });
      all.forEach(function (b) { b.el.style.display = "none"; });
      var last = "";
      show.forEach(function (b) {
        if (b.date !== last) { var hd = document.createElement("h4"); hd.className = "bk-dayhead bk-js"; hd.textContent = (b.date === t ? "Today · " : "") + (b.date ? nice(b.date) : "No date"); list.appendChild(hd); last = b.date; }
        b.el.style.display = ""; list.appendChild(b.el);
      });
      if (!show.length) { var e = document.createElement("p"); e.className = "bk-empty bk-js"; e.textContent = state.tab === "upcoming" ? "No upcoming bookings for this station." : "No bookings match these filters."; list.appendChild(e); }
      var up = all.filter(function (b) { return b.phase !== "past"; }).length, now = all.filter(function (b) { return b.phase === "now"; }).length;
      var bad = all.filter(function (b) { return /bk-bad/.test(b.el.className) && b.phase !== "past"; }).length;
      document.getElementById("bk-summary").innerHTML = "<b>" + up + "</b> upcoming · <b>" + now + "</b> running now" + (bad ? ' · <span class="bad">' + bad + " with a problem</span>" : "");
      Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-t") === state.tab); });
    }
    var qi = document.getElementById("bk-q"); if (qi) { qi.oninput = function () { state.q = qi.value.toLowerCase().trim(); draw(); }; }
    Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.onclick = function () { state.tab = b.getAttribute("data-t"); draw(); }; });
    var add = document.getElementById("bk-add"); if (add) { add.href = "edit.php?" + selfQuery(); }
    if (document.querySelector(".pagination, .paging")) {
      var hint = document.getElementById("bk-pagehint");
      hint.innerHTML = 'Some bookings are on other pages. <a href="view.php?' + selfQuery() + '&perpage=1000">Show all bookings on one page</a>.'; hint.hidden = false;
    }
    draw();
    if (AVAIL_DB) { fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); draw(); }).catch(function () {}); }
  }

  /* ---------------- add / edit page ---------------- */
  function formPage(form) {
    var t = document.getElementById("st-formtitle"); if (t) { t.textContent = "Book: " + STATION; }
    var fromSel = form.querySelector(".bkf-from select"), toSel = form.querySelector(".bkf-to select");
    var dsel = function (part) { return form.querySelector('.bkf-date select[name$="_' + part + '"]'); };
    var box = document.getElementById("bk-check"), others = null, board = null, rid = +param("rid") || 0;
    var pd = param("date").match(/^(\d{4})-(\d{2})-(\d{2})$/), pf = +param("from"), pt = +param("to");
    var setSel = function (sel, fn) { if (sel) { Array.prototype.forEach.call(sel.options, function (o) { if (fn(o)) { sel.value = o.value; } }); } };
    if (pd && !rid) { setSel(dsel("year"), function (o) { return +o.value === +pd[1]; }); setSel(dsel("month"), function (o) { return +o.value === +pd[2]; }); setSel(dsel("day"), function (o) { return +o.value === +pd[3]; }); }
    if (pf && !rid) { setSel(fromSel, function (o) { return hour(o.text) === pf; }); }
    if (pt && !rid) { setSel(toSel, function (o) { return hour(o.text) === pt; }); }
    function current() {
      var y = dsel("year"), m = dsel("month"), d = dsel("day");
      return { date: y && m && d ? iso(+y.value, +m.value, +d.value) : "",
        from: hour(fromSel ? fromSel.options[fromSel.selectedIndex].text : ""), to: hour(toSel ? toSel.options[toSel.selectedIndex].text : "") };
    }
    function check(final) {
      var b = current(), p = problems(b, others || [], board);
      if (b.date && (b.date < today() || (b.date === today() && b.from < new Date().getHours()))) { p.unshift("That time has already passed."); }
      var day = others && b.date ? others.filter(function (o) { return o.date === b.date; }).sort(function (a, c) { return a.from - c.from; }) : [];
      var dayTxt = day.length ? "<div class='bk-dayline'>Other bookings on " + nice(b.date) + ": " + day.map(function (o) { return hh(o.from) + "–" + hh(o.to) + " (" + esc(o.user) + ")"; }).join(", ") + "</div>" : "";
      if (others === null) { box.className = "bk-checkbox wait"; box.innerHTML = "Checking existing bookings…"; return p; }
      if (p.length) { box.className = "bk-checkbox bad"; box.innerHTML = "<b>" + (final ? "Not saved: " : "") + "please fix this first</b>" + p.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + dayTxt; }
      else if (b.date && !isNaN(b.from)) { box.className = "bk-checkbox ok"; box.innerHTML = "<b>✓ " + esc(STATION) + " is free on " + nice(b.date) + ", " + hh(b.from) + "–" + hh(b.to) + ".</b>" + dayTxt; }
      else { box.className = "bk-checkbox"; box.innerHTML = "Choose a date and time."; }
      return p;
    }
    [fromSel, toSel, dsel("day"), dsel("month"), dsel("year")].forEach(function (s) {
      if (s) { s.addEventListener("change", function () {
        var toH = toSel ? hour(toSel.options[toSel.selectedIndex].text) : NaN, frH = hour(fromSel.options[fromSel.selectedIndex].text);
        if (s === fromSel && toSel && (isNaN(toH) || toH <= frH)) { setSel(toSel, function (o) { return hour(o.text) === frH + 1; }); }
        check(false);
      }); }
    });
    var f = form.closest("form");
    if (f) { f.addEventListener("submit", function (ev) {
      if ((ev.submitter && /cancel/i.test(ev.submitter.name || "")) || others === null) { return; }
      if (check(true).length) { ev.preventDefault(); box.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }); }
    check(false);
    var jobs = [fetchPage(selfQuery()).then(function (doc) {
      var all = readBookings(doc);   // a booking that clashes with an earlier one is marked "Problem" – it doesn't block others
      others = all.filter(function (o) { return o.id !== rid && !all.some(function (e) { return e.id < o.id && overlaps(e, o); }); });
    })];
    if (AVAIL_DB) { jobs.push(fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); }).catch(function () {})); }
    Promise.all(jobs).then(function () { check(false); }).catch(function () {
      others = []; check(false);
      box.insertAdjacentHTML("beforeend", "<div class='bk-dayline'>Couldn't load the other bookings – conflicts will be flagged on the list page.</div>");
    });
  }

  function run() {
    var list = document.querySelector(".bk-list"); if (list) { listPage(list); }
    var form = document.querySelector(".bk-sform"); if (form) { formPage(form); }
    if (!list && !form && document.getElementById("st-head")) { header(); }
  }
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", run); } else { run(); }
})();
