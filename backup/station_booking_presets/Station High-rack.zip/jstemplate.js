/* Digital Factory Lab – booking database for ONE station (Moodle Database JavaScript template).
   List page: station header, "Book this station", bookings grouped by day, conflict flags.
   Add/Edit page: checks the time against the other bookings of this station before saving.
   Who may book is decided by Moodle permissions (role "Station booker"), not by this script. */
(function () {
  /* ======== settings ======== */
  var STATION = "High-rack Warehouse";          // name shown on this page (also used by the overview)
  var LOCATION = "C0.1", ROOM = "";
  var OVERVIEW_DB = 2323;             // id of the "Station overview" database (number after d= in its URL); 0 = no back link
  var AVAIL_DB = 0;                // id of the "Robot availability" database; 0 = don't check the availability board
  var OPEN = 8, CLOSE = 18, MAX_HOURS = 4;
  var DAYS = [1, 2, 3, 4, 5];      // bookable weekdays, 1 = Monday
  var IMG = "data:image/webp;base64,UklGRsQhAABXRUJQVlA4WAoAAAAQAAAAswAAxwAAQUxQSPsDAAABp8e4kaQ4VJN/1uDb/4jI4YdhylnIeXI5suTxhNK2kaSZoZvtv+D74bGI/k+APGfsTWW2n+SPFWBgAbYegnK17W1gRZI96YZdJrOiBBpgm3qEAu6aAmiAFljmsRX+TAbNYT6bdE5EOHAjKWyWCAl0kLQ95fYW6APSP9flydeAsXz4HjELk/BQYSERF1cLDXdc1xtfXvzmCSzc3TizibANNWYmlcFMql06k5AwGxu5qqqZ633Fu188vtvH1GSm/Kv5LCJIhzIJKTGzEDNpVxIRVnYOs1QCopeHu7u5JFI1YhVW5uFEwizMg5m4O7GxsbOZcUi+a/e/t1+/uZnKLxBldpU+tJkIddMmLJ88n3toVD7z2fuTFaqyzj1TRoWLKZScAJcMuREJcXFY1zXk33CF3G1zhBLWdQl5ojI3LBB3e0Lc8EAcYzNkznBRMPOcM1nyZHKFGJ4g5xq4RKq5Zypnkk+WdDQlIJsk0A3IJpCxYM6PIFceZ5kDO+TGRUbMzUrGzAsgTwQZGpB1Qsjv/iUjrvJp1nsyaAHrTGr1y+H43UU+kxrF9RQJdsg/YoacBBmu9bKpH3HBrBPh0lUK5PhbEHcvK+R4lRHHsgXysHWdG3Yqcw3MusqCeM26ZMR8MuejWZe6xCxgAYsLkIcVxD/9MjWRQzaxQNy4LIjjbwZmgnhYxNHkoR6IuwNy/L0AxnMgr1kXyLkGZG6WCub379HoEGtBzIGXjFg8sUBsAswSMgdOGXNcgGyCWUO+gLxPNWPetIBZqz+aWFYyYlwkxMi4cDUXfxFPZJAbDplPrpAPIBVg1eEcJIE8kWI+ZASZ56wZsUlBne8DPvxgoDWKU5mHlsPZWws538e8vGCQHc+BAbLJNWSUdEoPvMef+W4c30TxZ37OgIwM2V0XyNrmxdFQTbtbX0esE0aG0R24sELm7WkK55LnYN53XTLkXANyxPJAnGtczBgWyFUA0zZnPC9DHpYgIzCbQK4KZJHC06kU6zPmuHA0/3p7BYxPQq6WjHhvQMK8LrkcDBbIhwBXyCb5NG+RUmBBdjmY/QwXkDlwPpcokNXtPAODzBky5vUFzNsGTiZvLzOOB9nEkQHyS+nhzH9/I3srIZ4oZqKsAGvcoDQJMaMuvdHnrz79ChHPCTeiQTxo31rfauvb2PbemLqaIuAMbqJDWx8btXHb69hud+o8fab2Xg0TlTGIGm9723prexu1VupNVSUA8BwTc90r9VZH7Xur39NWqdPorPxX9na+S78fPIio6e1Wx1Zrr21Q4yoipgGAm6ma0U6j1TbaXvu21bGNEilFKRikANIxSEZrvd62OrY6WmMddpMvYAW6Vx/08TPS/0FKAgBWUDggoh0AAPBqAJ0BKrQAyAA+bSyQRaQioZkZ5vhABsSzi9HBIeEA4dJlfjM2fh/9VvSPUBuNudwsqO0meI36rwR/H/nv9D/fv3Q9ffGH116k3zz8D/xv8B6E/9Xw3+G/+H6hH5n/TvO7+j/6HdF7L/n/QI9pPsXgT6n3gz2APKj/f+J193/5HsC/0H/MerT/meWP689hhMXIJuJER7aUCMlYTQ4G84kYnFELG90CNhVHOlIhw7Uuf+4LAgT6fOPyUgx2FFasc72g/ffQRQ96rnCbPGdDillmz3+4MaO77L0hz0QTptOu7ZO6ts8m8JfUecLIr02FKD/0sMaKsK0qjyfjshiylWdBPeg9mENyFVSFwd4OJGk9UGRUBje9xVQ1sKkKk+uZjSTuTvGl/3W/iWs9L10JzZWcohxUPtkMtL3XC4elED51CBIhp+kIKzmurzex1WePUiHrnUZbHZWSru4Ol/U5ZWe9YsrKQpyJfdae0K93cLss5tMA+FTtNRUKFACJQWVcg1ErLZqYy3MT391WfEPCuCPzlGX1YewXq+1Tu5yRpa4qmnPCyE3uO0Z6oToV3M5C3uf5YyCJO7fmzk00Ry8Uy4sDu71rgFwv3rp8htUtgiU2O8GOGwKG/4C2/t0iPk4xGM4zjlUfq2niAkDKkwqEps6uzH1LXYKeqOBRKDqblknMt7P0gNJDMwurHC9Urtyp3LQ52XaIkxX/w5YeqmWqE3W/liwPzoseM5RFltLENCofPKID9j++liwF/fc/Hjh8JKAIqL6XXBUJST9dTWg0tYYciNq5CGrvliZjLD2JjiXH2zr1u+2YJhMVDMJ7zSFqwJM5puaZ1iCQixxFhHIc7S+xwzBzdlS3KwprP3g+96k9kBa0wje/kBPfJjwqee/NtxO5IQ0n4JfFTYLtii+SzuiKFm6eM55aQydRXl72UiwDZ7mQX76GMbXwpIRYkeS4FkU2+2sx/DZvCiXaVriYvLPaVH2dvCvkf6FS/cr/jjgPAE1NCO/DZp4XJ+/QQAvl0+Y1rXj9fKFArUNrDUiWlrElsb6eOmj+2owy+j7+OICEDYGCm1HjHiHB+4CAgaqNw/r4vurbGAx/sxb+8KKOxIn8ZetCVY+eTodWZcGHo8LI7VPbxKebzQrCbxDLaJffAAD+/3wmQUb5KN9fUdZWZEPcWmZ05cFJVpXyf6L/zg48/uh8docb98LiURGRYAUgoS1yE5aubYejTBlWddHlZIZ1AJjFUjreub0SEtT+r4DUcTC9WjeUGhbVVbwJa6EQ8JrxRH9X7wzWvtkIGjprdORL/ri8DzvsK50upmV4zJHLygmNTONUJo912uJG++A7yGldfi6PCVDNenN2v7MEvZnj3IDbs9vlJqHarNQAQRgwghm4bWc4KDbZHjfligLMeTS6dbpGg9/lyRKVNSeSWh9CE7ZTJKuzcEPoR4ykb8Py4XJgVHDwN2AcK8G7f/N6zR52nLHTIukY0NFLq4KQ//7yBPAmAGuSrJl29VjnJMNP7Uy6CkiVFXjzE5lvzb2PZVQ2Q7iESILZotiST5SyISqUjvN4X1a0IeEq8VMtuXtTVKSPe6zmtE7z4pfZ1uliIDRqhIhW3wOaYEaE7z+uclR4m7+frDT+xxL9HEZPZQif7oQwkXuJTIKnpTrMT5stWKcNcoO3hqGed+tbhmBxgSOGwmZPhnIAm3yd8xK7v8EcEuQmvArckxaVB1VEvUQ7Cx8lkB6IfWDRQ1lBWsUG0fIrt98GptYBsXst1EVd2pq0c7TnN5EAX2JSE70GZFez7yWGz1Q/s/8fhjc9mH3zZXk5JbcWvZZ/wFjC76cHNmve5wztj+jhcZJ0Lzmsa/z1e+lRkWZCqSZ+cnhZuKyLZs/QsQ/TZc4OcwXtZSH3cPolGbypDCL36cOsjXwpn8RkA6/2FGwQdQ93JEHAeENu5uEAo/gVCCtV4EH90rQI2k6Qq/ZzJm1XW2ttfZIJu4fKjxomJsKc+AXplkX7uwqqA0jilWU1hBAKN8LHVdjrSJsorcun9WMSFbAY5kwgCZ0JcimJlmRKijFHeEgDKCVWslMXpWD82iGpH3VmJB12KpJ1Xkt+/Qk/qgkZK3xFMUAb4TsKVNJ9h8QDqlusmIwwGs42/5xXoThCnwxFQzx2EvxPbNK8hziQfnoXSoaJhhxQ0+2qZPpEjgU7hs7tSyanXft0qnopFkdg0wDRUeXh+zGhBaI/S+fXW5+6Ijr7Lq+mn4YEpWyBcx1BdCKrPL54clTdaFNqVUlIVvl7zRuSyJjptsP8v/62nuoBd3HcQaKfYfDJ4NABpYihSl7NpcNwAtirxAvzAYudAvs3knS1kDZDzPKR/wJGH7MBLxQ3n9GY02dt9AZYro+EflsxB+0vYDh+bJojhqy2xy78PMSLWRax1gjS+c8BH0345/u2MsqjTDa1D/K/iPbWiuJ0/8Terw5lgUv6dTPNncRkoSIXWPgn4+9+Ka5drC3zjNqUTrMxyaDl55W4t6pBmnvtEy4unrQi/0nmSzhfDHfQs04Za3e7gNrEeNce6cfCq+gNHOlMIaauftyZnWav37h3dv0bvcWljHu8UWJK+OkT9xcPIlcQFVXV91shHfELuQxpcSim0rnhMROeXrc2AtjRQjG9DbUA7HuTHSXK2bydkLTQZFCLOOVNjruGasU8UKhZlqRogTtpAPWUwgFHs9vv9PxNEy/bj5aBH5wdcfgqVP+7g6mX/D5KxrQQT9Xs98/Y4KPiv936Gwsjq4uKSinPuVKV1uVPVXU8qUHogUVoXam4lbt32T24u+E+qJ23H1+8sUcY3H6naX4NNerNK0VTGdIUICTTR2VrYUcNv9j8o3LYb/0EyapNwWm6McxyYLoQTNHmZf/77+cjiHx+zMNCVHKqth40Uxn6fMA+s13BntlN8ctI31zhjOqBHsx4fLUBq3fiDY3Gm8Snxim9M4AIxMEGW0rT5FQIENd+a++0Hdg2LdGJvQfPnkKkSkuHTA+IfIGxsbr1240mZduQgoofySRLLlJvjrIjIpzeAG0dfmPBQyHi5eeZXVM8VOn0Rx7uRi9W3+g0gyCFu2KSPI8iXQbC4XExkE5QSIFfdLMQQQEDJt4xJbDxVTBCdZK6AvdCqROLq2i1D+pIsBi/hADqp83NBH4o2GXUHL6r5yQDZpJtBs4DRz2I9c3X20YlPmgjyhOt9jFQowpW5Lrb4Wfc4LhX/1eOfQdOq04gSIKvEi9kMsclHp+4LZNYT02RSnmYyyDsTBpUCkQxXXEmUaLN/m9ASZWAQFWu2A+aQDjoeqNcjLLMo8i/78g2Dbn9H4plf+OFcvCq+8D1HSfmBxK+Cfh00Rs2I0ePaNrlm83GofG02RH4AAYHuvrsYuAFvaRKXemIHZdH1rYIXCqi7GJxX+01N+eCZ5maYD+8Gx7DK77uInOxsWGyA6ZlRgXl40wUHrhP1DvemhBJh+/xi4xCTLeixwEvUhaM3KJ+izDG/LSdA3/HbQhHvACkHoz93ekzXIhy4VYpHwEn1MOEuFU8oPOMthxFlkjYK6P+X5zKu59F93kUbHDMYgV6Z9oDJPr/VP34aecttfNX+zVDRv4qKph6dIPU76jP+7D8Opr5UceOFLmofI3ZddfhQ2N2aKsXUSWdSw+RPBrHc3IurVTMbMgCSJY1rm9NqIOFntmtDyqEGiOg2xyqT2+tUWJk6tlm/8+68Xi4fvWKegAwzTrT5N6CBNve1/nLWnq3qeVFHbpVFGken6M4JVqa319DTLxsdeRNt9q7hRgEYOpBK/SFEUAHBt1h0XNjdAQfdOCkSqFLW7bd1T4pgkRdR/mKe5y5b0VoS/YUjeZpDxEROcOjtrGV2kOqQUFH4DO379jzqjKVcdhZbk6AFDR+DXkN1uzLvtLZbLJAOYkNpF/X+uslOnD43r4pN4MmzzkQv6Mm9s5yl9Vdg5Ws8x9tBatsT/fCZdUDOFf7BlKThtbYmeQj/NMsFXFSltVIQ6lozTXjykP22AX60Wf68Z8xPn/uln4DrlpAyUMCSQmYSJsprlZ2IGVZ8GsnBCVAQQKDS3N2LInAikqTCSAu8vSGW01PQmZgf6pt6vwQJEn7ZlNxnB8hdKkTGxTPX+P1/TXs9uN1hRz2anYXrD7rMJLXLV5UUd0DG0GoGnsA+4bVcULNaB35Nj+IA0N2xKJOmMhu8SJb6l8rIpK+2S7SaVBu95KW6hwjcUL8xmVtYmWsgIailMXz78phaMcidjzvvrNp2oyWKhgkpaHdHEn0M+Ljo5ehrTYcgca0RtehOBbqkmFaG/BO9TVmeuQ7N1qmjSlUCjdXHSLocsGkPMJpXbzbkHeln4EX2vF/TIE9xCv3RHx7aA5uoot4p96F8JGKs3uTbIRK7Iwpbb8papWZAOAiDDOrm8k1KjFJb1f07/xKd6X8tbHonIq0yKiBYhYy21fPVOBp7M59GxZbFmLXMbn1e9t78hoXUBQiUobpQkiHmaGlXYWwVh4UlKtl2pv6ImtKlbzdK+diPrC19Jpg7DGwZybAI0I46/KBbKaroFNeoXoBlv41NWUbrOqQvKaxnqPE93KzKGuv7X2yD1qFWAWo3pw4GZ6ktRtwf8llQfppwunGhvDWyWgeSXOrDKymin3TvWhzGZwwwltwdCSeAKNi988qEF8IibGOVcRzUUtpNniO5JR4y4DoXeqotAuBDPH/PRmCNwa61qrXCK1lvbjThhyfYZ+5T6QSCgoq3N/ylgBgM8l3k6HL1LN/6BhNSo06lsdyCnR/oq/aUHkpBnBpAOXyUKTlwSrwEpWcOb3fBVUYwLXqqXPWJl0AsNWEfBb5i9rVaaI+2PDmXLSLctxFQyESv/fO17jW80TfkA4ZaV/8m3/khX1/StEEJrxiPwwNU2yKCyJhT2n4fDkHdTWKt3rChtNatkSL2beoIxKTRVT4FdqZmsdkExCkWngK16fUB6JRGEuQ4KWYjWQlPDHlgD78mYhJ0P4zyChFzebUQDVPAE7E2h56VBpCqlo4ooCSga4bfIzQIlPnoS4EfMaq6fD+A00ftd9ljlPgBmocGiasMnX3K56idPk2o809fDuLuAtyC2xpBFFuSXVcdam9IsfMfsyoBnqJz9QFWt/3euXbYkn/xyjCTPNQH9LPpc5CjA9lG0wYE+SJu82ESt+daHEwl3LeevJiEhupAt0vq4/YM8KLD/DGCXO1xoKZsgfcpoi/y3XwrJfJMALz5geHTiTiS3AGaqS139/eT8VNd1Wh5C/6OfI1bApsANaPrfomshDte6l1Umt+FSpah860Ay1+pYEpEKRO5Fm96hahrVaGAfGATQyXAHz5owXLc1ELEL5F0uDo9Hy6wc/h0XrdthRaQS9SQtTk92qQL5iMLHPmWEDXJ8cg4Kbt64xlxoXdZxqAAOoewAIR8UsIDxPRly6AHFQJXuDR2lxMyph3/vKuAF0ZRUCwZYMAC7qFP76EdWBaed/RUGNZsQOIpjJINiKnHrm5VnAwxbxPvan2Nzr4yFk+hlkzHzrFokm8nABx4tosTs6c77q/oXez8KdwtbjVKsZAj+fV8MAnlgmARurkb5qWKSGbS890RSa4e9+ophpLlRpUHvp1fD5e4ukBRDsYNCeM8hbNfnfmgli/oZcjv5JL8ZtIz0n4KFUJR1fogyIkQaHi82IzeEs4V7QIOR/1CosUDr85/I5e+mgb2VowUB+lRWqGd+O1jT9JMG2Z0ZJ4/vLz7UiPIfVNnfKXq1OR4LP6IpDJqugZh6DplGKRC8tpPi6blC9mjbAn1XSe3bZaWMYrBJ2tYbtEX6/3AVxaLfzCsBfZegxqDCCuFkcl8jSSL0cHwR7WRdAVJwDcA3xLzXR8pDwuo149anQQYpr29EgIsXAREFllRXLruoPtFcJx2QuxhECv+pVZM5UvhXt3NuMVTO64yPmnyeiV9tioY+HG2R6DuLaU8begppOMsWB1pdijbavUGF5g0+65M8OG7JaR0nKZPGLX2kkxG4M8/vvCfIcUyHArXsEe/KNH0otJ9eS7cKzbCxfPOUDGguE6/q4E8M5yDIA5vs1w2AEcCzIKfzj4ly5ZTt4mLINGMt0E2FF9ch1+gWJ2x5v4Kz72ZulSP7u83igTIVPJi9br9CDkCSIRecDs4byVxzvAH1fxvVQZP4cwB/V+3OsNt3jo8N4hw3hAQugUjuyyXtzc/gdBaQX6KU4i9yz2Br/+ZFoPmBT2c4LRmTDdnzRLyJTtcPFo+p5QdbT7VQK/ifYq0vfEI2pzKXC35Zygvup348alDzOJQHPMaNAh35VHxkDmtyq4PrxiWaG2HITjl3V5IR9iTG3P9zKEenAa6DylMS7FeezppeN4aAxxo9MKIdG6tJtB1jkrfcVYE/io+mb+ZTm8Z+3386aMgFfvIXZjcgblbcKfWFRsWA3yII/oNodroGXNqNHpyUPn+LxYWzWlKe//8P/Btt3A789K231Jtwr3p38vYl2hyLqSkXEILJHeJ7a9mUuwZzZ/rKja9V7VFLHUUYZe6TlEW157/aNB5THDKvdxs3xoINCZqHGXDVFVj5iGkNjo8hLNOrZGPNiHqlinPjP9uCeai9jII3YuqhcHvty5Ee6wJhD47eYRFeXJFiyF3T9UneTAesiHmEcM1xVeQ4f64bJd8NIEvCkliRyDo+tkLGO6z+J7q9diK/abZBazPPsuNHUFRq9jvVbZJ5oefyH3EyNjGzlaNvCKnGbkYtz2Q0DdwhCh+wfDL1vo1AEmXGVnHa/87PKpcmTJn+WieXvmV6mHWnSUwP7GY4bHFvy/eBfXfmgp6VACUPCvjNNVdJxp4qR4pFzro0D5p/I4n4EZakp9q+B5VA60lglpXe/J7CZ0dAbb2yjdv0tNnhr/tlLVWHAJSrrBNN30z/u0zKlzZJhoH0s9jtUeGTxMAOCsZ0Ax79ftQcJt/ZJjm7VWWXtOqiqttho9rZn2m25yDYAHuNFyBFdjNtqEWK7pzJNR9jr+D+MOBAzPTJ4vXTR11UDutWeYmMAVRP+CHaTiQDZtsWqpFyfoFcRtRaDJKkR79hgCIxigdGqCtNV3PGr/Rsk3QCcu94OR2iXCOaV7Q0ZFBEpeVYCpv3vh37N106oPHIm+D3WC1EivUVYCMT6AYYoHfvCC+9dwlTiQpMLzrZoAyc7pP2NijCZx9eleHeizWGDph+ifvl7+2Aoyt9utfghwn9UODKMRE+YJ4MTefJrsz0WgEHkJ4wypAiuno0zT8HK1HrQPCedWjlkcndgI1+fCUA/rYouK4s4d8LTcI/m2wHa/cvwePRWRUomewUcLBsE88WPlZ87W2WpWOBHTXBf6obrrUF+4lHZn/zBTT7yRKYZ8wAxpsn4Ny1r3PfnEl5ij9SYvQWr67qAwcdmyPMyraaT+EAqY5e3EAtqtZT2OJ7ajxxf7qd33mMX7tuByvs/Up5OV63JTgLIhc7cjYa40D1WYrwo7e2G6YWmGHO34rR2UWvEgqcZEIaWj/qSXoFvJaQFMcGdp6v4YS03IV8FbBG0MIOzlC31z24Nl3KUha5bfe+Ij0BG/GJU6luuEfnbHw3OeUhg8flRILJDLsoImSibF9ABv2PKSF+2MGtvlUcJqjasA6DPzLUGgAm/sp2qt432vRPjVenLj7mRSe2Qp7AMGnMphATsGF1EccmoBkUsuqpy/S6m81lkMkWsKtUxAWYapdjU66jvrrBA46O5mKkUT4w+tc2VkjGzs8t+f1E0+DS0q7whwlgurBl6E0dkTfaneiZF0RuaanGw6ihl3C8QFTJpEcjZhZmfdhv3+nDt6BEH7MtYfYWVymT++zZswqDC9JOmKIxNA1HacLlK/0UgTeUPgLj3F0QlAoknnn8YhQnLW6mjJNXZ7gjOy1UyBDbcCOP/jeXJgMTu16H5bvIQcI0wMIaPVe8eYsoiJmaRVJbCfjbt3I9QusJkATVOHVd1nX8xmET7lB9ygZvkjK0GpBhWdoWtytd0KlWavS9+XgNzo/7Yn26S5cJiKPffOYjYjZeBwXPjg6sxz93S4XeoM7MO6ClwHZ7MQDIzOygpzMciHYb2yEqt4eGi97pkoo06/olBKFHOP5j0TFrLZbw0FfCZ+qWrCVjnMf+zf0XAannA/NdanUkl7lvXEbJ8DVixc8Nq121dnp74XLgD2ViR6aI5vZ0fvaoP5j5MiF07QAmcgqiLKybd31D1gnn96up9LMo7t/tXf9mNxlLbcf8xNx0lz2iuVXtOv/D6TMn3pKnMLmn1Ub/nUHvOBWwM/6Y67JgrKS8OUAgKt0rzVyoVJvlDVV3wlamHcuoWAU+iwUauxLzzTlOWo8goXHzisi2TqEgYkvL7d5lTSyENxbtVFs+gfpM5syq3Q/+37MKiZ60WEEpyFXmb6FBAjvhBYinjLdh/M+ydv053rQbJOq8u7bdUngvYwI5BUsbEHBYqCbgWUULe6pPlsk3A6n1wTjpfZ4d9Kla6YoC6G7KusR3cUkdwGFat+WoUod94a0iByJTO87SYg9m5LnqVMIVe1fZpIRPyTDnVSUnkn7L8YJHdggeCCcIi2qtKaWbXK4vXvJsI13RzjnMp9hLCJJvMK/hffs6V+cHSUnwPU6tcHZMyBfpKT6Q9UaQruax2lIZgHrEs4KiVNOAxoDU6TDJoGpqzRoCkrK4q0hDVJivsliJV8Dwo/AlOIQSGzNeZf7dqGldP6cW2cEnZg6JYpgb9pBLX1o9DfP4dp3YgChUI1o6cX7Fomy3Rh/CNDnoTCPg5wmEXLFkp8vIX4MLB/B9SlcBtjmw/e0aGMbTIWWmz3J5PMhs1JaatbxkIX3MN4110q6XBNPLH7smAebLXkzGys7MCE5f7/FwYYhawzRUz4ybh+tc9UA9jckMgHJezpkNbo+RPIBOwDYP5/bR/PX1d+p3W56xW7XEljnqUKPe98SM76Pn+UKQAX2WOjOHuR6fHuQoD0KOSRhvN2P5Z0l/urzGx+iYo1TFkUJQiUbOhXNns+g/YM/UXR+YjU3WDgmJAXdFI0x8ml3gDvYnr5iycA/zVr+AmKSL71LUpUG1ILVkk0U+C0fv8VUiPibdjbiT41xlwaIupv713uZhSRNehb9+HCMqiydM01BKlh2AzmRzs4K/7H8Ws6CRKNhLhZdX4BlyR3DwomYPTjVFELDHXJab89o98HU5NIXH53C+DHCZMVa6OldTnHsPn8Q4TPD1bAay/5HqUxoLwSrMajZDz43FOAPdeY9l/61mEqgVj3yxYo/ghCs1LOmp2D6vJuGf5F1FVFoiQu3TqWsdEnx0PuZu2axz1BuCI11xpSI+j5zaAy898ygyziAKASdvmEctkF94pTCQvbiXcJdq2CXg+usEB+0pmrMOBzpNCwyUE4HIlptEDpP+tbRA/n9iSr1dFDfOrgQqFh2KsQOB8bfwrV8O3gsEBC/oZ1PBVFRGWlxoF3rSnF8CjYuEAsuJNctWgHqKSOI0ACwmS9g/0NMfcjIRfqmSKa1gg1BqcMC2fCPT2cBY85NB0bcja3kEWYZojz7GuwvHoVyoLA5PHkJr5WHra1u74tlvDNPhHXUOQv0ze1ZwByQqgALgzJHtE1DssLXMfXpWla3JKzT40BSLYIrnmYHlgg/mBc1VGwEV/kAHjVstjKudAVSzXFVomAUQAksDpX4IPW7djaf5iVq15lo95tihML597uNQz+CCqdh+tzIPcf09c8Ls3ubzRlWAT4VWm659N2J1j9OnB9C3++ePrrBRV+In9XJsK2GP+leFulCz2OtWRvVVS9LTupiRTPxwZ53BRJox3dDl/uE0v4wkJl8TtZFsvOzxVm51qHZv/D2nxyqo7RZwvczzgz8mDdkgyBXFtngWXEl2ahpmFvHgWwz1ZyB5VvQdC8EfXH7J/NMlNPqxyqj6/b98XnUGAxDmACDNd9qIB6BFn7gAQuWRW8i2cevg2TxmC6qobG2ms6+8nCRqA8vSsfxDrT7zITwxCo578Jst5fVRnXQCwd8nnbebimD8nh96y/6NsWHGcROnEHkozkxpvoqXRKpMjbBXvgcgdIDsXq39Dwl93d0URrtrTS1avSW7G9q5Iq4N8WfzWCunHkAAAAAAAAAAAA";               // picture of the station: image address or data: image ("" = none)
  /* ========================== */

  var MONTHS = { january: 1, jan: 1, januar: 1, "jänner": 1, february: 2, feb: 2, februar: 2, "feber": 2, march: 3, mar: 3, "märz": 3, "mär": 3,
    april: 4, apr: 4, may: 5, mai: 5, june: 6, jun: 6, juni: 6, july: 7, jul: 7, juli: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9,
    october: 10, oct: 10, oktober: 10, okt: 10, november: 11, nov: 11, december: 12, dec: 12, dezember: 12, dez: 12 };
  var WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function txt(el) { return el ? el.textContent.replace(/\s+/g, " ").trim() : ""; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m) + "-" + pad(d); }
  function today() { var d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function dow(s) { var p = s.split("-"); return (new Date(+p[0], +p[1] - 1, +p[2]).getDay() + 6) % 7 + 1; }
  function nice(s) { var p = s.split("-"); return WD[dow(s) - 1] + ", " + p[2] + "." + p[1] + "." + p[0]; }
  function hh(h) { return pad(h) + ":00"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseShown(s) {   /* "18 November 2026" (English) or "18. November 2026" (German) */
    var m = s.toLowerCase().match(/(\d{1,2})\.?\s*([a-zäö]+)\.?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]]) { return iso(+m[3], MONTHS[m[2]], +m[1]); }
    m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) { return iso(+m[3], +m[2], +m[1]); }
    m = s.match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : "";
  }
  function hour(s) { var m = String(s).match(/(\d{1,2})/); return m ? +m[1] : NaN; }
  function param(n) { var m = location.search.match(new RegExp("[?&]" + n + "=([^&]*)")); return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; }
  function selfQuery() { return param("d") ? "d=" + param("d") : "id=" + param("id"); }
  function overlaps(a, b) { return a.date === b.date && a.from < b.to && b.from < a.to; }

  function readBookings(root) {
    return Array.prototype.map.call(root.querySelectorAll(".bk-e"), function (e) {
      return { el: e, id: +e.getAttribute("data-id") || 0, date: parseShown(txt(e.querySelector(".bk-date"))),
        from: hour(txt(e.querySelector(".bk-from"))), to: hour(txt(e.querySelector(".bk-to"))),
        user: txt(e.querySelector(".bk-user")), note: txt(e.querySelector(".bk-note")) };
    });
  }
  function readBoard(root) {
    var out = null;
    Array.prototype.forEach.call(root.querySelectorAll(".tdf-card"), function (c) {
      if (txt(c.querySelector(".tdf-name")) !== STATION) { return; }
      var u = txt(c.querySelector(".tdf-until")).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      out = { status: txt(c.querySelector(".tdf-status")), person: txt(c.querySelector(".tdf-person")).replace(/^@\s*/, ""), until: u ? iso(+u[3], +u[2], +u[1]) : "" };
    });
    return out;
  }
  function fetchPage(query) {
    return fetch("view.php?" + query + "&perpage=1000", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.text(); })
      .then(function (h) { return new DOMParser().parseFromString(h, "text/html"); });
  }
  function problems(b, others, board) {
    var p = [];
    if (!b.date) { p.push("Choose a date."); return p; }
    if (isNaN(b.from) || isNaN(b.to)) { p.push("Choose a start and end time."); return p; }
    if (b.to <= b.from) { p.push("The end time must be after the start time."); }
    else if (b.to - b.from > MAX_HOURS) { p.push("A booking can be at most " + MAX_HOURS + " hours."); }
    if (b.from < OPEN || b.to > CLOSE) { p.push("Bookings are possible between " + hh(OPEN) + " and " + hh(CLOSE) + "."); }
    if (DAYS.indexOf(dow(b.date)) < 0) { p.push("The lab is closed on " + nice(b.date) + "."); }
    if (board && (board.status === "Busy" || board.status === "Occupied") && !(board.until && b.date > board.until)) {
      p.push(STATION + " is " + (board.status === "Occupied" ? "out of service" : "assigned to " + (board.person || "someone")) + (board.until ? " until " + nice(board.until) : "") + " (availability board).");
    }
    others.forEach(function (o) { if (overlaps(b, o)) { p.push("Already booked " + hh(o.from) + "–" + hh(o.to) + " by " + (o.user || "someone") + "."); } });
    return p;
  }
  function header() {
    var el = document.getElementById("st-head"); if (!el) { return; }
    var place = [LOCATION, ROOM].filter(function (v) { return v; }).join(" · ");
    el.innerHTML = (IMG ? '<div class="st-img"><img src="' + IMG + '" alt=""></div>' : "") +
      '<div class="st-headtxt"><h3 class="bk-h">' + esc(STATION) + "</h3>" + (place ? '<p class="bk-sub">' + esc(place) + "</p>" : "") +
      '<p class="bk-sub">Bookable ' + WD[DAYS[0] - 1] + "–" + WD[DAYS[DAYS.length - 1] - 1] + ", " + hh(OPEN) + "–" + hh(CLOSE) + ", max. " + MAX_HOURS + " h per booking.</p></div>";
    var back = document.getElementById("st-back");
    if (back) { if (OVERVIEW_DB) { back.href = "view.php?d=" + OVERVIEW_DB; } else { back.style.display = "none"; } }
  }

  /* ---------------- list page ---------------- */
  function listPage(list) {
    header();
    var all = readBookings(document), t = today(), h = new Date().getHours(), board = null;
    var state = { tab: "upcoming", q: "" };
    var phase = function (b) { return !b.date ? "upcoming" : b.date < t || (b.date === t && b.to <= h) ? "past" : b.date === t && b.from <= h ? "now" : "upcoming"; };
    function draw() {
      Array.prototype.forEach.call(list.querySelectorAll(".bk-js"), function (x) { x.remove(); });
      all.forEach(function (b) {
        b.phase = phase(b);
        var pr = problems(b, all.filter(function (o) { return o !== b && o.id < b.id; }), board);
        b.el.className = "bk-e bk-" + b.phase + (pr.length ? " bk-bad" : "");
        b.el.querySelector(".bk-flag").innerHTML = pr.length ? '<span class="bk-badge bad">Problem</span>' : b.phase === "now" ? '<span class="bk-badge now">Now</span>' : b.phase === "past" ? '<span class="bk-badge">Past</span>' : '<span class="bk-badge ok">Confirmed</span>';
        var pe = b.el.querySelector(".bk-problems");
        if (!pe) { pe = document.createElement("div"); pe.className = "bk-problems"; b.el.insertBefore(pe, b.el.querySelector(".bk-actions")); }
        pe.innerHTML = pr.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + (pr.length ? "<div><b>Please change or delete this booking.</b></div>" : "");
      });
      var show = all.filter(function (b) {
        var okTab = state.tab === "all" || (state.tab === "past" ? b.phase === "past" : state.tab === "today" ? b.date === t : b.phase !== "past");
        return okTab && (!state.q || (b.user + " " + b.note).toLowerCase().indexOf(state.q) >= 0);
      });
      var asc = state.tab !== "past";
      show.sort(function (a, b) { var k = (a.date + pad(a.from)).localeCompare(b.date + pad(b.from)); return asc ? k : -k; });
      all.forEach(function (b) { b.el.style.display = "none"; });
      var last = "";
      show.forEach(function (b) {
        if (b.date !== last) { var hd = document.createElement("h4"); hd.className = "bk-dayhead bk-js"; hd.textContent = (b.date === t ? "Today · " : "") + (b.date ? nice(b.date) : "No date"); list.appendChild(hd); last = b.date; }
        b.el.style.display = ""; list.appendChild(b.el);
      });
      if (!show.length) { var e = document.createElement("p"); e.className = "bk-empty bk-js"; e.textContent = state.tab === "upcoming" ? "No upcoming bookings for this station." : "No bookings match these filters."; list.appendChild(e); }
      var up = all.filter(function (b) { return b.phase !== "past"; }).length, now = all.filter(function (b) { return b.phase === "now"; }).length;
      var bad = all.filter(function (b) { return /bk-bad/.test(b.el.className) && b.phase !== "past"; }).length;
      document.getElementById("bk-summary").innerHTML = "<b>" + up + "</b> upcoming · <b>" + now + "</b> running now" + (bad ? ' · <span class="bad">' + bad + " with a problem</span>" : "");
      Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-t") === state.tab); });
    }
    var qi = document.getElementById("bk-q"); if (qi) { qi.oninput = function () { state.q = qi.value.toLowerCase().trim(); draw(); }; }
    Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.onclick = function () { state.tab = b.getAttribute("data-t"); draw(); }; });
    var add = document.getElementById("bk-add"); if (add) { add.href = "edit.php?" + selfQuery(); }
    if (document.querySelector(".pagination, .paging")) {
      var hint = document.getElementById("bk-pagehint");
      hint.innerHTML = 'Some bookings are on other pages. <a href="view.php?' + selfQuery() + '&perpage=1000">Show all bookings on one page</a>.'; hint.hidden = false;
    }
    draw();
    if (AVAIL_DB) { fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); draw(); }).catch(function () {}); }
  }

  /* ---------------- add / edit page ---------------- */
  function formPage(form) {
    var t = document.getElementById("st-formtitle"); if (t) { t.textContent = "Book: " + STATION; }
    var fromSel = form.querySelector(".bkf-from select"), toSel = form.querySelector(".bkf-to select");
    var dsel = function (part) { return form.querySelector('.bkf-date select[name$="_' + part + '"]'); };
    var box = document.getElementById("bk-check"), others = null, board = null, rid = +param("rid") || 0;
    var pd = param("date").match(/^(\d{4})-(\d{2})-(\d{2})$/), pf = +param("from"), pt = +param("to");
    var setSel = function (sel, fn) { if (sel) { Array.prototype.forEach.call(sel.options, function (o) { if (fn(o)) { sel.value = o.value; } }); } };
    if (pd && !rid) { setSel(dsel("year"), function (o) { return +o.value === +pd[1]; }); setSel(dsel("month"), function (o) { return +o.value === +pd[2]; }); setSel(dsel("day"), function (o) { return +o.value === +pd[3]; }); }
    if (pf && !rid) { setSel(fromSel, function (o) { return hour(o.text) === pf; }); }
    if (pt && !rid) { setSel(toSel, function (o) { return hour(o.text) === pt; }); }
    function current() {
      var y = dsel("year"), m = dsel("month"), d = dsel("day");
      return { date: y && m && d ? iso(+y.value, +m.value, +d.value) : "",
        from: hour(fromSel ? fromSel.options[fromSel.selectedIndex].text : ""), to: hour(toSel ? toSel.options[toSel.selectedIndex].text : "") };
    }
    function check(final) {
      var b = current(), p = problems(b, others || [], board);
      if (b.date && (b.date < today() || (b.date === today() && b.from < new Date().getHours()))) { p.unshift("That time has already passed."); }
      var day = others && b.date ? others.filter(function (o) { return o.date === b.date; }).sort(function (a, c) { return a.from - c.from; }) : [];
      var dayTxt = day.length ? "<div class='bk-dayline'>Other bookings on " + nice(b.date) + ": " + day.map(function (o) { return hh(o.from) + "–" + hh(o.to) + " (" + esc(o.user) + ")"; }).join(", ") + "</div>" : "";
      if (others === null) { box.className = "bk-checkbox wait"; box.innerHTML = "Checking existing bookings…"; return p; }
      if (p.length) { box.className = "bk-checkbox bad"; box.innerHTML = "<b>" + (final ? "Not saved: " : "") + "please fix this first</b>" + p.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + dayTxt; }
      else if (b.date && !isNaN(b.from)) { box.className = "bk-checkbox ok"; box.innerHTML = "<b>✓ " + esc(STATION) + " is free on " + nice(b.date) + ", " + hh(b.from) + "–" + hh(b.to) + ".</b>" + dayTxt; }
      else { box.className = "bk-checkbox"; box.innerHTML = "Choose a date and time."; }
      return p;
    }
    [fromSel, toSel, dsel("day"), dsel("month"), dsel("year")].forEach(function (s) {
      if (s) { s.addEventListener("change", function () {
        var toH = toSel ? hour(toSel.options[toSel.selectedIndex].text) : NaN, frH = hour(fromSel.options[fromSel.selectedIndex].text);
        if (s === fromSel && toSel && (isNaN(toH) || toH <= frH)) { setSel(toSel, function (o) { return hour(o.text) === frH + 1; }); }
        check(false);
      }); }
    });
    var f = form.closest("form");
    if (f) { f.addEventListener("submit", function (ev) {
      if ((ev.submitter && /cancel/i.test(ev.submitter.name || "")) || others === null) { return; }
      if (check(true).length) { ev.preventDefault(); box.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }); }
    check(false);
    var jobs = [fetchPage(selfQuery()).then(function (doc) {
      var all = readBookings(doc);   // a booking that clashes with an earlier one is marked "Problem" – it doesn't block others
      others = all.filter(function (o) { return o.id !== rid && !all.some(function (e) { return e.id < o.id && overlaps(e, o); }); });
    })];
    if (AVAIL_DB) { jobs.push(fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); }).catch(function () {})); }
    Promise.all(jobs).then(function () { check(false); }).catch(function () {
      others = []; check(false);
      box.insertAdjacentHTML("beforeend", "<div class='bk-dayline'>Couldn't load the other bookings – conflicts will be flagged on the list page.</div>");
    });
  }

  function run() {
    var list = document.querySelector(".bk-list"); if (list) { listPage(list); }
    var form = document.querySelector(".bk-sform"); if (form) { formPage(form); }
    if (!list && !form && document.getElementById("st-head")) { header(); }
  }
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", run); } else { run(); }
})();
