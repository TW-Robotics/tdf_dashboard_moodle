/* Digital Factory Lab – booking database for ONE station (Moodle Database JavaScript template).
   List page: station header, "Book this station", bookings grouped by day, conflict flags.
   Add/Edit page: checks the time against the other bookings of this station before saving.
   Who may book is decided by Moodle permissions (role "Station booker"), not by this script. */
(function () {
  /* ======== settings ======== */
  var STATION = "ABB CRB 15000-5/0.95 (GoFa)";          // name shown on this page (also used by the overview)
  var LOCATION = "C0.1", ROOM = "";
  var OVERVIEW_DB = 2323;             // id of the "Station overview" database (number after d= in its URL); 0 = no back link
  var AVAIL_DB = 0;                // id of the "Robot availability" database; 0 = don't check the availability board
  var OPEN = 8, CLOSE = 18, MAX_HOURS = 4;
  var DAYS = [1, 2, 3, 4, 5];      // bookable weekdays, 1 = Monday
  var IMG = "data:image/webp;base64,UklGRiYMAABXRUJQVlA4WAoAAAAQAAAAngAAnwAAQUxQSGcGAAABoEZrmyFJ+irLbWts27ZtG2vb9nht22ysemzbM61xod1dXfn96K6qLyIjYr0nIiYA/md8TEpCUlJSrElFrLZuN/10wu1yu92n0+/uF+lIUAttyJelGPT+lwcpRa/0cgz53KoGTmW4qghJzz9aFzQViHkFyfNWD7XJr/tuZFm559Nly95ft2HDxi+mhMnI5piTg9xunajJJ+ld5Nn/nNMkmQ5bkPPXY6TimH8RuZ8jDxNErkYD5tSWhr3nZjTkK+GymHMRjXm8jhzCV+po0IoWUuixGY07U3wO2+RcNPBD4otdrWPA4vx9+05Wcfag8BpnYc1+z5m136x5+Ml9ajH5DAYsy7jv6sdvGDv/03K+ZgrupioMfP6lwY17DBwy+4NCrjxNxGZ6HIN0L29fv/aN3yzbUsnVF1axQauiYN6b2Sj1UfwuD2vO+4kH32TBtd2OQVbteLhfj3Gr33bV9Gu7u3n4xAJCH5ODQZcfXv3EU2veuVRNfzVa+5aDLQ3A4JqFifPBcgxe9x3fsfHXn/MR0XOTBraD7DKTwKj2LlOn9esw5dpZDVnU/RZD1XUd/YVuL+LBgQDQ0M0q58FkMKI5dewz3+7EgDmv3DA2hWjGaaT/NhUAYAAyrMrf8M60WmDQdzHkU0Mp7I+XIXnp3VaofitNpevolpdv6J1gAcNadoWGDxE0/AEZroSaP6L5rqEVDB5+IBS9ovyN0AYeRYb+vjWZ19HcAYaPPhYKVuT8Yg7KEZtyRymy/MlaU+JZEn8f48UcD0H3e7xbLEGF9UtHphfbQs2DfSSXU40XfSwERO+R94KK7HcQmZ7oDwHn6SS/2gRUtuMFaxCmO7zINLMFBF6GpE+AgNwbXgoi8W1kWvGkE4L8hWa6iM5nPm4JMGw3Mi2YDME6j5FU9hJS+m3mapp2tQeZbu4MQbctIrncTkD66S8WQ/V6ryGlP4iXoyD4OUi61S4g38EvJkBk484jtyNT79UQ6t00L4GA8OyaecsOeXRke6gvhKq9R3ObkC68fgqZf5UAIcfuIPEPEVLRBWRddmcYhJ52ieRiqpDYHx4DlN18JLvsIog5wdtvLYB0IZJ+YRJB3Em+KpdHAan2As0TIMLoY1xdnA/ElkyaKUKIP83Tto5A7ThGUtxcCHGnOHo7DsjbFpPkpMql/BYz0I9E0vQITQTJ+bwcHQUsb6O5B4SYmMvJ102B6Qc0C8SQnMdF2eM2YGrfROIfJIbUczzkTAa2YQ3Pk7jqS2NLM2Bs71NJstEphpQCZr4XGwFr0w1I+jKIMe0Cq50jAUzMVtHcKYEr6Y8MDwMObRtI9AGiuEhzMWdP9jOT6wCnyQUkrnqCSDhLUNClfZ1EG3Dc1UdyOEwU+QQnbcD5eCT9GgRp+6RSD6G84psI3p6ieUQUEN7z9RByJicB57YsEn2MMABmhFDUCHiP3kdS3EwgrQp8VYH0C7Mc3NX1kpyNFggs3nMyUHFv4H88kn6jiaRb1rp8l8uLrstXjqcZ4H6ah0GoVktyk6bth7Rt2LA2GPBDmtliMbb1EIneXR2aeEjyU9RhlE6yWVOHm5D0DVBG09s0t6hD7A6SyuGaMjS4QnI51aQMw5H0uB2U8RqaDJM6PEezApTR8QvNHHVo5SLxtVGHaT6Sqn07s9+6vbdDBe5EhhW7lkTKbxkLRFzXSnambxnhgXqSc+xjhd9HyS3pDDOcKbduPnaH42RmGoMcDpWZdg8Pj0ntVR6+l5npQR5+MUkM5vKwyyGzETxkgMwbXeHgE6mZszi4XmowtopZYVO52T5m9mW03CBxO6NLbUD2dbLZLAT5J919hM73mEkBAKIWHyXKnQKq+ByNvhiU8TaaqjFmZbiOpqwtKOMNNL4e6vAojX+QVRW65tDgyzGKkLQdif2zFWEkkq91qsFddJ4OanA/XXEjNXiArihNDZ6lK22sBNrndJWdlcDyDZ0+VAngazocoQbfK462TXEsxxTHfkJxIk4rTmwOg/FK0KqYwVwlaF/K4FYlaOZlcLsSNPEwuE0JmpcwuFUFWi9HhncqgOX6SyxyV0VJL/GeiywQW0qvwfKzTErrSW9RWRmT8kbSewLZ+sdK70lGeKmL7CaxwnGysz5yopTNGNkBODt9uXFb9m/Vs9euzc7Ozvzh80/feWnN8mVrXlx5Y6L8AECLAmoz/E0aAFZQOCCYBQAAMCUAnQEqnwCgAD55OplIJKOioSj0ChiQDwlpbuegC+ABl9nneAq/1r6OfKDopve2+2aJ+Y88tMMz36Am6AGIQ+kfSPpHy1AqzAx8eiLBtssVS0kxrh0coWMAQrINXcrAyzrmIsRHZRiISuW7U3FsZrT7vfYJyv20//Z6rc3W7UKJVDwl6F+7dbPEKoufSwuYnYbo9ymkVct4Nd4mYZcdIS1tGLOBre13rWn96HsTijPAVVy1t1Ja9vTKt+0Oyg+zMN1WGa3Hf74+sKaos0oZV7vQccVEyIaWMjI5Kx24DGn3swVKtsTB1ZNDIacEE0cNDu+ty9mCIS1nlHY3y1/uWjB7nZ3uX7FpuydCMCmMw9UcYMco698Wq0U1aoaNQMIFH0XeY6stcPJqsbqSjburU2QAAP7NcAAA//wnLnZ+2k/s/TPPSOx34QA9Ev80th0ShYyja1ZETTbXyJWBW5LViAnK4Qj5RJRgZFJ2nh6PORzPmxIrJm9ljrIjthW42hbDmCp4HPM54ocCBqumxw0BwV47asM6ZEZGr3kW0r6tllqJ2C6/8McqLbb0rNoXxSeqW6xRcU76xF/wUd6OkNM/Hy9uJaTVWTUCPBm4Z9iTBiR38JzGG0spiff2IQ26OBg6Y5xBYb+zi4DZKvqeZ3BiXFmuMi4zGoR//cFh0mcU+EbkVqvQYph0thChcNz/u6CpTk15zXFU8LnEKLmxqiCmgv44yr6sEjmwyiBb8ezVu3okUOrZwIxG9WKSsN31qRLm6kjUYuvNFCFcmSb9xrNX0xZx5iEweWn3WrZiWYih87JPoFbqZBCsLLAHj1zVlCJmx8t+zuz92EbA1SMB/xMbXJQK0xZKb24k4qWm88tRmP0473efEf3hiRHc0qQOJsCvxtNmKDtYT7sBw1lvuMOp89V1cyBqeuTR79ZXxxFJNZPTb9IyH9qjU7sQnuNQvVuTyte1C66TngxR7mdF6fJ/jOePaGobtmx7f3h88jj2wIzZ+/lCh6d4RgiPMeyGJVgzCZ2x+umk0VALFwftGBI2JOeQpY0k/59YIlzwdkp7s/jsJMthdVuNkF/Sc2Ok8ZWwnIOxrG3pTGD2gXDFGnydij0DDKU+HfgrpW6OGImhpFJKBEEW9WMILpnT6gQMP3ZG+QCEQ3E9TXTkWMj9yT22uCuwHut2+fXuK9lC9ywwVjwmrAQdRnfq6V/eX9CzViJWL63maUa+NIQtV32ajc+f91/cZXfwf/+NA//jJD//xgAUPlUtUkxkKSlYsui8AM26QXq5Vlez6z3S2G51Jle3OYzYWBn9G1R0U1o5o9wAaNFbDW1sSe/73/kMGN9EENXGUQr68/tjlmQ5stRDdlXhbJStC3eMTRv7KGv04YA/55Y8VAp+6mQgrjtu2duQHDxS1O2rOdK0yRVcWWd60j5dv/v7obh7cp62jOFNXKtu3zy4ZtcSn/bJRRZlbfTHCZwDdWaWj1o+sW1x6qqyI00AB2XYxkG7y2GbOBzE3ZZFMk2t/Fq/gHCu0RrMbldJSHK7Oy5fATBc4VD/FssBmssBgHGZ1wKPV1dBJ8mIVIjp94vNWYdjlBIimmCmIqcMq7ivzn5+hRZvUZXkxU98xr0f9xzsc96d0YAJmCJxyBF6ImPRg+lnqB5No33dttz5RmuPKxJVIy3+3h0SGUVCH0aGM9I5aYXEtLy3AA/PqaOLdhMuiRGFVNsCvN0aq8ltisrJhZwq/ZguIT4LIJVnAulhJ5xPWYWd+AgzhJ9WPArf9q5enWWZwWjn3ZSubr2nDYyiTd+pbtHlUUjhLDuz5bHoDHX3CjCDyH27/rnFkybhP8WUmDyppiRh7tygZePL+436CK/9D/IL2MgYgqhqvOyHX/t2V8hk5VhXS2QXtFyrT0vzFdWVoAAAAA==";               // picture of the station: image address or data: image ("" = none)
  /* ========================== */

  var MONTHS = { january: 1, jan: 1, januar: 1, "jänner": 1, february: 2, feb: 2, februar: 2, "feber": 2, march: 3, mar: 3, "märz": 3, "mär": 3,
    april: 4, apr: 4, may: 5, mai: 5, june: 6, jun: 6, juni: 6, july: 7, jul: 7, juli: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9,
    october: 10, oct: 10, oktober: 10, okt: 10, november: 11, nov: 11, december: 12, dec: 12, dezember: 12, dez: 12 };
  var WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function txt(el) { return el ? el.textContent.replace(/\s+/g, " ").trim() : ""; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m) + "-" + pad(d); }
  function today() { var d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function dow(s) { var p = s.split("-"); return (new Date(+p[0], +p[1] - 1, +p[2]).getDay() + 6) % 7 + 1; }
  function nice(s) { var p = s.split("-"); return WD[dow(s) - 1] + ", " + p[2] + "." + p[1] + "." + p[0]; }
  function hh(h) { return pad(h) + ":00"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseShown(s) {   /* "18 November 2026" (English) or "18. November 2026" (German) */
    var m = s.toLowerCase().match(/(\d{1,2})\.?\s*([a-zäö]+)\.?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]]) { return iso(+m[3], MONTHS[m[2]], +m[1]); }
    m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) { return iso(+m[3], +m[2], +m[1]); }
    m = s.match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : "";
  }
  function hour(s) { var m = String(s).match(/(\d{1,2})/); return m ? +m[1] : NaN; }
  function param(n) { var m = location.search.match(new RegExp("[?&]" + n + "=([^&]*)")); return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; }
  function selfQuery() { return param("d") ? "d=" + param("d") : "id=" + param("id"); }
  function overlaps(a, b) { return a.date === b.date && a.from < b.to && b.from < a.to; }

  function readBookings(root) {
    return Array.prototype.map.call(root.querySelectorAll(".bk-e"), function (e) {
      return { el: e, id: +e.getAttribute("data-id") || 0, date: parseShown(txt(e.querySelector(".bk-date"))),
        from: hour(txt(e.querySelector(".bk-from"))), to: hour(txt(e.querySelector(".bk-to"))),
        user: txt(e.querySelector(".bk-user")), note: txt(e.querySelector(".bk-note")) };
    });
  }
  function readBoard(root) {
    var out = null;
    Array.prototype.forEach.call(root.querySelectorAll(".tdf-card"), function (c) {
      if (txt(c.querySelector(".tdf-name")) !== STATION) { return; }
      var u = txt(c.querySelector(".tdf-until")).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      out = { status: txt(c.querySelector(".tdf-status")), person: txt(c.querySelector(".tdf-person")).replace(/^@\s*/, ""), until: u ? iso(+u[3], +u[2], +u[1]) : "" };
    });
    return out;
  }
  function fetchPage(query) {
    return fetch("view.php?" + query + "&perpage=1000", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.text(); })
      .then(function (h) { return new DOMParser().parseFromString(h, "text/html"); });
  }
  function problems(b, others, board) {
    var p = [];
    if (!b.date) { p.push("Choose a date."); return p; }
    if (isNaN(b.from) || isNaN(b.to)) { p.push("Choose a start and end time."); return p; }
    if (b.to <= b.from) { p.push("The end time must be after the start time."); }
    else if (b.to - b.from > MAX_HOURS) { p.push("A booking can be at most " + MAX_HOURS + " hours."); }
    if (b.from < OPEN || b.to > CLOSE) { p.push("Bookings are possible between " + hh(OPEN) + " and " + hh(CLOSE) + "."); }
    if (DAYS.indexOf(dow(b.date)) < 0) { p.push("The lab is closed on " + nice(b.date) + "."); }
    if (board && (board.status === "Busy" || board.status === "Occupied") && !(board.until && b.date > board.until)) {
      p.push(STATION + " is " + (board.status === "Occupied" ? "out of service" : "assigned to " + (board.person || "someone")) + (board.until ? " until " + nice(board.until) : "") + " (availability board).");
    }
    others.forEach(function (o) { if (overlaps(b, o)) { p.push("Already booked " + hh(o.from) + "–" + hh(o.to) + " by " + (o.user || "someone") + "."); } });
    return p;
  }
  function header() {
    var el = document.getElementById("st-head"); if (!el) { return; }
    var place = [LOCATION, ROOM].filter(function (v) { return v; }).join(" · ");
    el.innerHTML = (IMG ? '<div class="st-img"><img src="' + IMG + '" alt=""></div>' : "") +
      '<div class="st-headtxt"><h3 class="bk-h">' + esc(STATION) + "</h3>" + (place ? '<p class="bk-sub">' + esc(place) + "</p>" : "") +
      '<p class="bk-sub">Bookable ' + WD[DAYS[0] - 1] + "–" + WD[DAYS[DAYS.length - 1] - 1] + ", " + hh(OPEN) + "–" + hh(CLOSE) + ", max. " + MAX_HOURS + " h per booking.</p></div>";
    var back = document.getElementById("st-back");
    if (back) { if (OVERVIEW_DB) { back.href = "view.php?d=" + OVERVIEW_DB; } else { back.style.display = "none"; } }
  }

  /* ---------------- list page ---------------- */
  function listPage(list) {
    header();
    var all = readBookings(document), t = today(), h = new Date().getHours(), board = null;
    var state = { tab: "upcoming", q: "" };
    var phase = function (b) { return !b.date ? "upcoming" : b.date < t || (b.date === t && b.to <= h) ? "past" : b.date === t && b.from <= h ? "now" : "upcoming"; };
    function draw() {
      Array.prototype.forEach.call(list.querySelectorAll(".bk-js"), function (x) { x.remove(); });
      all.forEach(function (b) {
        b.phase = phase(b);
        var pr = problems(b, all.filter(function (o) { return o !== b && o.id < b.id; }), board);
        b.el.className = "bk-e bk-" + b.phase + (pr.length ? " bk-bad" : "");
        b.el.querySelector(".bk-flag").innerHTML = pr.length ? '<span class="bk-badge bad">Problem</span>' : b.phase === "now" ? '<span class="bk-badge now">Now</span>' : b.phase === "past" ? '<span class="bk-badge">Past</span>' : '<span class="bk-badge ok">Confirmed</span>';
        var pe = b.el.querySelector(".bk-problems");
        if (!pe) { pe = document.createElement("div"); pe.className = "bk-problems"; b.el.insertBefore(pe, b.el.querySelector(".bk-actions")); }
        pe.innerHTML = pr.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + (pr.length ? "<div><b>Please change or delete this booking.</b></div>" : "");
      });
      var show = all.filter(function (b) {
        var okTab = state.tab === "all" || (state.tab === "past" ? b.phase === "past" : state.tab === "today" ? b.date === t : b.phase !== "past");
        return okTab && (!state.q || (b.user + " " + b.note).toLowerCase().indexOf(state.q) >= 0);
      });
      var asc = state.tab !== "past";
      show.sort(function (a, b) { var k = (a.date + pad(a.from)).localeCompare(b.date + pad(b.from)); return asc ? k : -k; });
      all.forEach(function (b) { b.el.style.display = "none"; });
      var last = "";
      show.forEach(function (b) {
        if (b.date !== last) { var hd = document.createElement("h4"); hd.className = "bk-dayhead bk-js"; hd.textContent = (b.date === t ? "Today · " : "") + (b.date ? nice(b.date) : "No date"); list.appendChild(hd); last = b.date; }
        b.el.style.display = ""; list.appendChild(b.el);
      });
      if (!show.length) { var e = document.createElement("p"); e.className = "bk-empty bk-js"; e.textContent = state.tab === "upcoming" ? "No upcoming bookings for this station." : "No bookings match these filters."; list.appendChild(e); }
      var up = all.filter(function (b) { return b.phase !== "past"; }).length, now = all.filter(function (b) { return b.phase === "now"; }).length;
      var bad = all.filter(function (b) { return /bk-bad/.test(b.el.className) && b.phase !== "past"; }).length;
      document.getElementById("bk-summary").innerHTML = "<b>" + up + "</b> upcoming · <b>" + now + "</b> running now" + (bad ? ' · <span class="bad">' + bad + " with a problem</span>" : "");
      Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-t") === state.tab); });
    }
    var qi = document.getElementById("bk-q"); if (qi) { qi.oninput = function () { state.q = qi.value.toLowerCase().trim(); draw(); }; }
    Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.onclick = function () { state.tab = b.getAttribute("data-t"); draw(); }; });
    var add = document.getElementById("bk-add"); if (add) { add.href = "edit.php?" + selfQuery(); }
    if (document.querySelector(".pagination, .paging")) {
      var hint = document.getElementById("bk-pagehint");
      hint.innerHTML = 'Some bookings are on other pages. <a href="view.php?' + selfQuery() + '&perpage=1000">Show all bookings on one page</a>.'; hint.hidden = false;
    }
    draw();
    if (AVAIL_DB) { fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); draw(); }).catch(function () {}); }
  }

  /* ---------------- add / edit page ---------------- */
  function formPage(form) {
    var t = document.getElementById("st-formtitle"); if (t) { t.textContent = "Book: " + STATION; }
    var fromSel = form.querySelector(".bkf-from select"), toSel = form.querySelector(".bkf-to select");
    var dsel = function (part) { return form.querySelector('.bkf-date select[name$="_' + part + '"]'); };
    var box = document.getElementById("bk-check"), others = null, board = null, rid = +param("rid") || 0;
    var pd = param("date").match(/^(\d{4})-(\d{2})-(\d{2})$/), pf = +param("from"), pt = +param("to");
    var setSel = function (sel, fn) { if (sel) { Array.prototype.forEach.call(sel.options, function (o) { if (fn(o)) { sel.value = o.value; } }); } };
    if (pd && !rid) { setSel(dsel("year"), function (o) { return +o.value === +pd[1]; }); setSel(dsel("month"), function (o) { return +o.value === +pd[2]; }); setSel(dsel("day"), function (o) { return +o.value === +pd[3]; }); }
    if (pf && !rid) { setSel(fromSel, function (o) { return hour(o.text) === pf; }); }
    if (pt && !rid) { setSel(toSel, function (o) { return hour(o.text) === pt; }); }
    function current() {
      var y = dsel("year"), m = dsel("month"), d = dsel("day");
      return { date: y && m && d ? iso(+y.value, +m.value, +d.value) : "",
        from: hour(fromSel ? fromSel.options[fromSel.selectedIndex].text : ""), to: hour(toSel ? toSel.options[toSel.selectedIndex].text : "") };
    }
    function check(final) {
      var b = current(), p = problems(b, others || [], board);
      if (b.date && (b.date < today() || (b.date === today() && b.from < new Date().getHours()))) { p.unshift("That time has already passed."); }
      var day = others && b.date ? others.filter(function (o) { return o.date === b.date; }).sort(function (a, c) { return a.from - c.from; }) : [];
      var dayTxt = day.length ? "<div class='bk-dayline'>Other bookings on " + nice(b.date) + ": " + day.map(function (o) { return hh(o.from) + "–" + hh(o.to) + " (" + esc(o.user) + ")"; }).join(", ") + "</div>" : "";
      if (others === null) { box.className = "bk-checkbox wait"; box.innerHTML = "Checking existing bookings…"; return p; }
      if (p.length) { box.className = "bk-checkbox bad"; box.innerHTML = "<b>" + (final ? "Not saved: " : "") + "please fix this first</b>" + p.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + dayTxt; }
      else if (b.date && !isNaN(b.from)) { box.className = "bk-checkbox ok"; box.innerHTML = "<b>✓ " + esc(STATION) + " is free on " + nice(b.date) + ", " + hh(b.from) + "–" + hh(b.to) + ".</b>" + dayTxt; }
      else { box.className = "bk-checkbox"; box.innerHTML = "Choose a date and time."; }
      return p;
    }
    [fromSel, toSel, dsel("day"), dsel("month"), dsel("year")].forEach(function (s) {
      if (s) { s.addEventListener("change", function () {
        var toH = toSel ? hour(toSel.options[toSel.selectedIndex].text) : NaN, frH = hour(fromSel.options[fromSel.selectedIndex].text);
        if (s === fromSel && toSel && (isNaN(toH) || toH <= frH)) { setSel(toSel, function (o) { return hour(o.text) === frH + 1; }); }
        check(false);
      }); }
    });
    var f = form.closest("form");
    if (f) { f.addEventListener("submit", function (ev) {
      if ((ev.submitter && /cancel/i.test(ev.submitter.name || "")) || others === null) { return; }
      if (check(true).length) { ev.preventDefault(); box.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }); }
    check(false);
    var jobs = [fetchPage(selfQuery()).then(function (doc) {
      var all = readBookings(doc);   // a booking that clashes with an earlier one is marked "Problem" – it doesn't block others
      others = all.filter(function (o) { return o.id !== rid && !all.some(function (e) { return e.id < o.id && overlaps(e, o); }); });
    })];
    if (AVAIL_DB) { jobs.push(fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); }).catch(function () {})); }
    Promise.all(jobs).then(function () { check(false); }).catch(function () {
      others = []; check(false);
      box.insertAdjacentHTML("beforeend", "<div class='bk-dayline'>Couldn't load the other bookings – conflicts will be flagged on the list page.</div>");
    });
  }

  function run() {
    var list = document.querySelector(".bk-list"); if (list) { listPage(list); }
    var form = document.querySelector(".bk-sform"); if (form) { formPage(form); }
    if (!list && !form && document.getElementById("st-head")) { header(); }
  }
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", run); } else { run(); }
})();
