/* Digital Factory Lab – booking database for ONE station (Moodle Database JavaScript template).
   List page: station header, "Book this station", bookings grouped by day, conflict flags.
   Add/Edit page: checks the time against the other bookings of this station before saving.
   Who may book is decided by Moodle permissions (role "Station booker"), not by this script. */
(function () {
  /* ======== settings ======== */
  var STATION = "MiR with UR5";          // name shown on this page (also used by the overview)
  var LOCATION = "C0.1", ROOM = "";
  var OVERVIEW_DB = 2323;             // id of the "Station overview" database (number after d= in its URL); 0 = no back link
  var AVAIL_DB = 0;                // id of the "Robot availability" database; 0 = don't check the availability board
  var OPEN = 8, CLOSE = 18, MAX_HOURS = 4;
  var DAYS = [1, 2, 3, 4, 5];      // bookable weekdays, 1 = Monday
  var IMG = "data:image/webp;base64,UklGRtAOAABXRUJQVlA4WAoAAAAQAAAATAAAnwAAQUxQSHgHAAAB8IZt2+HW//9dM5OkTW23i/Wybdu2bdu2bdv2q162UaVtirQpwpnrQaeZyT19+n5vETEB8L8R60xeuGH3gRE2pYJHeJtYTUq6+s/6Lp6S89j6KSW1kDWzHCI+9ZTacrR8oKQc6q3KEDCZLOfIinYKBcMo7N2DwnsdfKtHoYOJqnMjNTn+xX+PHz179T0lh0XhsX4kdfuBVtTlZX89UAkIrpmCoueronatW99aDiRvRpHZ5Gsrp4xccHBXJJCseCFO6sGhEc72LkH1OjaxBwCKGLtXImi/7qnOAADIlUobOVWMIoW+I0i1NtIReCmZTQlADCwRoNlcFkqmZHK5jAGyAt5Ykne8ClhIMbLiNA1A0cRA8IUSitaG0mApI5fJ5TKGIQwqqvnibMHyYgqFXMZQQFEEwXW+tAqCGJpmZDKaAiCqF8uDQwXQMoaiKEZGA2HULr7P/pYBTVMURTNAvMcHnrwIAUABAEWTB2d4tDWFSHYSD44pJZw/8RwuJeA8zweHUmI+T0ENIZRUuvDgOAEUI5XgbJ4TpYTtK553DpbRMqnAdh5tdQGMZFqai+EYAXJKKi4feD4HW2ZLSwUO8eAYiygb6WzkW2qZQjrdDDx/O1pC28ok0zqbB5OWzVw4Z3IXHwCKsXdgeCh7VzlZ8lNoOadaogBaaV9M7l+ra0PCyv4SgIgDgaIpYDzqDxw3pHVFmqwWRcK2AlBOkd0nThnYula4J0XWaBR+x6/1kuOXds3r3bBqRJgbkD1VhF//JWZpcpM/vYx+cu/q2S1zRnRpVjM00NlWRsIwkyAuP0uVnqVJvr5h3eEENSJrNKMxV/Up4b87J1aNaxcut0bTS4mC2LzUf6lp6X+e3P2Snp34T5VvNGhzCvKzY0+evP/XgH9CrCBbnZSYrhOiSf6Xkq0t0Kr//EjN1ud/v7F6/MjRfTpU9vGrfjQX1aHitVl7LffB1ttfP8U9i/9t5MN8VXaBLj8nLTVPr02MOb24Y5ivp5uLm7ebo7KHGlVlRSv3mdO9P3FhSeMyng7KykklGPML8/MLDYYC1du7G0a2CPf18fX18fIspjyBaeI1K9Rk5H2e6UMBAFTLKAFZg8moVSd9vHtuYaPynm5unv5BAb4+Pl6udsxCzCgnWv38Io1Wp744NMLT0We2qSTOkJ+VnlPw6/n3L6/PtHd1cfP2Dwjw9/N0smFWYXpZ0cr+MSe+ex6XblC/fpyQXMjxsbq83CIjInKIyK1wdXJ28/b19/f3dlIqd2BakGjKS6jLHOMe2WfdzbfvX2fojfoivclo0PxO1LHIzyaMC3Wyd3Jxc/fwdFE67LcGzEB87gIAtF+XubtjYqPi/mVrTZzZzHFoYdrJOQObVPQPLOPv7WC7D1Ot0MWEW4GxsbV3D6zXb9uxywm5Bt3ndxoUzOb+jvvvv4dRl/tcxGQ/8Rro8Jkzbe/m6R7cb9enXBY5o/HRjRRhFuYmYaKveGEqvCMDZbkOWxPykZdjWbQiayjAP97ieX/G6+C65W0hEmrI1+FPD/Fc3+BtCEpHYk0ZevzhLp5DNEbL3H6Sw+lY/OYmnu0T/KBUvien+CcX8RQP8Zuj4jVZn60gu4O/XWXxZL1zFI+6jEledBRZr+3FgzOoCoTHZL1zsMIJzAyGa4Q5WuEAaqvBKcKcrLAT9Q3hAFnvHa2wHtk2sJWst3ZWmInYC1aTxOEbpRUGcTgalhLEmfGNrRXaFOAMmEWQMRffKq1QNwfnwUiCVPH4wd4KEWm4FPoQ9PopfnG2QuAP3AC9SOE+Lu12Fb+7WsE9AU9Cd1LO1QprcRl/WcPtOd6A8nFksN/uHV0Vgz9dgKLE8nyOD2lw77UpKs1oNdTn5hcasej6XD8Q2/0RxikBAGxrXLVe4V8Ni8VXifcEP7oC0A5O61gCCjnkTT/WTS6O0yP86QPg3GZbOhL9N0gc+hoa2tOtzuUg2W86gsh7EK9fL0TC70aA2PM5DonX73AUS7HCjMRzulv+IvmPeceRZ9K8qCxOrad6lCCX8rAzUGJsRkkW/Iw/3xCE+63Okkg+i+8DBbknoIR1TQUFJEpJ3dBWiH2UhFRL6wTSAmyfSkc/XmEjA4H0GengPUcQPsconZwIEer9kU5WmAjBMRwrlS8eInTOQoOBPLbYRhBxNyJrIs6sMSNGeYtxEDkkX//55bMDoSDm4CLOaCJOe76lhwJEpRvt+65hyeK+rKkI4tPlev9HVMqMMHuwbtApcnSHQ8H6btGkvOtEAYnjzMK4Im1uVpYJETX/OD7tag8gM/SDMFb988OrPybElDXbC3keNgBCad/TAjhETv31dXwaoil98fRMRFTPUAIxDlMtuzz1WKr+9YmtGz4jsoa1nb4g3q0C5FK049j7eSXpB5etMf7knNZ1+31DRDw0oM/sPnZAuKLy9PtaHsPQiuXCu/ZoWGeDDhHZvS0cQZLyylOeFSIaxgd7uYe0atnoICJi1mAnkKyi3rZna+oGOimda7ZtudOMiPvdQNIyWsbQNOPoU6bzwzzzNT8oHSnGLrh5Cyf4PyMBVlA4IDIHAAAwIwCdASpNAKAAPnk2lEckoz+hKlj88/APCWUA0WWViq7eLngNNJ9AD9QOs+8p3NAP5h+HfgJ/ivCXxje983DEvP+xysr+AF6k7+va/5r4ntLdj49WP/N8lX1T7BP60dFH7IH7VJPehbZeBFSyROIg9l94/EAw/hzLEhiJPeQzw+b6Jv4ALdnaTkgDDMSFFoksLj3QI7/mC3hzqJvjA3O4aGUKKYnPA3DfmTpgMNWAQaSXAHIEp+YP38MCs9IrXhakJHDPR19GU9ledl4SBBAAmjVzl+9fGF7D1RhZVysxed2ZO+3teZ/d+o6hVFz/8fwVW7G3ynJcFJKzFEsGZXIvT/+635Y0G+TLcU42lZTstdYcIb0RzuY9pV+8B7rbwADgAAD+/PhAA6cKs/Tq63fiKYrdkGGo0A9trIKUg+SsrP+abzfbbo2isaHx9IG04OWMcuBQ2TAb/8jjwMhJKg3NhtTAiMMbbypfcT8ndX+aIw2N+zehFFVvU4YJe9xfThToiWJkZBWjbWuM9xpfrrdrQMHnUFVkAafjM+Eh57/50gF/qHARYfhAjVx1vbWYdP1eOQzJQ68o9XJgt/Gw9P1lRjyKidhLyk4LszFjvcRofXKYhV7Wkptg2ylLraM6lzP70ufIpeC42xqkQGUGsLbp7jQlNvfWo+KJW1euMw/WiiQggBPIL6XCDIsjIQ9mhwNp9rhqsezVtOzKVPjqP6PXegre/Dy/ijYQOP2up1aWcZH96L8x2jT8WuopH3nUKWFWItOqDO78M+CCVm5vmr1Tjlf7AOb94s/Wv/R2f2n09TTR4ejA4+l2qiHSaPlBx0JMcO2cLrPKpV+/9s9/3z9F925rFvkXEb+4fk3Pn++hj0Tsp1w9vMiVZxWiqx4SasUF2roeQxC+HdYO+9GMKAZb6BMvZkrOv+ljMSAH9yip9KmqFZG0s1EcS7Nz1m5OOrCRB2CfDBGKjxFDkyykYfnmXoDOKaG0z1GQyf5WNGi9xOZddxnjLGTjYwg+C98Pj/IYmVCpqmOO0KxvVMDf+6qurFE1YW6AMm6wVr89t6DFCTP/R8JioQgNLUTJduDB+goxijDwOLBGF0pLIxDkSDwKRKmT7PiAfYJaiifNkp7GsZVsijKHTCszMaXsWDBA+bG5O3eGQXtAk9kLgzCpD8Ic51gbtAC88lVG5XiN7zrVHGUnEij/M+w53N15eKubxJHmJz1rkImzAGU3G66VkBmvlgzUMtQ4EZudUy/Co0z6ewz2/2nzwpZbq6jsAh+HsC8+93sv38DA0shL/Ka5qR0U2PVESwZoUpre+DTAjUnbHzuM8+aiLMGUcMqiq243TGiLlqsbjwq2dO/zI1qUJnrZi7JAyoEmAEK+mf0kAk1WBcgCeiZqSDaJP65/pl0CKkTz8/vH4foUoIS05kQ2fdf33qER/8gTBIENS+umb7wPlDn1IneEU9r2lHREEpAeS0Nr2RlwrwYDKaUcBGZ/YLEi3WhKYpjg/qyZXLLqOz3N6McWbJX2jUGErptOzG8zblloJ6kSVOr8MBtBQbl0B11mc1fJiLHTtn3BhLIcjdBeQm0rFxxZZ6gWPoG3SMWP43fTeQLM3o678kiujUDBUbr6oOIjD+9waIJgN9gJa8Lf+L0mNU+IbQBqan7va0zVvwxKp9dJN6clKnzHJTvTZ9gxlKDGa7dMcO3AVDKtGFXcAauJi19uSo+JHmppYRPoSuXPXKAe4VdbQ6yf+VYoZ/eYuyfqI2/Bh0r86MeSCMQRr3tGu6oPqOJkozJfMpIFol3YoWwxt84s7VMnNEIo+LJwF7ose6X8IpOe9rDHRRjKUoBj3hW2161Q9GiruHTYgeIowqB6bITHsD2UovGMvL/z0yDNNPRRZyVxKhNLSg+tUibpkOTsIsKuAzGHznYtdlXeGkrN1u7O/keiaJ2oOWlTBtFMjX4xOOUTA8lWarqZjOKTHxwn5g3cQPxKg4lFDjilDOFO7OJPkh1goJ1zBxBvu66qDsXrbArLIL/Fugdqhao565q3YXFRZv3ozVfdhBlU0+vNq4c3ktFMOvScRgjLh/9vGzCbpBvtTYCUUU0jojkfOVshaE2eHGXr7w7MstxCSmLzGl/MIHJCj6Mnc2mv6WwOGGwIoXEeynbJiHB6dsTKBEI9BAZ8cAu/ycfv2DSlRX0rWpoK5MbpwBDTbHek6YZvTuu4iJWfwlnCBRDEw16J3dO1eATTRJjXvvl2y5sdcks7U5bSpFUKoFSkQjtfVHVpGGRRHhWLUJAp+MztHeXa9Q99fUNoRukk+3JKANngfXjyFkTZ3W1CMCMDUJHEqhNpi8gr2aM/ll6Nwi4Zh279p8yakvtcHEhC0jB+xAJpReBUQ+mxUpsjd/8pZFIvGMy0RBwjaeFn93Rvd9YB0+tKdXwCwumN9krgrofNZoD4B1I5qR+/1+wkCOB5/4AAAAA=";               // picture of the station: image address or data: image ("" = none)
  /* ========================== */

  var MONTHS = { january: 1, jan: 1, januar: 1, "jänner": 1, february: 2, feb: 2, februar: 2, "feber": 2, march: 3, mar: 3, "märz": 3, "mär": 3,
    april: 4, apr: 4, may: 5, mai: 5, june: 6, jun: 6, juni: 6, july: 7, jul: 7, juli: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9,
    october: 10, oct: 10, oktober: 10, okt: 10, november: 11, nov: 11, december: 12, dec: 12, dezember: 12, dez: 12 };
  var WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function txt(el) { return el ? el.textContent.replace(/\s+/g, " ").trim() : ""; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m) + "-" + pad(d); }
  function today() { var d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function dow(s) { var p = s.split("-"); return (new Date(+p[0], +p[1] - 1, +p[2]).getDay() + 6) % 7 + 1; }
  function nice(s) { var p = s.split("-"); return WD[dow(s) - 1] + ", " + p[2] + "." + p[1] + "." + p[0]; }
  function hh(h) { return pad(h) + ":00"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseShown(s) {   /* "18 November 2026" (English) or "18. November 2026" (German) */
    var m = s.toLowerCase().match(/(\d{1,2})\.?\s*([a-zäö]+)\.?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]]) { return iso(+m[3], MONTHS[m[2]], +m[1]); }
    m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) { return iso(+m[3], +m[2], +m[1]); }
    m = s.match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : "";
  }
  function hour(s) { var m = String(s).match(/(\d{1,2})/); return m ? +m[1] : NaN; }
  function param(n) { var m = location.search.match(new RegExp("[?&]" + n + "=([^&]*)")); return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; }
  function selfQuery() { return param("d") ? "d=" + param("d") : "id=" + param("id"); }
  function overlaps(a, b) { return a.date === b.date && a.from < b.to && b.from < a.to; }

  function readBookings(root) {
    return Array.prototype.map.call(root.querySelectorAll(".bk-e"), function (e) {
      return { el: e, id: +e.getAttribute("data-id") || 0, date: parseShown(txt(e.querySelector(".bk-date"))),
        from: hour(txt(e.querySelector(".bk-from"))), to: hour(txt(e.querySelector(".bk-to"))),
        user: txt(e.querySelector(".bk-user")), note: txt(e.querySelector(".bk-note")) };
    });
  }
  function readBoard(root) {
    var out = null;
    Array.prototype.forEach.call(root.querySelectorAll(".tdf-card"), function (c) {
      if (txt(c.querySelector(".tdf-name")) !== STATION) { return; }
      var u = txt(c.querySelector(".tdf-until")).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      out = { status: txt(c.querySelector(".tdf-status")), person: txt(c.querySelector(".tdf-person")).replace(/^@\s*/, ""), until: u ? iso(+u[3], +u[2], +u[1]) : "" };
    });
    return out;
  }
  function fetchPage(query) {
    return fetch("view.php?" + query + "&perpage=1000", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.text(); })
      .then(function (h) { return new DOMParser().parseFromString(h, "text/html"); });
  }
  function problems(b, others, board) {
    var p = [];
    if (!b.date) { p.push("Choose a date."); return p; }
    if (isNaN(b.from) || isNaN(b.to)) { p.push("Choose a start and end time."); return p; }
    if (b.to <= b.from) { p.push("The end time must be after the start time."); }
    else if (b.to - b.from > MAX_HOURS) { p.push("A booking can be at most " + MAX_HOURS + " hours."); }
    if (b.from < OPEN || b.to > CLOSE) { p.push("Bookings are possible between " + hh(OPEN) + " and " + hh(CLOSE) + "."); }
    if (DAYS.indexOf(dow(b.date)) < 0) { p.push("The lab is closed on " + nice(b.date) + "."); }
    if (board && (board.status === "Busy" || board.status === "Occupied") && !(board.until && b.date > board.until)) {
      p.push(STATION + " is " + (board.status === "Occupied" ? "out of service" : "assigned to " + (board.person || "someone")) + (board.until ? " until " + nice(board.until) : "") + " (availability board).");
    }
    others.forEach(function (o) { if (overlaps(b, o)) { p.push("Already booked " + hh(o.from) + "–" + hh(o.to) + " by " + (o.user || "someone") + "."); } });
    return p;
  }
  function header() {
    var el = document.getElementById("st-head"); if (!el) { return; }
    var place = [LOCATION, ROOM].filter(function (v) { return v; }).join(" · ");
    el.innerHTML = (IMG ? '<div class="st-img"><img src="' + IMG + '" alt=""></div>' : "") +
      '<div class="st-headtxt"><h3 class="bk-h">' + esc(STATION) + "</h3>" + (place ? '<p class="bk-sub">' + esc(place) + "</p>" : "") +
      '<p class="bk-sub">Bookable ' + WD[DAYS[0] - 1] + "–" + WD[DAYS[DAYS.length - 1] - 1] + ", " + hh(OPEN) + "–" + hh(CLOSE) + ", max. " + MAX_HOURS + " h per booking.</p></div>";
    var back = document.getElementById("st-back");
    if (back) { if (OVERVIEW_DB) { back.href = "view.php?d=" + OVERVIEW_DB; } else { back.style.display = "none"; } }
  }

  /* ---------------- list page ---------------- */
  function listPage(list) {
    header();
    var all = readBookings(document), t = today(), h = new Date().getHours(), board = null;
    var state = { tab: "upcoming", q: "" };
    var phase = function (b) { return !b.date ? "upcoming" : b.date < t || (b.date === t && b.to <= h) ? "past" : b.date === t && b.from <= h ? "now" : "upcoming"; };
    function draw() {
      Array.prototype.forEach.call(list.querySelectorAll(".bk-js"), function (x) { x.remove(); });
      all.forEach(function (b) {
        b.phase = phase(b);
        var pr = problems(b, all.filter(function (o) { return o !== b && o.id < b.id; }), board);
        b.el.className = "bk-e bk-" + b.phase + (pr.length ? " bk-bad" : "");
        b.el.querySelector(".bk-flag").innerHTML = pr.length ? '<span class="bk-badge bad">Problem</span>' : b.phase === "now" ? '<span class="bk-badge now">Now</span>' : b.phase === "past" ? '<span class="bk-badge">Past</span>' : '<span class="bk-badge ok">Confirmed</span>';
        var pe = b.el.querySelector(".bk-problems");
        if (!pe) { pe = document.createElement("div"); pe.className = "bk-problems"; b.el.insertBefore(pe, b.el.querySelector(".bk-actions")); }
        pe.innerHTML = pr.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + (pr.length ? "<div><b>Please change or delete this booking.</b></div>" : "");
      });
      var show = all.filter(function (b) {
        var okTab = state.tab === "all" || (state.tab === "past" ? b.phase === "past" : state.tab === "today" ? b.date === t : b.phase !== "past");
        return okTab && (!state.q || (b.user + " " + b.note).toLowerCase().indexOf(state.q) >= 0);
      });
      var asc = state.tab !== "past";
      show.sort(function (a, b) { var k = (a.date + pad(a.from)).localeCompare(b.date + pad(b.from)); return asc ? k : -k; });
      all.forEach(function (b) { b.el.style.display = "none"; });
      var last = "";
      show.forEach(function (b) {
        if (b.date !== last) { var hd = document.createElement("h4"); hd.className = "bk-dayhead bk-js"; hd.textContent = (b.date === t ? "Today · " : "") + (b.date ? nice(b.date) : "No date"); list.appendChild(hd); last = b.date; }
        b.el.style.display = ""; list.appendChild(b.el);
      });
      if (!show.length) { var e = document.createElement("p"); e.className = "bk-empty bk-js"; e.textContent = state.tab === "upcoming" ? "No upcoming bookings for this station." : "No bookings match these filters."; list.appendChild(e); }
      var up = all.filter(function (b) { return b.phase !== "past"; }).length, now = all.filter(function (b) { return b.phase === "now"; }).length;
      var bad = all.filter(function (b) { return /bk-bad/.test(b.el.className) && b.phase !== "past"; }).length;
      document.getElementById("bk-summary").innerHTML = "<b>" + up + "</b> upcoming · <b>" + now + "</b> running now" + (bad ? ' · <span class="bad">' + bad + " with a problem</span>" : "");
      Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-t") === state.tab); });
    }
    var qi = document.getElementById("bk-q"); if (qi) { qi.oninput = function () { state.q = qi.value.toLowerCase().trim(); draw(); }; }
    Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.onclick = function () { state.tab = b.getAttribute("data-t"); draw(); }; });
    var add = document.getElementById("bk-add"); if (add) { add.href = "edit.php?" + selfQuery(); }
    if (document.querySelector(".pagination, .paging")) {
      var hint = document.getElementById("bk-pagehint");
      hint.innerHTML = 'Some bookings are on other pages. <a href="view.php?' + selfQuery() + '&perpage=1000">Show all bookings on one page</a>.'; hint.hidden = false;
    }
    draw();
    if (AVAIL_DB) { fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); draw(); }).catch(function () {}); }
  }

  /* ---------------- add / edit page ---------------- */
  function formPage(form) {
    var t = document.getElementById("st-formtitle"); if (t) { t.textContent = "Book: " + STATION; }
    var fromSel = form.querySelector(".bkf-from select"), toSel = form.querySelector(".bkf-to select");
    var dsel = function (part) { return form.querySelector('.bkf-date select[name$="_' + part + '"]'); };
    var box = document.getElementById("bk-check"), others = null, board = null, rid = +param("rid") || 0;
    var pd = param("date").match(/^(\d{4})-(\d{2})-(\d{2})$/), pf = +param("from"), pt = +param("to");
    var setSel = function (sel, fn) { if (sel) { Array.prototype.forEach.call(sel.options, function (o) { if (fn(o)) { sel.value = o.value; } }); } };
    if (pd && !rid) { setSel(dsel("year"), function (o) { return +o.value === +pd[1]; }); setSel(dsel("month"), function (o) { return +o.value === +pd[2]; }); setSel(dsel("day"), function (o) { return +o.value === +pd[3]; }); }
    if (pf && !rid) { setSel(fromSel, function (o) { return hour(o.text) === pf; }); }
    if (pt && !rid) { setSel(toSel, function (o) { return hour(o.text) === pt; }); }
    function current() {
      var y = dsel("year"), m = dsel("month"), d = dsel("day");
      return { date: y && m && d ? iso(+y.value, +m.value, +d.value) : "",
        from: hour(fromSel ? fromSel.options[fromSel.selectedIndex].text : ""), to: hour(toSel ? toSel.options[toSel.selectedIndex].text : "") };
    }
    function check(final) {
      var b = current(), p = problems(b, others || [], board);
      if (b.date && (b.date < today() || (b.date === today() && b.from < new Date().getHours()))) { p.unshift("That time has already passed."); }
      var day = others && b.date ? others.filter(function (o) { return o.date === b.date; }).sort(function (a, c) { return a.from - c.from; }) : [];
      var dayTxt = day.length ? "<div class='bk-dayline'>Other bookings on " + nice(b.date) + ": " + day.map(function (o) { return hh(o.from) + "–" + hh(o.to) + " (" + esc(o.user) + ")"; }).join(", ") + "</div>" : "";
      if (others === null) { box.className = "bk-checkbox wait"; box.innerHTML = "Checking existing bookings…"; return p; }
      if (p.length) { box.className = "bk-checkbox bad"; box.innerHTML = "<b>" + (final ? "Not saved: " : "") + "please fix this first</b>" + p.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + dayTxt; }
      else if (b.date && !isNaN(b.from)) { box.className = "bk-checkbox ok"; box.innerHTML = "<b>✓ " + esc(STATION) + " is free on " + nice(b.date) + ", " + hh(b.from) + "–" + hh(b.to) + ".</b>" + dayTxt; }
      else { box.className = "bk-checkbox"; box.innerHTML = "Choose a date and time."; }
      return p;
    }
    [fromSel, toSel, dsel("day"), dsel("month"), dsel("year")].forEach(function (s) {
      if (s) { s.addEventListener("change", function () {
        var toH = toSel ? hour(toSel.options[toSel.selectedIndex].text) : NaN, frH = hour(fromSel.options[fromSel.selectedIndex].text);
        if (s === fromSel && toSel && (isNaN(toH) || toH <= frH)) { setSel(toSel, function (o) { return hour(o.text) === frH + 1; }); }
        check(false);
      }); }
    });
    var f = form.closest("form");
    if (f) { f.addEventListener("submit", function (ev) {
      if ((ev.submitter && /cancel/i.test(ev.submitter.name || "")) || others === null) { return; }
      if (check(true).length) { ev.preventDefault(); box.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }); }
    check(false);
    var jobs = [fetchPage(selfQuery()).then(function (doc) {
      var all = readBookings(doc);   // a booking that clashes with an earlier one is marked "Problem" – it doesn't block others
      others = all.filter(function (o) { return o.id !== rid && !all.some(function (e) { return e.id < o.id && overlaps(e, o); }); });
    })];
    if (AVAIL_DB) { jobs.push(fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); }).catch(function () {})); }
    Promise.all(jobs).then(function () { check(false); }).catch(function () {
      others = []; check(false);
      box.insertAdjacentHTML("beforeend", "<div class='bk-dayline'>Couldn't load the other bookings – conflicts will be flagged on the list page.</div>");
    });
  }

  function run() {
    var list = document.querySelector(".bk-list"); if (list) { listPage(list); }
    var form = document.querySelector(".bk-sform"); if (form) { formPage(form); }
    if (!list && !form && document.getElementById("st-head")) { header(); }
  }
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", run); } else { run(); }
})();
