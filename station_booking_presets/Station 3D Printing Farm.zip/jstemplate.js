/* Digital Factory Lab – booking database for ONE station (Moodle Database JavaScript template).
   List page: station header, "Book this station", bookings grouped by day, conflict flags.
   Add/Edit page: checks the time against the other bookings of this station before saving.
   Who may book is decided by Moodle permissions (role "Station booker"), not by this script. */
(function () {
  /* ======== settings ======== */
  var STATION = "3D Printing Farm";          // name shown on this page (also used by the overview)
  var LOCATION = "C0.1", ROOM = "";
  var OVERVIEW_DB = 2323;             // id of the "Station overview" database (number after d= in its URL); 0 = no back link
  var AVAIL_DB = 0;                // id of the "Robot availability" database; 0 = don't check the availability board
  var OPEN = 8, CLOSE = 18, MAX_HOURS = 4;
  var DAYS = [1, 2, 3, 4, 5];      // bookable weekdays, 1 = Monday
  var IMG = "data:image/webp;base64,UklGRnIYAABXRUJQVlA4WAoAAAAQAAAAcAAAxwAAQUxQSAcLAAAB70c2QKH+/xx7RGSoyYPMJxi1jSSpUtO/av6E59xFENH/CdDL9oW/yY1/BidmEIoNYAM4myxgldAksSWpk8RJyGQDhHEG6b5InoxNr6ouVHWhKqAPVFV9JF3tYQ3/P0OSpF+kij2NmcZ0j421bdu2bdu2vWf7bm3b3h0s2l09hS4lIv4vMksZUa/uTURMAP6P2oQHai7QTE0IU2siJADTnD5nWlfzgBCkFUuJGU0DhMhWfcem0lrzAB24a/6Uncoxo2mIzkOE6Hl8H9NsGtjQ4Qztq3OteUQNBqBks2ZBWJkGAMfUmgUwkPK5Ub1ZMJSKPh1aswA828eE0SQYGIgIYF6zIIAYA2CYWpMAB4EEoFFzWHjptd3EdCKAXNEMNl12zSW/mVkWXAA86zSBOV9zYLu/rcuJAC6E+rQ/cA5gnb/NdYnD0ZvAJiXXBYBpnRoR3MmG+n7N7eVl+KOMIDojypuVsnnJCWAaQDFNeYfx7+/NTQIBgEZwE6S8bdBW+BkffuEDkRtVXmITxzq/4F3xLYRPoJ2rrrtn4szrZn3+ogvykWEprzOunVnGf7mADjCQqbmqS+pifYhXweEnEhCqM+CJaH4AIki4GqlOh0XIjoP7iEiQUB0ABofD9YGY5pHqNAAQBCcAZLVA9QRyAcCrYFhCdQLMgMYgfEyDx0l1BDAQYPvAyMsJ1XkAoAHRACIvrTzhY7xztyBu9XaozvXp3p6LfUR8/V13Vx4HoLHZ8GuGNvbpB6rjIoAFmVQY/FR1ggAYOipyzqF6TwBgTKvgZjzluRyAHmFBzM3mmoRVAdHN19x9uuIcD4CZQLDWdcyu/3ztSKY016eZFRgANvPqVqV5HATdYkHBUUtpM9vBYCRqICh9UhQEplF1ircJDGjVMELVkNo4ACwsnH2UW4VQGw9o7X9yDFVytXnCF+OsT6vC402gTbv4HlYNKc3lvp21TeM5qqT41pgP/xw6yEyWRSKgf22lmXoAfmhNxoj0gK83VFp/OkgwhorlE3+ntqeCql125rNQOj1YqOXev0+dvjypsLaTTrFqeXHWPND7j89XyMzbzttqihHUsfOf7j/crAVwTXD+H0MZCz/h3B544ea9Z5lY+42/b4/aV7y/RXeJ88wcZeyxBmD0AMh8sWzH3iJqF7/fpvXE9U4CNn1XFTaqJqoDnRw9+u/3nAqc/2qxP6+EYnV11dsvW37NIe2A5/Blr22qKcBuGGX2WZxE5ZMv3FQ+0TCvvD6qjmzkSMcbRi5q/fxz2UKo1eSdVQKgWZFYa0di/z23nRw61jBrWk24vuP4q/u6utpaoxGDc+fLa2bXEE1aDdrilUZBq80jEzUO/uPWKjY6fXbLZ8eVG2KdsfGS3rjWiPq65WIhNTaRT9tp6jqqBx8sqbTrQcAijgazeN+8pQuXTu+IhOehP4/mykVHIHDzv3ThV5MqMADDbqOCIy1zlyyev6AvycJwwe2o/tJrsO7+FdoBCISYxfsWzVuyZO6kRr2wh1Pd9Pe6cUwkqA+AHabgSPvci8uNEbs/W53+1vpY0BakAxgPH4Dbvq8k7HrgrnOrwzM7IFrBAOBIIQ497tdugP1LXd7axqvKeGMDMD0oDqBVCnz9pH7LWT7B6jKy2qqqOj/vxE8b5pOtkztarp1NZuEPF8gA8O/gz/2F1+PpPcinmbFIvG3yjud4LP1pW1cyZurkMgvYTg5YAeJfq6oSjq6RvvIcu3PylLbW1s4piWjU0lH7HpKwAG3l76oiV2Oe5nhJHY29WBIjIHFyb1XgTEMYXz/ODBGLWG1Tu6d0t8U3BDinSVcfWB2BheLOi9YNgRVp7enq7evtmdrVErMYAkWGQ86b9tu5IWzT+b1Tu3v62i1LQ61GmyHJX0/dpjFvb4C6EhgYiNWBWAh22m28IXhpKxDzEeNkVGIAiGVLPbWFMrbZksb8aX9U1hHsCruUTJBnjBX69LGsMyNbKLpdhhMZX75wZlwn5rM5N029HoJY/IjT123E2msbCQ0tsUTLDl3A8E+G0fbNRy+kzjtKGATt5/xTTy275JGMS1vM+2Xhsoc2iay2Rkd7YuHAdNcAA/DzqGAljzFzujYFQC6dJcF3uOv4RlT71E7AIzcYk3+7ZMoOXxAESuX2wntD/d88OmgB3609ur3x53UGRcfT/WyHj/a81wKAzFXPlaNpDsa65v0NQPG5HzQCsGE8DPq/AbRYhc3WSZ4IlMCAfJK5riVePVyPfn3CpNunTrMs4sZVX5CzPhfwl2cnRzWHAPTbSQCTKAYQYJphwG8ALL3pJT2G0lP92y9lAGkkym5svU05jf3zvf3mo470htmRYPB/PwTgkxtXgBhIbLrVjBD8EcAr37XAiZXe/fs5pzMwgGc+54/91ML+ZcPLbIzffRGfs2hwKG5qaywOKBuWVZx6aaEY1dsSRJj1wFawdBJzfvfMviGIAlgw+9c7fWN+dXomC0YA9LbN33mv9xvBBfxDt11zzJ77cwBn3Blgg9u850TUyvQYYIaAA+j7Qzo/XCiOa+0gAWLQvalP3fvofM2F7eFn6oAY4QAQRZC18fgHzLFqCaQQ6AA+GJ+59lz6k7eifJQHCB2l1HMrV49HqGe3xb0Y+VcPKiaCSt667BpOkNQAsNfzC7p1Oqwvy0U5CgApd9ZLZywuOOv/3ozAPunRc1iQGWTraZQ9IYsJYCkAsHnoFoIRGNBR3OjwomUzXtJbsbR09dpHBOkVvLGo65EkTEMwMSLG9CSgERLA6ZnTP9HsrNaL1Os9N+3WEmAEua7nxk0uiaFXYAAjJ8IAMAAwOw8ACqWIjnmPnzowtmZAPAi80HnIAkuSaKKCn1kMNUbnRNk4zIXb5adV55aHI90dsjjCJ0RAfb2BmWX7l9hLT5fJ/iEa9PwTc9ddkIakm/b4NK0Bgby0gjuFxE9rB5VLSROyHv2vDl+jf/5mYvUfAVhdiSCp104gjJl/PH300nyUuZPjCigjnKIUMSBQHjerE3I4IQnUEJ+OKsXosyU5SkHkhaFq/tPyZd+fWZTDDoIesoH/ZvoHTyrJ4QQxFiBysUg4fjESK0ZLphw8qGJu5dSucKTYJOKOIYdbAy9FjXCMsbjDPWJ1YdSoUg3hLds2Qxl15QKNtiWBy03ka3EKA8tWLP+5s2FlWQDB4hWolF35w4/L+1NxhjByaQjM9OX+9P3yoYKFELvScB2B35+MsNvSEAsqIPSONJXt8HnSTTSfvARctpwEnmyrwuc6smXD53myFcIneNPxXNkmwud6klExfEJI5uXC53HZCuHjnmz58LmuZK4dPoLkeSds0Z1WcMmKVrimHHzRbjokL4SKHXPJhgzS51mYkiZUWESYJw8oIR8q45wJFRRDhbajJxSQDddv2vYek28iXADGJqTLhA6ZtGz58CE7JllOAuRH5MrKgNKIVEUp4A7Z8nBHDmC0KAeBOUIWjExIAWK2Jw1SORkYEy6XB7mUBADKMiE3IoUtZEJpVIayIRXKw174fg/Zh4phe+YH6TBaCNfALVDgWDZM/HwoMZ0O0cNQ5MRoaD76lyowMRyS9GVQpz1KobgKKhXDxRD8fUwpwFCxYSvvgWrHcg1yzod6V6UbcxdUnEs14vU3lIT8SP1S10DRxZG6XQJle8N2fX7rqQsYLtTjmyeh9NF8bcULofhUtqaboPxcqobnvlQfOkarGroRzbAwUgU/H83RHvEqPIqmOVQM+PgfzQPDeQC5S9FMU2ngKjTXVROj/U0G+W783zYAVlA4IEQNAABQOgCdASpxAMgAPm0wkkckIqGhKjdLKIANiWVu3V7UwwoJxLusC76Xtup5gPNt9MP+R30veYMhl8if0b6APJT+1eCviq9s+4vrp4s+tzNZ+Jf5H969E++/4z6hfszdswBfoP9i7/fUv8C+ab6b/63xJfv//K9gX+d/5P/u+zL/i+Qz9E/2HsE/zr+0dcT90PZU/ZY9HlXF8+STBp+LoXp0g2wizrrg9GxqGp+7GNmy27ESpziEzxaI0JympIlIcqbujA2/soYLyI+RHUE279cTGTW7n1idA/gGPQhCbYPDQiOOoOeGPhvehXuGut7zHsD65U69pjPzSi0zAq3FYIGeuDEYh0QKNgrEhjXt5LcKvUaqd7GUAH1um4OX2jFEV3eEm5gHRtZiKC0EtGVXb/GNhIV/G0IbBx9xM+fqwRmVBX+3zusgHCnXids9WJ4b+X3oc+MnEW/gvVnm50bF1+gFb4iDXPMGan1F1NWNgQ5LvraJYv1MY7hTHdo4LWedSmQPd/75oepUXV8VTl8scsrccRsleg1fHOIjeNhp+XnSudYPZ4+Dsic+IYghhHlnyvDRc5rbYz2pQ+zJN/8v4WUD8+DqNIokP0gTaJ5nxkaf1ta6mO7OWq/JviYAAP79Nni7NEvJKMRiXd4bPx0+HX1I2SdMIi3ttyYcLzPkK0FH04i908xOb3d2ypd2dqy/l+d0a9HoxMw2jFdXp6IpXJ+vodAEEiNi6Xvue/sVc3XLmxI98deqiVPFSPAvDypBD5fpGp9cdxYwBa7TlydUTYkOuw/TF7fRC3yH8O1ozMAnCaXpL+TjBvgp0XBOQLLnA5EIw4lLBzFqFde5RH8ttSxxpK7oFW2RHOg0njBWAKirSSOA2Wi9mVY2zBB0s31UYmur/uT6cl4Qw+dUd7LOxjcuoKel0/a6n7FPoGmBwW56tWXrlQdnzOtust6+OfiUmGu0LabpUxT4WIJFDHYnG2GMAEsrHxgCsMJDDL2y/zy/cp3K2ViiiIqK9m7GXIR7lzRnJwWBGx+W4nGLFIR0RKj3snikbJ/nT+FaRitWetAZjUTUbnb93M/dNvigCdKBQ6KJ9kohrOkNi6QK0oAM2HmSwwKdsOYhJsl6FfLVJ/WoJygG52gKt9ygP22U0PaQFm0YB06iB6u8IFxx9vdthe2KuEAtvJaQXAcw6m0Q63loPd4ryj8/EDZqIE7+w6OdIn1O2vVUMvR0PJ88lxPQdJgj0LudnuZqKwgt2yOGfUhFBPbXpjZ6I+uO5IaSZ9kEVX7MWYKhRp65P42WeaW8LcSaQB39HfjkN4Bjwcr6lXDyHdjrYmq2AaMzqFvEX2dJw4tIw+6ENuZ4zqQoKmjQ7LFD3nPU0+jTIfsZ6UBfVBJ+t5EeUu+Rb/ls9qRaJ3T+rlmuoUcmFTxV0vPR6jy5eBO71PsJ88qZGuc1h0PFv764PqguhupPk+Z9ZVn9SYxjM+F4lBpB1DPUiYVrJCdfv8E/GwSFWc1B2b+rZoySxBBaNOagQ7YL4yGuIu8J4Hl0O/9d5v6ORA3AvxM9wTFHZAw6pqAMWa6LupOt28E4f6PkCuz6PaM6jD0gVfo6QeqV56H+AV4qXfnkzjUunofVi+R8jXUgaZn4CzgFoIG/Od84i3i6RqjKNbK9H5T9OMQEpSJue+jZe2SFRWrZXkP2qD44AtkC5agLBp54Iu/dWCICnlmJSClwLGiXzrpput9/ChE/+xJsaEjFI4ED2kRolGDv7pZVbADOD6eM+N8prCqMe6UltdcpdfjKzlf8hpJhLF9vaCjHcZf9l1R899GwKb34QgdQg3CnJ3xhlUHTXU9TYZ/c+MfWmKMmu/O8qS0/583juHoYnk20mvTQQBT2founFA2NLjVdol7JZudn2eznxWu9NQrB2iMmM08FGCvdd08/IWhGQGV+c1Fzf2eauabixcom7P6rO2YJb3iVSRTV3rIO53D+z7hbt5gJpqXNNU0Rc1YqR7HpKbR1/bEQnmEc+Xt1WyWIrOu8sBC1IJkDgH0Y2fMdzChmhOR3wHspC/ssPezRfmfURclJwj8Rz7qNpTNAck1TECNudmdC6HVyE+/fOBVuJtr31OAw+0fa9xEIopZ9LbWqCjhAKKtR/8KwimQvtVu1y9OfDVID/u5pyC21EIuM+CJkQws+TrNaGIGtzpjMU6w0lRt7q+KfiefcEU7B96APytSiZLOSGMYsSvtnECvfe/vdrQNPTmnxgXiqgYB193botFa8baXFqlr1Cglia8b4oo5OHNGUOeLBn/97+rdAE+mlWiRS52wvcCJ10oc04otilAJSnGGYIBEqoSkD127N4Oq+/CM2NwavfuhdoLkJMIX0Tc8ECvWEuaTpjRvrwm3sYxIv2fUzfyZZFZh1Cj/2zYc0zMCAgBwDtDJch5HfFj6UjYuxOtd+mmzXgafTeOyey1IMrhifZ4sEtliMR3e1+4ktTuy+3PkCe7gVnrH1QhH4Mwc/u0iY/PDBJYG6ydr4edigl/T5CfZJMH1UliWOWulowrkMkQtCIT/p8F+V4wjdtQ21120HPzhwUMImdRuL6yhZ27Ehs21utxb7UVyjaZSZbMFXiBQkmfKEW9KraVY8UJDxihmemdx1Wt9QDzMNJn42neNRkf9Qi/wWx2eW7hIz04QW9SUoEZ2UbZYOLBfJZ0l6Jv85ZCF1xdA+lUuSLKHUT/CpLevHd9pqdUEzi56oS5DJCYB4mtkLCDpcixchL5PU8zi3GrLJA63AGkbxCQHJth1uBTVTdpsT0d10NpTQpVwsfCnE6iO56biAyOs6AxUaSdL3LLU6vsqfB4XyaqnqkmktXTJSVFdYBNL3qJri/J7CsjAg1ixdUG2ydAkSHpwmbzS+EjlGbHaZ49UgwwwJbQgrPeJsdknuwoTvH0iN8FSobHvwHqGiC+yXQoDRsOZNCWtcP4Kw/la8GCCArVjcrzhyqXyFnoyIpLv4v+YAdBoxr4qzuvWRaqC0j40+IgvZPSM1FmNH9aAyDnlgisZMHPeFqjjDR/lc2/TtrhqrXvD6JWtRtba52pxfzs5ATiysvTQnPHCP2CrA008rxEfmj8hOLqShlfir/KkNHsVX0Jdw6NN+iguZ2nJ7p1EjadPN1JBcSNZvA8O9HNM6ZevKG0PSYcDOyt7bDEq/Jlq3EmUntGsL6wirY1ATj17wuVgJHTalZBph9UYY7WjubDu2cMMAkaCsB7j5GHQn/OcaYSdIvQ+cBEl9tRs/Ya2KnjjX3IunJ4uRBfSMT9TsNzOumkNYTXCJn7sEXvzFenk9yp43/mgSS7ARGVlGIG72EouZUm5nCi3/m3RIpAwqFY3dTB+YkE0c7f9Hbwkq/0Kq34BLfryWgjeXpQkhmo+17SDCYA5z5/OcYfdrnR21Qwkt8rvHelOXNKOABCPf69jK7C4dl2Od8AJAOf0ksodSoqwRy8GAROMp+VS3b6JyKMDb5dPITECx3UwUanpQWuJr0gn71ESlyvGvVo42t6nNACxqI7zOgwpxojXxLZfjsOtITGblt3kps0bV05ZTHTtQkR+GIhNqDTIXkb/yX6h9A+D5dP8QP3MrovQuM0b9Gf62ZQmD5zQH1j+DC5MCWl3v5n6cQN8huzeogTpQHWn9FGrYyRUnRsQZbPRaV9xv6PP2aQSUzCUfBz1NAIW6anCfa2/cXMecuu6Xjm3dlZZ1hTafevtVh18Ho30ZtM5wh/kgRvx9QiSc6LuWW5hAdIDDQaJ6WIOAXcj12yhWgt7PHnXXLD9G4x6Nyct61nCJciCX6QN72xz3TrLqfNWSp7j/wu6k5MQGUZpTI/ObwCLKF51BtbmjnWJQP9nsPeGb6jpWaGW6bi4O6u+dJIPD/3GIQAv/qLjEpGqEC6o8W6NHptkeVU2b6d3BB5St6EIMzlETnLoIG2cfdpzGR+YhUjHdVIouMV38HugUn5qNCGZVA6ZBV2GB2LOGNbR7kO3YoRKX0Q0FgOfOTbNcQ31lcG15dA3Kqu1t3Bja7qU4XoWhshcws+GSoXfuWA7LGl2KqepHmSD8iyU2KIManozVVmFCgfn4HrZ2rXvMI7/UwmwD6jEgl1k0Ehovv1Hrp5SS3begRYd2KRc/TxtVcQ4Nr1FWEhY4/PsAKtvdTNoE8eKe/NkQQR+WHwgY4eSsmt4/Ef4ZH1zB3bAf0AD7GKKViYOBhjbSaRF56Nn9nIK+kim+LOOs1HKwsGFiayLIUsKKWSecxv+YlH/vuMBK/dNWiQBibS2MsPn48Aq4EXle5n8jH+TAEJew6NObbgD3oCzwZiCFdg+omMBpAkQ3fXsHpuO7vpfmI2Wsk8bSjNGXgLAGOWd2IugcWtaqzsje77h68IvqUxJcv7r2kB0n/aPshBJDOHZjuQx8pfrO3X2KdgzM7mpT44HFEq1I82QH1bfhKUjdeqs+tqFC3jZTrsoszB6/hFRV4Tk5/9eGmFdYyeyPaEqN/SpwOl/rsLjp4QuDUmoqy4BsUsWLPCsP99b3i3fgoibPlNixyAAAAAA=";               // picture of the station: image address or data: image ("" = none)
  /* ========================== */

  var MONTHS = { january: 1, jan: 1, januar: 1, "jänner": 1, february: 2, feb: 2, februar: 2, "feber": 2, march: 3, mar: 3, "märz": 3, "mär": 3,
    april: 4, apr: 4, may: 5, mai: 5, june: 6, jun: 6, juni: 6, july: 7, jul: 7, juli: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9,
    october: 10, oct: 10, oktober: 10, okt: 10, november: 11, nov: 11, december: 12, dec: 12, dezember: 12, dez: 12 };
  var WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function txt(el) { return el ? el.textContent.replace(/\s+/g, " ").trim() : ""; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m) + "-" + pad(d); }
  function today() { var d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function dow(s) { var p = s.split("-"); return (new Date(+p[0], +p[1] - 1, +p[2]).getDay() + 6) % 7 + 1; }
  function nice(s) { var p = s.split("-"); return WD[dow(s) - 1] + ", " + p[2] + "." + p[1] + "." + p[0]; }
  function hh(h) { return pad(h) + ":00"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseShown(s) {   /* "18 November 2026" (English) or "18. November 2026" (German) */
    var m = s.toLowerCase().match(/(\d{1,2})\.?\s*([a-zäö]+)\.?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]]) { return iso(+m[3], MONTHS[m[2]], +m[1]); }
    m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) { return iso(+m[3], +m[2], +m[1]); }
    m = s.match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : "";
  }
  function hour(s) { var m = String(s).match(/(\d{1,2})/); return m ? +m[1] : NaN; }
  function param(n) { var m = location.search.match(new RegExp("[?&]" + n + "=([^&]*)")); return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; }
  function selfQuery() { return param("d") ? "d=" + param("d") : "id=" + param("id"); }
  function overlaps(a, b) { return a.date === b.date && a.from < b.to && b.from < a.to; }

  function readBookings(root) {
    return Array.prototype.map.call(root.querySelectorAll(".bk-e"), function (e) {
      return { el: e, id: +e.getAttribute("data-id") || 0, date: parseShown(txt(e.querySelector(".bk-date"))),
        from: hour(txt(e.querySelector(".bk-from"))), to: hour(txt(e.querySelector(".bk-to"))),
        user: txt(e.querySelector(".bk-user")), note: txt(e.querySelector(".bk-note")) };
    });
  }
  function readBoard(root) {
    var out = null;
    Array.prototype.forEach.call(root.querySelectorAll(".tdf-card"), function (c) {
      if (txt(c.querySelector(".tdf-name")) !== STATION) { return; }
      var u = txt(c.querySelector(".tdf-until")).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      out = { status: txt(c.querySelector(".tdf-status")), person: txt(c.querySelector(".tdf-person")).replace(/^@\s*/, ""), until: u ? iso(+u[3], +u[2], +u[1]) : "" };
    });
    return out;
  }
  function fetchPage(query) {
    return fetch("view.php?" + query + "&perpage=1000", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.text(); })
      .then(function (h) { return new DOMParser().parseFromString(h, "text/html"); });
  }
  function problems(b, others, board) {
    var p = [];
    if (!b.date) { p.push("Choose a date."); return p; }
    if (isNaN(b.from) || isNaN(b.to)) { p.push("Choose a start and end time."); return p; }
    if (b.to <= b.from) { p.push("The end time must be after the start time."); }
    else if (b.to - b.from > MAX_HOURS) { p.push("A booking can be at most " + MAX_HOURS + " hours."); }
    if (b.from < OPEN || b.to > CLOSE) { p.push("Bookings are possible between " + hh(OPEN) + " and " + hh(CLOSE) + "."); }
    if (DAYS.indexOf(dow(b.date)) < 0) { p.push("The lab is closed on " + nice(b.date) + "."); }
    if (board && (board.status === "Busy" || board.status === "Occupied") && !(board.until && b.date > board.until)) {
      p.push(STATION + " is " + (board.status === "Occupied" ? "out of service" : "assigned to " + (board.person || "someone")) + (board.until ? " until " + nice(board.until) : "") + " (availability board).");
    }
    others.forEach(function (o) { if (overlaps(b, o)) { p.push("Already booked " + hh(o.from) + "–" + hh(o.to) + " by " + (o.user || "someone") + "."); } });
    return p;
  }
  function header() {
    var el = document.getElementById("st-head"); if (!el) { return; }
    var place = [LOCATION, ROOM].filter(function (v) { return v; }).join(" · ");
    el.innerHTML = (IMG ? '<div class="st-img"><img src="' + IMG + '" alt=""></div>' : "") +
      '<div class="st-headtxt"><h3 class="bk-h">' + esc(STATION) + "</h3>" + (place ? '<p class="bk-sub">' + esc(place) + "</p>" : "") +
      '<p class="bk-sub">Bookable ' + WD[DAYS[0] - 1] + "–" + WD[DAYS[DAYS.length - 1] - 1] + ", " + hh(OPEN) + "–" + hh(CLOSE) + ", max. " + MAX_HOURS + " h per booking.</p></div>";
    var back = document.getElementById("st-back");
    if (back) { if (OVERVIEW_DB) { back.href = "view.php?d=" + OVERVIEW_DB; } else { back.style.display = "none"; } }
  }

  /* ---------------- list page ---------------- */
  function listPage(list) {
    header();
    var all = readBookings(document), t = today(), h = new Date().getHours(), board = null;
    var state = { tab: "upcoming", q: "" };
    var phase = function (b) { return !b.date ? "upcoming" : b.date < t || (b.date === t && b.to <= h) ? "past" : b.date === t && b.from <= h ? "now" : "upcoming"; };
    function draw() {
      Array.prototype.forEach.call(list.querySelectorAll(".bk-js"), function (x) { x.remove(); });
      all.forEach(function (b) {
        b.phase = phase(b);
        var pr = problems(b, all.filter(function (o) { return o !== b && o.id < b.id; }), board);
        b.el.className = "bk-e bk-" + b.phase + (pr.length ? " bk-bad" : "");
        b.el.querySelector(".bk-flag").innerHTML = pr.length ? '<span class="bk-badge bad">Problem</span>' : b.phase === "now" ? '<span class="bk-badge now">Now</span>' : b.phase === "past" ? '<span class="bk-badge">Past</span>' : '<span class="bk-badge ok">Confirmed</span>';
        var pe = b.el.querySelector(".bk-problems");
        if (!pe) { pe = document.createElement("div"); pe.className = "bk-problems"; b.el.insertBefore(pe, b.el.querySelector(".bk-actions")); }
        pe.innerHTML = pr.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + (pr.length ? "<div><b>Please change or delete this booking.</b></div>" : "");
      });
      var show = all.filter(function (b) {
        var okTab = state.tab === "all" || (state.tab === "past" ? b.phase === "past" : state.tab === "today" ? b.date === t : b.phase !== "past");
        return okTab && (!state.q || (b.user + " " + b.note).toLowerCase().indexOf(state.q) >= 0);
      });
      var asc = state.tab !== "past";
      show.sort(function (a, b) { var k = (a.date + pad(a.from)).localeCompare(b.date + pad(b.from)); return asc ? k : -k; });
      all.forEach(function (b) { b.el.style.display = "none"; });
      var last = "";
      show.forEach(function (b) {
        if (b.date !== last) { var hd = document.createElement("h4"); hd.className = "bk-dayhead bk-js"; hd.textContent = (b.date === t ? "Today · " : "") + (b.date ? nice(b.date) : "No date"); list.appendChild(hd); last = b.date; }
        b.el.style.display = ""; list.appendChild(b.el);
      });
      if (!show.length) { var e = document.createElement("p"); e.className = "bk-empty bk-js"; e.textContent = state.tab === "upcoming" ? "No upcoming bookings for this station." : "No bookings match these filters."; list.appendChild(e); }
      var up = all.filter(function (b) { return b.phase !== "past"; }).length, now = all.filter(function (b) { return b.phase === "now"; }).length;
      var bad = all.filter(function (b) { return /bk-bad/.test(b.el.className) && b.phase !== "past"; }).length;
      document.getElementById("bk-summary").innerHTML = "<b>" + up + "</b> upcoming · <b>" + now + "</b> running now" + (bad ? ' · <span class="bad">' + bad + " with a problem</span>" : "");
      Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-t") === state.tab); });
    }
    var qi = document.getElementById("bk-q"); if (qi) { qi.oninput = function () { state.q = qi.value.toLowerCase().trim(); draw(); }; }
    Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.onclick = function () { state.tab = b.getAttribute("data-t"); draw(); }; });
    var add = document.getElementById("bk-add"); if (add) { add.href = "edit.php?" + selfQuery(); }
    if (document.querySelector(".pagination, .paging")) {
      var hint = document.getElementById("bk-pagehint");
      hint.innerHTML = 'Some bookings are on other pages. <a href="view.php?' + selfQuery() + '&perpage=1000">Show all bookings on one page</a>.'; hint.hidden = false;
    }
    draw();
    if (AVAIL_DB) { fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); draw(); }).catch(function () {}); }
  }

  /* ---------------- add / edit page ---------------- */
  function formPage(form) {
    var t = document.getElementById("st-formtitle"); if (t) { t.textContent = "Book: " + STATION; }
    var fromSel = form.querySelector(".bkf-from select"), toSel = form.querySelector(".bkf-to select");
    var dsel = function (part) { return form.querySelector('.bkf-date select[name$="_' + part + '"]'); };
    var box = document.getElementById("bk-check"), others = null, board = null, rid = +param("rid") || 0;
    var pd = param("date").match(/^(\d{4})-(\d{2})-(\d{2})$/), pf = +param("from"), pt = +param("to");
    var setSel = function (sel, fn) { if (sel) { Array.prototype.forEach.call(sel.options, function (o) { if (fn(o)) { sel.value = o.value; } }); } };
    if (pd && !rid) { setSel(dsel("year"), function (o) { return +o.value === +pd[1]; }); setSel(dsel("month"), function (o) { return +o.value === +pd[2]; }); setSel(dsel("day"), function (o) { return +o.value === +pd[3]; }); }
    if (pf && !rid) { setSel(fromSel, function (o) { return hour(o.text) === pf; }); }
    if (pt && !rid) { setSel(toSel, function (o) { return hour(o.text) === pt; }); }
    function current() {
      var y = dsel("year"), m = dsel("month"), d = dsel("day");
      return { date: y && m && d ? iso(+y.value, +m.value, +d.value) : "",
        from: hour(fromSel ? fromSel.options[fromSel.selectedIndex].text : ""), to: hour(toSel ? toSel.options[toSel.selectedIndex].text : "") };
    }
    function check(final) {
      var b = current(), p = problems(b, others || [], board);
      if (b.date && (b.date < today() || (b.date === today() && b.from < new Date().getHours()))) { p.unshift("That time has already passed."); }
      var day = others && b.date ? others.filter(function (o) { return o.date === b.date; }).sort(function (a, c) { return a.from - c.from; }) : [];
      var dayTxt = day.length ? "<div class='bk-dayline'>Other bookings on " + nice(b.date) + ": " + day.map(function (o) { return hh(o.from) + "–" + hh(o.to) + " (" + esc(o.user) + ")"; }).join(", ") + "</div>" : "";
      if (others === null) { box.className = "bk-checkbox wait"; box.innerHTML = "Checking existing bookings…"; return p; }
      if (p.length) { box.className = "bk-checkbox bad"; box.innerHTML = "<b>" + (final ? "Not saved: " : "") + "please fix this first</b>" + p.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + dayTxt; }
      else if (b.date && !isNaN(b.from)) { box.className = "bk-checkbox ok"; box.innerHTML = "<b>✓ " + esc(STATION) + " is free on " + nice(b.date) + ", " + hh(b.from) + "–" + hh(b.to) + ".</b>" + dayTxt; }
      else { box.className = "bk-checkbox"; box.innerHTML = "Choose a date and time."; }
      return p;
    }
    [fromSel, toSel, dsel("day"), dsel("month"), dsel("year")].forEach(function (s) {
      if (s) { s.addEventListener("change", function () {
        var toH = toSel ? hour(toSel.options[toSel.selectedIndex].text) : NaN, frH = hour(fromSel.options[fromSel.selectedIndex].text);
        if (s === fromSel && toSel && (isNaN(toH) || toH <= frH)) { setSel(toSel, function (o) { return hour(o.text) === frH + 1; }); }
        check(false);
      }); }
    });
    var f = form.closest("form");
    if (f) { f.addEventListener("submit", function (ev) {
      if ((ev.submitter && /cancel/i.test(ev.submitter.name || "")) || others === null) { return; }
      if (check(true).length) { ev.preventDefault(); box.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }); }
    check(false);
    var jobs = [fetchPage(selfQuery()).then(function (doc) {
      var all = readBookings(doc);   // a booking that clashes with an earlier one is marked "Problem" – it doesn't block others
      others = all.filter(function (o) { return o.id !== rid && !all.some(function (e) { return e.id < o.id && overlaps(e, o); }); });
    })];
    if (AVAIL_DB) { jobs.push(fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); }).catch(function () {})); }
    Promise.all(jobs).then(function () { check(false); }).catch(function () {
      others = []; check(false);
      box.insertAdjacentHTML("beforeend", "<div class='bk-dayline'>Couldn't load the other bookings – conflicts will be flagged on the list page.</div>");
    });
  }

  function run() {
    var list = document.querySelector(".bk-list"); if (list) { listPage(list); }
    var form = document.querySelector(".bk-sform"); if (form) { formPage(form); }
    if (!list && !form && document.getElementById("st-head")) { header(); }
  }
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", run); } else { run(); }
})();
