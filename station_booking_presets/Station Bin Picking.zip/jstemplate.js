/* Digital Factory Lab – booking database for ONE station (Moodle Database JavaScript template).
   List page: station header, "Book this station", bookings grouped by day, conflict flags.
   Add/Edit page: checks the time against the other bookings of this station before saving.
   Who may book is decided by Moodle permissions (role "Station booker"), not by this script. */
(function () {
  /* ======== settings ======== */
  var STATION = "Bin Picking Station";          // name shown on this page (also used by the overview)
  var LOCATION = "C0.1", ROOM = "";
  var OVERVIEW_DB = 2323;             // id of the "Station overview" database (number after d= in its URL); 0 = no back link
  var AVAIL_DB = 0;                // id of the "Robot availability" database; 0 = don't check the availability board
  var OPEN = 8, CLOSE = 18, MAX_HOURS = 4;
  var DAYS = [1, 2, 3, 4, 5];      // bookable weekdays, 1 = Monday
  var IMG = "data:image/webp;base64,UklGRlQeAABXRUJQVlA4WAoAAAAQAAAAlAAAxwAAQUxQSN8EAAABCbVt2zBw4FH/P+yUNWNE/ydAR2x7BxfaFePE1nZJ7INrfKLyQJMTm6yCkxQMtW3bSPL+Y+cTrroyIiaAfVSMl8HI30BQWRaILUmSJEmKLNwt4NU8ndNalawzp4gJmABK17YdkqQ30tldtm27EpHZRtmI4rp/wdi2be1s2zMr2zbTEfHFotgZ3/ecmV1ETADx/3jJyHOnSmC4fPPtdPWuuIFE+fiYRmv1f2Gwe1faaGMWwqBieNrAuxNh8bkCSiNtWY0IrmJqnNF2qiGBOf1LrbTd8YioqkYnGB3FeExE7l1KHR3lWFQ4VdNzjI5+LCYUl7w8nEVJGUqIo2ZszKCkjali2LlLqaakDscFUDc5yCjZ/2Wcc+9erSAzhjSe1U6MkVnDOq9SdynVZOKQwaWGyUMGmZr9w5/UPYulZHotwpmGmQHiohriSMru1VLipR7mRcPUIPFUDfMgba9SRpyNRU3XMnWAOByPmip9v5JPfI5HzdM6M0X8jvxpjrSDy3tSiedHfjFB4/wAcf5Z4fT0/YslxP1xWuvMfhJh6KTM/Yu5JMg6Rmqf3kPi1CHZB5QMEmmdIHXOBEmwui/noJJGwq27uuaCJGLdknN4IZXEXDd0KUEStq7KGVhMJYGva7qUXSR2XZA9sJJKol8f6lKmCEC9L2dgOegkLKQuJUgorjdyBxZTCEe9kHoUmaAU0N285CYwF/AU4SmAWfBYgGbDQ4CNILEAsoAEIALimCC6ACsgAjRA1s+kfiYCJEAK0DDRARHAAKkBAxMdkYAKiAZ0QCqAqAYYIBVIIDKgIRLQAVEAUQ0wQCqQQGRAQ6SgAxKCgUiBATIKKiKCBkgUGCBD0BApMECioAEyBB2R+pFEQQNk6EeCAkNE0BGpn4qGiKAiUmCILBiYMEQE9T+TBQ0RwYKJziBRDUAWVAsggkqQWBkkDJEF1QBEUC2QMB0TAxLCRCVIdAOQRzA0QATNAKTALJDoBImhQUIqIIJqIBKqBZAKZkVkWOOIhKEiMjQDkYhLgCiYBZAaNhWRIEiGzgBRJCRAaugMEVkxkXRAQjoiozRCRIYGSBQkQxIhUroBSIjpgAxJKiLFNEBCBgE6ilkQEWmAREkJQEYZGiAQ6YgUSYiIIH1ACUQekYrIIh0RYbJIQkSkI7JIRUQkIbLo4fu/0OAQPT7hHzj58e8ZFIuIfnr6jCHv+Lkv/IqD8E57eafcX5+Bxlp3VY/cW7NTePaPrE2t65O7Kp1Cs12xNqvR4+8otQnLftXa/Favr61QEpL7DiKSijtkT3OOcH5+/aa19rIu2VOfLpKXzqND3ZW9N74TEUT8yucpmVNr++XuSgf3Pn+C8zObPHJHqZVn916DT5rX6pNbCzn1x1k/0CeWijtkb3M2f946g0xvK+sOeOrTeKJe9wjx0VXZF+ircXPi65OJpym1nkB3pd18j1xO3M1o8ga+Zqb694RZ4nNeq19uLTDL2ycTz0s6ZV9TVvKxm+8m3tvKewKe+pSk+vFECwnRVd0X7K12JctTF5JAU+s9ge5y29GLnf82iTar2RtsL5aOygcnkpgL2v3+1txtu+MuEreltDPgbbri11OiJHhHRW+gv27H5l48jyDcUe0J9FY51otd8RLhmN7gCXaVWejTYwjNnJZg7sVfwvF/OABWUDggThkAAPBaAJ0BKpUAyAA+bSqRRqQiIaEtFN44gA2JYwhwAY7aCTMm+rsPLl5XoC7mD53pv8T7p7eY3zePS5/kPSq6nbepL8z+gDzB/1HhL+QfSP5380OVH1R5o/zb8Cf0/Mr/leGfw01Dvyz+kf7H+3eSHtt9a/yn7P+wR7H/R/+R/kPIb/3fRH7BewB34fiIfgP+T7BP8+/yX7I+yR/6f670Z/of+u/bL4EP53/et+uVwH+FdRT+AvjTnbqU949XD3qENt4gSZ/6RFYl1KIBm+c/wmf5l1/9eJMb8IZewg4CtZSb5FRzj71fA5qd6NNO2pz5hJyv/WyF3c+M2Khb3jlIyGIPG6/1M6QYu7Lr46o48Q9Z0/61wgCFMEokrSzTI/kvTqMn/1CTa6JOhFc/F+JKp3QW70KCVI34oNPiRa+sb9/Fx0AJwv4nLbo4BV/fR4SQbcecaia8u7Oj3MRKHsjYa3ncRgT1EJ+z9lTuZk2CoOC4n9sSvFFbwaiUuXdinXaZdBrTSEzXDRlvH4TVa11pdmqNRT7ghIh+HBPRTlvSQkgUcPgPNUEytqFAhSwSG+J4sQ3nF4eVdzbKZXBjPHuBIE6neUITbUAXG3Ve2HgRu12ebaOfHjQl51VIZzDw4NipKqstMLeLXsdnigT4yKEpSQNh5NE09lkXRTx7eIjMpBig57MdocZkXe36a+Ih1djOcPrAxBS9XPoOtK9NDVUtlyQxuaN0QXLbbNzcEICXE/sQbu4B9twvg1PV6yiYi5nDe6gQoyBVGgBx1DRtn9e5gl0Vou6hCVG72+kytHvLOWd2ofOmhojczZ6j7pF2yU086T/OyZ4SdhsjesiE4tQCyqaWpMs9W5Mwl2PX9+wdGdPgdj8zuQc6XlrthGxnFXIbCp/6DIpAP77KQUyjn/P6+p/nqpFaWLLcE4mHldwdR2HoHYj2j+ZGwf4zXd7d8JlNlqSSZHZi3vaEAd0zyJ+xPiAA/twsAA4f8tFl4Jlwdr/U98IAP8hQenhKrCQTZX+z4lcyvo1RoqDmrI52FU2jlH/KM4XsPL5hcrCi7nufVgEDv7Jm9PPfDcBJjDbD0510FM3Rwx7ao38uuC0WZl0PccLnyokF/iXWl8WH0kxGIYje3hyN8Jy+pICqmDM/XRxniIfx995/gn0f2stW62dlZEzRBD/5iISNU0gMZWHPO5YwloC2Myu8HaAZpd2SS70f5//1DeO15M43opa3Kh1TlnHBzX+VyFNnAR/wYS0b5WVcSU/jXnAc5xCW1agEkSXGJ4lcpPjmUD7AlFhP6gZ/e40t4P4NdF4VUASxes+klJuJTJmFkfNAWN0ZqfRz53+DG8Yj78wOF5/LZZbz4NQBBUTnxdfcbIvuQmr3fqVEJkwUK4eLS5TWwSyBSVC9yX1yC2rh3uhunYRxt93LDQv8nLRoXy2N3dkc+qIwXP6VtxFb8FKIvX2IvcKWvQmZUuNThl8KSMh6VLjLW/FiQRCbq4/LCxczHDweuOCDWxOjA+wHX55iX2TPXijo7CwjgSpiuXXK5TnT+g5vTszA1Ia3XOdCUxnx9uxkGL/UuZLjZlThMZ84rwfdRhBU8LFG55L4MbRm/mIUKO29K8b//+NIWb8KJbfcAg/+ShHG4ggkqvEic153v/zxTw+o6H4TsgUfmgbXBKRDmIwzyTwVolCEW7l8KF8u4+sdCAhj3cMIQYuuozkz1YX461fwfogCrt/Yv9lyB14vA3ZSj6ursrbIAiQv7rnAwPM160fPUQK+QsRNRcuJK6t2yfb+LlRJ0DI9qPF9JZAwS3shcvXhA5cqL85M0sJ9hB0RpB0AiYCwCyb+OKz4dQGGsnwPWNUaxGXLW8M6Vevvdnor5zDjHMBdK/JBSH9JoyQz/wN7slvl4LLqXcQNh9dByCpvMjJzA6cCII/UOHUyvgxPkIDJjQShyMDnrsPqBD7dDRPePc1S5Ydn0vwyhBDtMETEDYOWoO0qT3Pp+Zi1s6h1nTjkzh2PzutSSSuyQFQuXBreGdDF4nHeU0FU+HFuUvbubD6K1DRmTCLJEBoKZMgWbSS2eBVitZ2W+gOk5MrQ4Px7DX1lbzuzq3JTsVWyly2NdiInXfAJ3D4ppqk1C4XW2NP1pTk8Q6qc0c92OQdd0YfrwRxqvYr4vj168CAIdl52gDGtug9/2UT9FjcOgVhLv+PA66qGKOLbtxz7natcxiKLacAeiaedz/YrM5pyRjl/FCnQiyGflNuywMxEeRvg8q1CnK3RiLV53gHfww8CDaJ6/UFPl+hkEI9lnRaDF+z9sZ7LVw8NtOBqd375Vwg+wxQLypoBBFRpzuWIlM/fQIUwfdxyA9aTPFR/49fLggG7zPk5UgMcmxRTfjB0XtflnphVMHTahvneP7XCwtF3OLIpqX5EpgpsEJCPsiEtlZhQPd8PYBBZEBTxq6ycJGZNq5NhGbXFyRoAQdY/XxYG2OHwCPTsokf0uJVbX0uT+b+4+r/A92Yoh01j0qC1RnE/0GK8RfoT2v1nL//omJv87OFiH9TlOxBsjm8fRWys2JQjZOmF4qbbCU6Y0oaQ03NBPKDxO/0/72Q8Ph1QA5nWiJ3Ks6F3/XA5qPN9B8uk8s0GzYCoCZMANMgRCGRtPV6iAx4r5YaVTdmxHzhENlWjmeJWALUPG+ZNWroN77uKJrEn5PYJCppgKj5UvE+zZ/AvlSntjRxa9Vy7lqMVsHHudcu/tQVRCjN07HsmYo/41+n9k+6jlw9BBDJjboQ46kWpj9uzlvssHQTCEpfHOei5ldcztVaaFXFKTFrrfEsEAuxZiK0AaQ//232FjutiGTO0gPRSYaRmv36Z5q17Rl6rnUgD5Gok+ckyoDHUsnwXZlirvqqPi0N7if48VHl09f32NiqYvVz3/UJM+lvd921faNRc237zEBU83Sw194LgW2tuQ1gU/RBqrC3PLb/U32T6gzs/Zt2csn5JBv35Zv/UbRd4GgwcPADk/cW9frrwNrwspRqgouQ2iVJRgVJh0GntFLHY2iTp+gF15vmlgIyzOftbphNVsam6/qUrTqsEfUO23HrTPv+OMkF3mz8tBTBQ0jI0rD+lV6VDb1xblGMP/9zd6gqSKtw7Wx2i0uXAoqyluxP4eSjafbgtDjx5JcZxZa3oLdZmaiM+w4RBeN/Zz+l8kKEX1cs+6HRjXcJ24nJaTkiDIazzxqQzm8sJZ35ef+wJiiOvVAjxXT6E2QwwZtDjGntZNdZatgk4wf0kNKRbpxorL0DlcMBSYU89Gkg+OtNEPVVzpAaj3pLznMTMfuii6hNtmXRKz/pdehmZJEjp4T1SNSxD2L0oHPHnCGg/51svFz1Mal/Ppg96bfoprHdyO8peUZvtj8wUMaOQSp0Jx4jDCBBkCkBxM5O43C2TOBx0m+ZFJbZHvsUYWD68Ys1eTFwpgodStmXuLrReOW1KsVkCSsB4Ax/h8wfHdIMZ1zdxq3zE5uD+jIXfwGfvBvWGBLC+UhnpRrIIFrhZV7EWCXJw/NhKjOYYGoMIfWRvafaDuAFFALLVKshy5MWTMf3G0fWjighESrbe5AkjIZPaZj3iWuldf+LtNvU6hUW+3bnLa2Up2FugknyIp1WALsEr6C794jIdQpOn80JHy9Tc2SboMdCbFf0RUQKz78PKoxMTf2LUJ7qQK6rPlgSkFu3i7ThuELaKCK+Fqip4WUTAoKPv5tJjlpJ2NOZ0vX4WsigwaNZOxnDteDcAjkMFz8gowZOLYYwkgdiZzLyOe+Tw9vW62Xbc8IfrjROo9MZanDPGR2KyngMibXOhgQ11jY4SARL6FOsjkgrQrvYZpAaH9LxueFVj8B3q0seY4ov7G0uhDrdAkUs8LmomaMweQMTbkp+pmFhKsORdaX0HRzCEm/AEYNxNyXnWwrMEyyrmWBJP+MKcukQFQcteWvy9ILFwSdmm8Al6990Ng+DH9LBZmsYnT8HWSMYKktvF5VHwDRp4AT8UwRHRAh2kA9GM4OrWDd0hJ6/NY0ljE5lb1/3QwY+6xPJ299C6tHdLumYdpNPxiMj0CUBP8nfKAw58Hmyo61zVxOjKgO2ASulSRmWSYpUPuZOrXWYN4fQgbqQK/biRLYRtaaUFGJyx2IJSaR5H2NjMfCxNNyoUfRSIPuJbmA58Q60J4JjBQABi4MxQl71VhjGpsvPBxfeSHmu1mzv/TZPmQs/ay02/bOlItKu3cI+JGBwbsOMbGMaaRzc7g+udCFbxfo+ZBSNr5bjTHGhldaLX6c68MDIquBcdTfojiODAX9eLhuFqRALGp1ypZq12tPVClIfKOjdrhEH5y1NH3tUmrwnyaxoE2D4krF/PnzcDQ/OCUIoBXUaQ2lPqW6jVTMQrWR86kF+/fJ2gnWDOdbixRSCmT/oNl1+Vw1hCu+pC116MLlrxnyik6CTGdqxG24PljEuUtpCXNfI9LzlVqpFRtdC1LA8Zfj8Wtri+/hiZp8B2jwWoJD/4vuI6tu3LNH9151PXUWghajH9gwcCnbXjyWx20SdM2sc16qoF1AlKe9Zg9M+rVfz8vsBoXoNo3YUX8OXQ+GU3WD7+S322jPsHU51wOlVUF308flYB6oOCYMAsIHixqHaTxHR9aApHjs2fBknrjVUDTc3uKT6XXl/X4+ln9IzmoZek/6NZKzZDdobFlvay0a94iKX7C5jboErHgE4Anw3KR5fuhqm0MDkg3w2DuHznUEZ6N2EHdOZ6j+fjayzlNyWvvr/KumydmjAOj+bojfCJKmGauPpU3S5vuxyuxTS7/F1yaaFn7im4/6jlclkNJHHiaSyukVqWipDGPg42p+lOhoV4u5i+9/zP6EzuXIV7o1u3FLcnQsmldDUvLHGJJbhIB2SlcVAI+gTyAttG8ziciouZx8u6dz1RFQhbIa/D9IN5rrtLUgUf6lsZmGMWVArKhD042cLPwQRZYo4u52mUTbeS2QaVG5I+fvL4MZd6QFX1sgFo7IvivoyunWQ6M6vgE8VfYRcj0UdeTvfWBtWhSJYYzHgW1eTa8UakvBPzu9gonFp1RDJGsPyCWfH+t1lKKUYk8dICGisixHYRZHEkGNDuupC2zuaXnDD3SB4dEt+H8yXsqDwvWUBLHFJzrW/wK6jteu6+0oWbHwTScJ7a2k5ig/2m1Z4i53A4ip5W1pBhbofmJupqtWR+Tgx1zddBGEONgnIuGi2Kc3/TjlrnRWWere16fs7JonQT0I5s15yzManSYiVb2MAgm98FyGLeqISJ2m5grF+ojFIxq7VFHvaeRj8EIBc82wTFvLp2/wuRh0e5sLdsJotqg+avfbbzDJyXLLcpeqerYnylJt313u8gPssK9l/1AbDdcvXvczLN2qHDi2ZCc4JozSR/NEiVOSscr8uhLAInJuQtK4z3wi45FaPaYDpJQMYrvGdblqUfKsMe+bt7jW0/MRDwaeWh+Azrmgw6gULCsOn//g1HyfwH6B3vM66qcds4TMkwFMzX4N30fNPt57MoMuftYJmIHJ/4LFdaRKenbI/2DdjdwaYvwyqWSmuz6qLvQf0zamni1OcwDeU8WNHLGV314QV77rGc1aT3/ifWAdJRSkoWnRQVvGGNXvAkYPGDYPbRkeuTY6ZS2miErIKgLoyorB8AakVpN7ftHJ2ZaAUE4mwXflmyP9iBy9xVt3dzXGASbY/uzJRWdMHi4EJ1hSQxBjcXy7ntTcx4EqZRsding3uWT4hyPdyrh6GTegRSCN78dpBKvzO9gfj3Hwb8I5Xdil959inHMME5gUjm70f0V4AscdLJOURVHmrpBpld2uaCC+OKwRKMyWSlGli5M79yZPm87AxURAPat8VoS2thnayuBWO1XQhvsVz9utmMRmqJ+LQOSXaH3Xxd9el1Pa7bkGKqWsQh8GVKy0CkN2PBn++U5gQyladGsPHZG969A9roT7apzubnFSg6ouZu+4uim2UECEu+pPMpI1se65Eld7enrJHFlsBXzyDaXbnLRetekX/zZcyd8qFW61V5eZblgVtrk8yq6WCidO1rbDRX6PGc1ODv8bYneJwQxLjCFLP3WG4kHGMVbdRav+Ke5QOVtya+to2+Y7hrWfZ6YymXATDVCTBVYFcnPDuCuaPo89FJw3UTMpfjJOD0rre3bwKqCO0R6ehIes4kmQIQ8l2kWSlTg7Z/i3OQL8to6ljfnQC8IqPjT2VYhr1UQG+3L6wgWQuzmx+f4iSi2yY5KtW7UL4+RhuncbUcXp78mGEJ8GenpPisUvLm3De8CIhf53ILvfp8Xw4wdrV8G7bL1tW2MweIM3wxAAW3Xx9YE6+dwL4LW2gMyQiwtOZHwfoxGSzWENVU78OApYh34nthw8shMdAooWY7TpYnS22ZBMcwl8wlFJ2F6KTQBpaZvV+cXoW83qG0VK0C9pRHF/be46E3qNPtXRC9dioVjMghUSv4sbFg04+9QDKaI7ArAT6mZZ9HAaa7rS4864qWMzjlj08BQpbEb54+lMqYhC5/QPof492GJDFbjyfGRFfm279Nu3Y5D2AvuLs8mwwxGJQ02+6qkIEh8kzdAGIUS8LuhaiziwYzA0Dtb0Ow9S5RHS979q8f7wEXpqV7/5gpcdsWq2i5iTlos2m5YoQ9e3FqnQl2woYybI25/63l8NJe5uoApJFANCv8sctQxpHMdXLDRXaaPiKbMPqjOCaNt0c6BvlEBGdG+XeLZEc2WRRB4LMhCP+9EnZKyiS8ZzMFJBF3Ps4FsV74XusmEycXXQ6kd/4fSDA6D9OLZLQtFpkXMmih8Z3Zo+aheHVSHie7dgHu1Si3EDqxLqTiVxiAskHge6KP43ZfAUhHwR6/4zOS228dQFHDUDeDiJS8Iogy52UODwhQJy1iysKC9GYDbpXdobrcrD3b5BwlVBeDeVnWKYLtY+XH70BvY4BVCcsRHnZf0X0Xico9NjgA7IgHNVkOYWI/gbrW49Wg0T7nmxRpxoRByUNiXRB/ZHBqYh2LFaXtlxFdhm0YOlNKdpC2X8q0P4ib9ingPXvizhP0RB8wpkRNeUyGiZKouezDpyFzYVtoSy+ZD+OsRdowEIA+DPFQnJBLbkLlyGAwabs8C1dfuU9CZmtVuYOCGXbT68tZYOwc37OBDJAcTNbiLTrwfbcOrHMbcIWj7Xve+fbiDnGi3UId1YhvQ1yt47G6eWFWdgvYUREOzFlpc8PHO4puetFNZlHg8NSro8x+1MjssL3akM6k8ZczcyvPIMnVF2jDUmQJtWQb+ZG/u+jOwqNfwctnN88qTQ6Vk6p8EZBhhInRPSQ++natHS0/zzXQDi1Qr/rfKF72usdyZdODJCAY6dyVt7S4xb8zLEcgrPMzOcrQftOJHHd73xcdeuU0x06Yiyn/ZDpUrtLAtjqKrgHhlBXLg7xZcRWIZKiLQo5QwYX/WWbAG4ddRwWX0LiqdQYbB5OYAqfsJiW72cATc6q63D//SALvhUL8tqSuDsNJxaa3CBNhISmCY37YKoKfC8RkhActCz1ui/2uooxA66lJw/1nEWvRY5HI6uCbJOUN1r6tgvjGVaa62Lv90xVkeojUHIUYmavvRe1TZ5Mipa4eTjAzBI0rC547RYjaCIHQ67JAhb9futHSUDifTAGk6McpSbBzbnfKjgw5pt/hYJC7npq13g5BvtXZsVwSKRlqngAC0Gq5WroTfbQmgZTUJYOBefql+x2EoWOcKSFbTS8K11Hm0DzobOhM7WGIR0P/lS1afWoIMvJD37VfkmBZ4tAVY8bH7UUSk2v9Q6trcSSjHlHQ27bt0kIksUXPcZJJlQw2gRqVpSUPlMdMYUlbtpl5bUzTwFrmuTV+oNYQqfv8S398XVr8iOth06PzTntM7x6cP9Ob+Rqb+O3y/0USq52bYVNlD9r5TfDotDlJ6KCzmPfA0JG6HKiiFrMqmxjLjJFs7WavZtEXkqVyRtE4AlmCbw0tkvMoT/aIZwh2V7pRZMmN31kCWQannxdPF1iD9FSobrlejMEOHWKSplVxEZwuFJR1ReW5DHNz5KddBhiiWDlmOlBuSm/d9+D6ngzwvXmpZGQ4ADa3MnAmfoWPl0mngQ7D8Bbkq9D1njJDrh41A+659TXU6rNHQEs6TXg42QGw0uQ2iyBDdyo7qebudlRHLomEPTj2EUELyg8c5fGJChQfIPyj1JuXs2iyYbQzi+fCwzcslAQW618v3UvhiNNDuCW6Ae6wf+AL5rl15GXUYhYstZsJXH47M+s4SQpX2HWJ7GXHZwFrttptuDRL6gs/kDxarS99KnI8bAvki2gkvZQj9AUfpBQPe3f8/MHyL4gJpCFa/uUdWBlhH6To//B5GhSrw3+fR1ipZ10rtlsil9Sd9Tbw5Di0QeF7E/WOtGgSdtKxC2gdoXqybhqSXGu1fYL8dNFYOzy0vSID69E5eVv7XKZ1OaHhXaKXTfV2kQYy7B919N7/6O/deD0F1BDzpH2CgNg441WqdwR3Y8LmkfX02YDVkdhgrYXK4/RX6gLUYNpW+7tcb/RAlghcIXzCurQPxOdgNR+OjnqNnWKIYxr8l2K/4Lz///q1enSF7YlrZMwAAsaNdYHtFRtXenXPNZ9LMvOJA9BZqPy8fWFLf/iwhdgGfUCbmQCOvlz4cAAAAAA=";               // picture of the station: image address or data: image ("" = none)
  /* ========================== */

  var MONTHS = { january: 1, jan: 1, januar: 1, "jänner": 1, february: 2, feb: 2, februar: 2, "feber": 2, march: 3, mar: 3, "märz": 3, "mär": 3,
    april: 4, apr: 4, may: 5, mai: 5, june: 6, jun: 6, juni: 6, july: 7, jul: 7, juli: 7, august: 8, aug: 8, september: 9, sep: 9, sept: 9,
    october: 10, oct: 10, oktober: 10, okt: 10, november: 11, nov: 11, december: 12, dec: 12, dezember: 12, dez: 12 };
  var WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  function txt(el) { return el ? el.textContent.replace(/\s+/g, " ").trim() : ""; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function iso(y, m, d) { return y + "-" + pad(m) + "-" + pad(d); }
  function today() { var d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function dow(s) { var p = s.split("-"); return (new Date(+p[0], +p[1] - 1, +p[2]).getDay() + 6) % 7 + 1; }
  function nice(s) { var p = s.split("-"); return WD[dow(s) - 1] + ", " + p[2] + "." + p[1] + "." + p[0]; }
  function hh(h) { return pad(h) + ":00"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function parseShown(s) {   /* "18 November 2026" (English) or "18. November 2026" (German) */
    var m = s.toLowerCase().match(/(\d{1,2})\.?\s*([a-zäö]+)\.?,?\s*(\d{4})/);
    if (m && MONTHS[m[2]]) { return iso(+m[3], MONTHS[m[2]], +m[1]); }
    m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) { return iso(+m[3], +m[2], +m[1]); }
    m = s.match(/(\d{4})-(\d{2})-(\d{2})/); return m ? m[0] : "";
  }
  function hour(s) { var m = String(s).match(/(\d{1,2})/); return m ? +m[1] : NaN; }
  function param(n) { var m = location.search.match(new RegExp("[?&]" + n + "=([^&]*)")); return m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : ""; }
  function selfQuery() { return param("d") ? "d=" + param("d") : "id=" + param("id"); }
  function overlaps(a, b) { return a.date === b.date && a.from < b.to && b.from < a.to; }

  function readBookings(root) {
    return Array.prototype.map.call(root.querySelectorAll(".bk-e"), function (e) {
      return { el: e, id: +e.getAttribute("data-id") || 0, date: parseShown(txt(e.querySelector(".bk-date"))),
        from: hour(txt(e.querySelector(".bk-from"))), to: hour(txt(e.querySelector(".bk-to"))),
        user: txt(e.querySelector(".bk-user")), note: txt(e.querySelector(".bk-note")) };
    });
  }
  function readBoard(root) {
    var out = null;
    Array.prototype.forEach.call(root.querySelectorAll(".tdf-card"), function (c) {
      if (txt(c.querySelector(".tdf-name")) !== STATION) { return; }
      var u = txt(c.querySelector(".tdf-until")).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/);
      out = { status: txt(c.querySelector(".tdf-status")), person: txt(c.querySelector(".tdf-person")).replace(/^@\s*/, ""), until: u ? iso(+u[3], +u[2], +u[1]) : "" };
    });
    return out;
  }
  function fetchPage(query) {
    return fetch("view.php?" + query + "&perpage=1000", { credentials: "same-origin" })
      .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.text(); })
      .then(function (h) { return new DOMParser().parseFromString(h, "text/html"); });
  }
  function problems(b, others, board) {
    var p = [];
    if (!b.date) { p.push("Choose a date."); return p; }
    if (isNaN(b.from) || isNaN(b.to)) { p.push("Choose a start and end time."); return p; }
    if (b.to <= b.from) { p.push("The end time must be after the start time."); }
    else if (b.to - b.from > MAX_HOURS) { p.push("A booking can be at most " + MAX_HOURS + " hours."); }
    if (b.from < OPEN || b.to > CLOSE) { p.push("Bookings are possible between " + hh(OPEN) + " and " + hh(CLOSE) + "."); }
    if (DAYS.indexOf(dow(b.date)) < 0) { p.push("The lab is closed on " + nice(b.date) + "."); }
    if (board && (board.status === "Busy" || board.status === "Occupied") && !(board.until && b.date > board.until)) {
      p.push(STATION + " is " + (board.status === "Occupied" ? "out of service" : "assigned to " + (board.person || "someone")) + (board.until ? " until " + nice(board.until) : "") + " (availability board).");
    }
    others.forEach(function (o) { if (overlaps(b, o)) { p.push("Already booked " + hh(o.from) + "–" + hh(o.to) + " by " + (o.user || "someone") + "."); } });
    return p;
  }
  function header() {
    var el = document.getElementById("st-head"); if (!el) { return; }
    var place = [LOCATION, ROOM].filter(function (v) { return v; }).join(" · ");
    el.innerHTML = (IMG ? '<div class="st-img"><img src="' + IMG + '" alt=""></div>' : "") +
      '<div class="st-headtxt"><h3 class="bk-h">' + esc(STATION) + "</h3>" + (place ? '<p class="bk-sub">' + esc(place) + "</p>" : "") +
      '<p class="bk-sub">Bookable ' + WD[DAYS[0] - 1] + "–" + WD[DAYS[DAYS.length - 1] - 1] + ", " + hh(OPEN) + "–" + hh(CLOSE) + ", max. " + MAX_HOURS + " h per booking.</p></div>";
    var back = document.getElementById("st-back");
    if (back) { if (OVERVIEW_DB) { back.href = "view.php?d=" + OVERVIEW_DB; } else { back.style.display = "none"; } }
  }

  /* ---------------- list page ---------------- */
  function listPage(list) {
    header();
    var all = readBookings(document), t = today(), h = new Date().getHours(), board = null;
    var state = { tab: "upcoming", q: "" };
    var phase = function (b) { return !b.date ? "upcoming" : b.date < t || (b.date === t && b.to <= h) ? "past" : b.date === t && b.from <= h ? "now" : "upcoming"; };
    function draw() {
      Array.prototype.forEach.call(list.querySelectorAll(".bk-js"), function (x) { x.remove(); });
      all.forEach(function (b) {
        b.phase = phase(b);
        var pr = problems(b, all.filter(function (o) { return o !== b && o.id < b.id; }), board);
        b.el.className = "bk-e bk-" + b.phase + (pr.length ? " bk-bad" : "");
        b.el.querySelector(".bk-flag").innerHTML = pr.length ? '<span class="bk-badge bad">Problem</span>' : b.phase === "now" ? '<span class="bk-badge now">Now</span>' : b.phase === "past" ? '<span class="bk-badge">Past</span>' : '<span class="bk-badge ok">Confirmed</span>';
        var pe = b.el.querySelector(".bk-problems");
        if (!pe) { pe = document.createElement("div"); pe.className = "bk-problems"; b.el.insertBefore(pe, b.el.querySelector(".bk-actions")); }
        pe.innerHTML = pr.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + (pr.length ? "<div><b>Please change or delete this booking.</b></div>" : "");
      });
      var show = all.filter(function (b) {
        var okTab = state.tab === "all" || (state.tab === "past" ? b.phase === "past" : state.tab === "today" ? b.date === t : b.phase !== "past");
        return okTab && (!state.q || (b.user + " " + b.note).toLowerCase().indexOf(state.q) >= 0);
      });
      var asc = state.tab !== "past";
      show.sort(function (a, b) { var k = (a.date + pad(a.from)).localeCompare(b.date + pad(b.from)); return asc ? k : -k; });
      all.forEach(function (b) { b.el.style.display = "none"; });
      var last = "";
      show.forEach(function (b) {
        if (b.date !== last) { var hd = document.createElement("h4"); hd.className = "bk-dayhead bk-js"; hd.textContent = (b.date === t ? "Today · " : "") + (b.date ? nice(b.date) : "No date"); list.appendChild(hd); last = b.date; }
        b.el.style.display = ""; list.appendChild(b.el);
      });
      if (!show.length) { var e = document.createElement("p"); e.className = "bk-empty bk-js"; e.textContent = state.tab === "upcoming" ? "No upcoming bookings for this station." : "No bookings match these filters."; list.appendChild(e); }
      var up = all.filter(function (b) { return b.phase !== "past"; }).length, now = all.filter(function (b) { return b.phase === "now"; }).length;
      var bad = all.filter(function (b) { return /bk-bad/.test(b.el.className) && b.phase !== "past"; }).length;
      document.getElementById("bk-summary").innerHTML = "<b>" + up + "</b> upcoming · <b>" + now + "</b> running now" + (bad ? ' · <span class="bad">' + bad + " with a problem</span>" : "");
      Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-t") === state.tab); });
    }
    var qi = document.getElementById("bk-q"); if (qi) { qi.oninput = function () { state.q = qi.value.toLowerCase().trim(); draw(); }; }
    Array.prototype.forEach.call(document.querySelectorAll(".bk-tabs button"), function (b) { b.onclick = function () { state.tab = b.getAttribute("data-t"); draw(); }; });
    var add = document.getElementById("bk-add"); if (add) { add.href = "edit.php?" + selfQuery(); }
    if (document.querySelector(".pagination, .paging")) {
      var hint = document.getElementById("bk-pagehint");
      hint.innerHTML = 'Some bookings are on other pages. <a href="view.php?' + selfQuery() + '&perpage=1000">Show all bookings on one page</a>.'; hint.hidden = false;
    }
    draw();
    if (AVAIL_DB) { fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); draw(); }).catch(function () {}); }
  }

  /* ---------------- add / edit page ---------------- */
  function formPage(form) {
    var t = document.getElementById("st-formtitle"); if (t) { t.textContent = "Book: " + STATION; }
    var fromSel = form.querySelector(".bkf-from select"), toSel = form.querySelector(".bkf-to select");
    var dsel = function (part) { return form.querySelector('.bkf-date select[name$="_' + part + '"]'); };
    var box = document.getElementById("bk-check"), others = null, board = null, rid = +param("rid") || 0;
    var pd = param("date").match(/^(\d{4})-(\d{2})-(\d{2})$/), pf = +param("from"), pt = +param("to");
    var setSel = function (sel, fn) { if (sel) { Array.prototype.forEach.call(sel.options, function (o) { if (fn(o)) { sel.value = o.value; } }); } };
    if (pd && !rid) { setSel(dsel("year"), function (o) { return +o.value === +pd[1]; }); setSel(dsel("month"), function (o) { return +o.value === +pd[2]; }); setSel(dsel("day"), function (o) { return +o.value === +pd[3]; }); }
    if (pf && !rid) { setSel(fromSel, function (o) { return hour(o.text) === pf; }); }
    if (pt && !rid) { setSel(toSel, function (o) { return hour(o.text) === pt; }); }
    function current() {
      var y = dsel("year"), m = dsel("month"), d = dsel("day");
      return { date: y && m && d ? iso(+y.value, +m.value, +d.value) : "",
        from: hour(fromSel ? fromSel.options[fromSel.selectedIndex].text : ""), to: hour(toSel ? toSel.options[toSel.selectedIndex].text : "") };
    }
    function check(final) {
      var b = current(), p = problems(b, others || [], board);
      if (b.date && (b.date < today() || (b.date === today() && b.from < new Date().getHours()))) { p.unshift("That time has already passed."); }
      var day = others && b.date ? others.filter(function (o) { return o.date === b.date; }).sort(function (a, c) { return a.from - c.from; }) : [];
      var dayTxt = day.length ? "<div class='bk-dayline'>Other bookings on " + nice(b.date) + ": " + day.map(function (o) { return hh(o.from) + "–" + hh(o.to) + " (" + esc(o.user) + ")"; }).join(", ") + "</div>" : "";
      if (others === null) { box.className = "bk-checkbox wait"; box.innerHTML = "Checking existing bookings…"; return p; }
      if (p.length) { box.className = "bk-checkbox bad"; box.innerHTML = "<b>" + (final ? "Not saved: " : "") + "please fix this first</b>" + p.map(function (x) { return "<div>" + esc(x) + "</div>"; }).join("") + dayTxt; }
      else if (b.date && !isNaN(b.from)) { box.className = "bk-checkbox ok"; box.innerHTML = "<b>✓ " + esc(STATION) + " is free on " + nice(b.date) + ", " + hh(b.from) + "–" + hh(b.to) + ".</b>" + dayTxt; }
      else { box.className = "bk-checkbox"; box.innerHTML = "Choose a date and time."; }
      return p;
    }
    [fromSel, toSel, dsel("day"), dsel("month"), dsel("year")].forEach(function (s) {
      if (s) { s.addEventListener("change", function () {
        var toH = toSel ? hour(toSel.options[toSel.selectedIndex].text) : NaN, frH = hour(fromSel.options[fromSel.selectedIndex].text);
        if (s === fromSel && toSel && (isNaN(toH) || toH <= frH)) { setSel(toSel, function (o) { return hour(o.text) === frH + 1; }); }
        check(false);
      }); }
    });
    var f = form.closest("form");
    if (f) { f.addEventListener("submit", function (ev) {
      if ((ev.submitter && /cancel/i.test(ev.submitter.name || "")) || others === null) { return; }
      if (check(true).length) { ev.preventDefault(); box.scrollIntoView({ behavior: "smooth", block: "center" }); }
    }); }
    check(false);
    var jobs = [fetchPage(selfQuery()).then(function (doc) {
      var all = readBookings(doc);   // a booking that clashes with an earlier one is marked "Problem" – it doesn't block others
      others = all.filter(function (o) { return o.id !== rid && !all.some(function (e) { return e.id < o.id && overlaps(e, o); }); });
    })];
    if (AVAIL_DB) { jobs.push(fetchPage("d=" + AVAIL_DB).then(function (doc) { board = readBoard(doc); }).catch(function () {})); }
    Promise.all(jobs).then(function () { check(false); }).catch(function () {
      others = []; check(false);
      box.insertAdjacentHTML("beforeend", "<div class='bk-dayline'>Couldn't load the other bookings – conflicts will be flagged on the list page.</div>");
    });
  }

  function run() {
    var list = document.querySelector(".bk-list"); if (list) { listPage(list); }
    var form = document.querySelector(".bk-sform"); if (form) { formPage(form); }
    if (!list && !form && document.getElementById("st-head")) { header(); }
  }
  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", run); } else { run(); }
})();
